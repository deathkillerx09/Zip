(() => {
  const viewport = document.getElementById("city-viewport");
  const zoomIn = document.getElementById("city-zoom-in");
  const zoomOut = document.getElementById("city-zoom-out");
  function zoom(deltaY) {
    if (viewport?.dataset.renderer === "isometric-fallback") return;
    const canvas = viewport?.querySelector('canvas[aria-label^="AI Money Town 3D world"]');
    if (!canvas) return;
    canvas.dispatchEvent(new WheelEvent("wheel", { deltaY, bubbles: true, cancelable: true }));
  }
  zoomIn?.addEventListener("click", () => zoom(-100));
  zoomOut?.addEventListener("click", () => zoom(100));
})();
