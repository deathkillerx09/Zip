"""The visible interface must reflect the backend and every control must work."""

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FRONTEND = ROOT / "frontend"


def read(name: str) -> str:
    return (FRONTEND / name).read_text(encoding="utf-8")


def test_worker_health_strip_is_present_and_rendered():
    html = read("index.html")
    app = read("app.js")
    assert 'id="worker-strip"' in html
    assert "function renderWorker(" in app
    assert "renderWorker(data)" in app
    assert "blocked_reason" in app
    assert "valid_deliverable_count" in app


def test_task_board_shows_failures_errors_and_controls():
    app = read("app.js")
    assert "task-${task.status}" in app
    assert "Why it failed:" in app
    assert '"Retry"' in app and '"Run now"' in app
    assert "/api/tasks/${taskId}/${action}" in app
    assert '["failed", "Failed"]' in app
    assert "attempt ${task.attempts}" in app


def test_business_dialog_exposes_real_product_files():
    app = read("app.js")
    assert "Built product files" in app
    assert "No product files have been built for this business yet" in app
    assert "/preview" in app
    assert "/products/build" in app
    assert "history.deliverables" in app


def test_graphics_quality_control_is_wired_to_the_renderer_that_runs():
    fallback = read("city-visual-fallback.js")
    assert "QUALITY_CAPS" in fallback
    assert 'getElementById("graphics-quality")' in fallback
    assert "localStorage.setItem(\"ai-money-town-graphics\"" in fallback
    assert "Isometric town ready" in fallback
    assert 'status.dataset.state="ready"' in fallback


def test_zoom_and_recenter_controls_still_work_in_the_visible_renderer():
    fallback = read("city-visual-fallback.js")
    for control in ("city-zoom-in", "city-zoom-out", "city-recenter"):
        assert f'getElementById("{control}")' in fallback
    assert "state.zoom=Math.min(10" in fallback
    assert "state.zoom=Math.max(3.8" in fallback


def test_three_dimensional_scene_is_opt_in_so_the_laptop_stays_cool():
    bootstrap = read("city-bootstrap.js")
    assert "ai-money-town-renderer" in bootstrap
    assert '"3d"' in bootstrap
    # The default path must not download or render the Three.js scene.
    assert bootstrap.index("if (!use3d)") < bootstrap.index("cityModule.src")


def test_every_button_in_the_page_has_a_handler():
    html = read("index.html")
    scripts = "\n".join(
        read(name) for name in (
            "app.js", "city-visual-fallback.js", "city-zoom-controls.js", "city-bootstrap.js",
        )
    )
    button_ids = re.findall(r'<button[^>]*id="([^"]+)"', html)
    assert button_ids, "expected identifiable buttons"
    missing = [
        button for button in button_ids
        if f'"{button}"' not in scripts and f'"#{button}"' not in scripts
    ]
    assert missing == [], f"buttons with no handler: {missing}"


def test_forms_and_navigation_ids_are_referenced_by_the_application():
    html = read("index.html")
    app = read("app.js")
    form_ids = re.findall(r'<form[^>]*id="([^"]+)"', html)
    assert form_ids
    missing = [form for form in form_ids if f"#{form}" not in app]
    assert missing == [], f"forms with no handler: {missing}"
    data_screens = set(re.findall(r'data-screen="([^"]+)"', html))
    assert data_screens == {"city", "dashboard"}


def test_dashboard_polls_and_reports_worker_state():
    app = read("app.js")
    assert "setInterval" in app
    assert "document.hidden" in app
    assert "Could not load town data" in app
    assert "/api/tasks/${taskId}/${action}" in app


def test_styles_exist_for_the_new_components():
    css = read("styles.css")
    for class_name in (
        ".worker-strip", ".worker-pill", ".task-error", ".task-note",
        ".task-result", ".deliverable-row", ".deliverable-actions",
    ):
        assert class_name in css, class_name
