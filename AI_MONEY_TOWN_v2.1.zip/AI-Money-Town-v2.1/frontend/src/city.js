import * as THREE from "three";

const $ = (selector) => document.querySelector(selector);
const viewport = $("#city-viewport");
const locationName = $("#city-location-name");
const syncStatus = $("#city-sync-status");
const metricsElement = $("#city-metrics");
const promptElement = $("#city-action-prompt");
const errorElement = $("#city-error");
const loadingElement = $("#city-loading");
const returnTownButton = $("#city-return-town");
const returnTownDialogButton = $("#city-dialog-return-town");
const dialog = $("#city-dialog");
const dialogTitle = $("#city-dialog-title");
const dialogKicker = $("#city-dialog-kicker");
const dialogContent = $("#city-dialog-content");
const employeeBuildings = {
  "town-manager": "town-hall",
  researcher: "research-lab",
  strategist: "innovation",
  builder: "product-hq",
  marketer: "marketing",
  "finance-analyst": "central-bank",
  operations: "quality-assurance",
  "community-manager": "customer-centre",
};
const districts = [
  { id: "innovation", title: "Innovation District", x: -40, z: -16, color: 0x8268d8, accent: 0xf0dfff, style: "innovation" },
  { id: "research-lab", title: "Research Laboratory", x: -20, z: -16, color: 0x339dbd, accent: 0xd9f7ff, style: "lab" },
  { id: "town-hall", title: "Town Hall", x: 0, z: -16, color: 0xe5a03f, accent: 0xffe6a2, style: "town" },
  { id: "product-hq", title: "Product Development HQ", x: 20, z: -16, color: 0x3eaa79, accent: 0xd9ffe8, style: "product" },
  { id: "customer-centre", title: "Customer Simulation Centre", x: 40, z: -16, color: 0xe36c79, accent: 0xffd8df, style: "customer" },
  { id: "marketing", title: "Marketing District", x: -40, z: 16, color: 0xd96ca8, accent: 0xffd8ec, style: "marketing" },
  { id: "sales", title: "Sales Department", x: -20, z: 16, color: 0x239b9b, accent: 0xcdfbf0, style: "sales" },
  { id: "central-bank", title: "Central Bank", x: 0, z: 16, color: 0x35785b, accent: 0xe3f5bb, style: "bank" },
  { id: "quality-assurance", title: "Quality Assurance Centre", x: 20, z: 16, color: 0x6e78ad, accent: 0xe0e5ff, style: "quality" },
  { id: "recreation", title: "Employee Recreation Area", x: 40, z: 16, color: 0x69b95f, accent: 0xe4ffb9, style: "park" },
];
const districtById = new Map(districts.map((district) => [district.id, district]));
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x83c6e4);
scene.fog = new THREE.Fog(0x9fc8bd, 180, 420);
const camera = new THREE.PerspectiveCamera(60, 1, 0.1, 520);
let renderer;
try {
  // Low-power is more reliable on integrated GPUs and reduces unnecessary power draw.
  renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "low-power", alpha: false });
} catch (error) {
  loadingElement.hidden = true;
  errorElement.hidden = false;
  errorElement.textContent = `The 3D world could not start because this browser could not create a WebGL 2 graphics context. Update your graphics driver, enable hardware acceleration in Chrome, then reload. Details: ${error.message}`;
  throw error;
}
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.08;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.domElement.setAttribute("aria-label", "AI Money Town 3D world. Click the town, then use WASD or arrow keys to walk.");
renderer.domElement.tabIndex = 0;
viewport.prepend(renderer.domElement);

const cityGroup = new THREE.Group();
cityGroup.name = "Town streets and districts";
const employeeGroup = new THREE.Group();
employeeGroup.name = "Live backend employees";
scene.add(cityGroup, employeeGroup);

const hemiLight = new THREE.HemisphereLight(0xe5f7ff, 0x52654f, 1.15);
scene.add(hemiLight);
const sun = new THREE.DirectionalLight(0xffedc4, 2.15);
sun.position.set(-35, 54, 28);
sun.castShadow = true;
sun.shadow.camera.left = -64;
sun.shadow.camera.right = 64;
sun.shadow.camera.top = 60;
sun.shadow.camera.bottom = -60;
sun.shadow.camera.near = 1;
sun.shadow.camera.far = 150;
sun.shadow.mapSize.set(1024, 1024);
scene.add(sun);

function makeCobblestoneTexture() {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 512;
  const context = canvas.getContext("2d");
  context.fillStyle = "#726f66";
  context.fillRect(0, 0, 512, 512);
  let seed = 8217;
  const random = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  for (let row = 0; row < 15; row += 1) {
    const offset = row % 2 ? -18 : 0;
    for (let column = 0; column < 9; column += 1) {
      const x = column * 62 + offset + 4;
      const y = row * 35 + 4;
      const shade = Math.floor(112 + random() * 45);
      context.fillStyle = `rgb(${shade},${shade - 3},${shade - 13})`;
      context.beginPath();
      context.roundRect(x, y, 55 + random() * 5, 28 + random() * 4, 7);
      context.fill();
      context.strokeStyle = "#4c514a";
      context.lineWidth = 2;
      context.stroke();
      context.fillStyle = "#ffffff18";
      context.fillRect(x + 8, y + 5, 28, 2);
    }
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(11, 1.7);
  texture.anisotropy = 4;
  return texture;
}

function makeRoofTexture() {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 512;
  const context = canvas.getContext("2d");
  context.fillStyle = "#493e3b";
  context.fillRect(0, 0, 512, 512);
  for (let row = 0; row < 18; row += 1) {
    const offset = row % 2 ? -28 : 0;
    for (let column = 0; column < 8; column += 1) {
      const x = column * 70 + offset;
      const y = row * 29;
      const red = 83 + ((row * 13 + column * 7) % 35);
      context.fillStyle = `rgb(${red},${55 + (column % 3) * 5},${47 + (row % 4) * 4})`;
      context.beginPath();
      context.roundRect(x + 2, y + 1, 66, 27, 8);
      context.fill();
      context.strokeStyle = "#382f2d";
      context.lineWidth = 2;
      context.stroke();
      context.fillStyle = "#ffffff20";
      context.fillRect(x + 10, y + 4, 36, 2);
    }
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(2.2, 3.8);
  texture.anisotropy = 4;
  return texture;
}

const roadTexture = makeCobblestoneTexture();
const roofTexture = makeRoofTexture();
const groundMaterial = new THREE.MeshStandardMaterial({ color: 0x78a96f, roughness: 1 });
const roadMaterial = new THREE.MeshStandardMaterial({ color: 0xffffff, map: roadTexture, roughness: 0.98 });
const sidewalkMaterial = new THREE.MeshStandardMaterial({ color: 0xc9c2ad, roughness: 1 });
const roadMarkMaterial = new THREE.MeshStandardMaterial({ color: 0xe3d4b8, roughness: 0.95 });
const windowMaterial = new THREE.MeshStandardMaterial({
  color: 0xb9e8e8,
  emissive: 0x4b8990,
  emissiveIntensity: 0.12,
  roughness: 0.2,
  metalness: 0.12,
});
const cityColliders = [];
const employeeCharacters = new Map();
const clickTargets = [];
const keyState = new Set();
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
const movementForward = new THREE.Vector3();
const movementRight = new THREE.Vector3();
const clock = new THREE.Clock();
let townState = null;
let activeInterior = null;
let interiorGroup = null;
let interiorCharacters = new Map();
let interiorColliders = [];
let currentPrompt = "";
let syncTimer = 0;
let syncInFlight = false;
let latestDiscussionId = 0;
let discussionWindow = null;
let pointerDown = null;
let yaw = 0;
let pitch = 0.55;
let cameraDistance = 44;
let simulationElapsed = 0;
let quality = "low";
let disposed = false;

const player = new THREE.Group();
player.name = "Player avatar";
scene.add(player);
const playerBody = new THREE.Mesh(
  new THREE.CapsuleGeometry(0.35, 0.75, 4, 8),
  new THREE.MeshStandardMaterial({ color: 0x2d6872, roughness: 0.82 }),
);
playerBody.position.y = 0.88;
playerBody.castShadow = true;
player.add(playerBody);
const playerHead = new THREE.Mesh(
  new THREE.SphereGeometry(0.28, 12, 10),
  new THREE.MeshStandardMaterial({ color: 0xf1c6a2, roughness: 0.85 }),
);
playerHead.position.y = 1.61;
playerHead.castShadow = true;
player.add(playerHead);
const playerPack = new THREE.Mesh(
  new THREE.BoxGeometry(0.44, 0.48, 0.24),
  new THREE.MeshStandardMaterial({ color: 0xf3bd59, roughness: 0.9 }),
);
playerPack.position.set(0, 0.91, 0.36);
player.add(playerPack);
const playerEyeMaterial = new THREE.MeshStandardMaterial({ color: 0x273a42, roughness: 0.35 });
for (const x of [-0.095, 0.095]) {
  const eye = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 6), playerEyeMaterial);
  eye.position.set(x, 1.64, -0.245);
  player.add(eye);
}
const playerArms = [];
for (const x of [-0.39, 0.39]) {
  const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.095, 0.42, 3, 6), new THREE.MeshStandardMaterial({ color: 0x245d69, roughness: 0.84 }));
  arm.position.set(x, 1.0, 0);
  arm.rotation.z = x < 0 ? -0.12 : 0.12;
  arm.castShadow = true;
  player.add(arm);
  playerArms.push(arm);
}
const playerLegs = [];
for (const x of [-0.15, 0.15]) {
  const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.11, 0.42, 3, 6), new THREE.MeshStandardMaterial({ color: 0x354a55, roughness: 0.92 }));
  leg.position.set(x, 0.31, 0);
  leg.castShadow = true;
  player.add(leg);
  playerLegs.push(leg);
}
let playerWalkPhase = 0;
let playerIsMoving = false;
player.position.set(0, 0, 32); // Start at the southern town approach with the main square in view.

function box(parent, width, height, depth, material, x, y, z, options = {}) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), material);
  mesh.position.set(x, y, z);
  mesh.castShadow = options.castShadow !== false;
  mesh.receiveShadow = options.receiveShadow !== false;
  parent.add(mesh);
  return mesh;
}

function textTexture(title, subtitle = "", background = "#18362a", foreground = "#f3f8e9") {
  const canvas = document.createElement("canvas");
  canvas.width = 768;
  canvas.height = 192;
  const context = canvas.getContext("2d");
  context.fillStyle = background;
  context.beginPath();
  context.roundRect(10, 10, 748, 172, 22);
  context.fill();
  context.fillStyle = foreground;
  context.textAlign = "center";
  context.font = "700 39px Segoe UI, Arial";
  context.fillText(title, 384, subtitle ? 88 : 118, 700);
  if (subtitle) {
    context.globalAlpha = 0.82;
    context.font = "500 21px Segoe UI, Arial";
    context.fillText(subtitle, 384, 135, 710);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;
  return texture;
}

function makeSign(parent, title, subtitle, x, y, z, width, height, background, facing = 0) {
  const material = new THREE.MeshBasicMaterial({
    map: textTexture(title, subtitle, background),
    transparent: true,
    side: THREE.DoubleSide,
  });
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(width, height), material);
  sign.position.set(x, y, z);
  sign.rotation.y = facing;
  parent.add(sign);
  return sign;
}

function addRoad(width, length, x, z, rotation = 0) {
  const road = box(cityGroup, width, 0.16, length, roadMaterial, x, -0.02, z, { castShadow: false });
  road.rotation.y = rotation;
  road.receiveShadow = true;
  return road;
}

function addTree(x, z, scale = 1) {
  const tree = new THREE.Group();
  tree.position.set(x, 0, z);
  tree.scale.setScalar(scale);
  const trunkMaterial = new THREE.MeshStandardMaterial({ color: 0x79553a, roughness: 1 });
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.31, 1.75, 9), trunkMaterial);
  trunk.position.y = 0.87;
  trunk.castShadow = true;
  tree.add(trunk);

  const foliage = [0x3f9867, 0x52aa70, 0x347e5a, 0x67b977];
  const crowns = [
    [-0.48, 1.88, 0.08, 1.03], [0.42, 2.02, -0.12, 1.08],
    [0.0, 2.7, 0.02, 0.92], [-0.14, 3.32, 0.0, 0.65],
  ];
  crowns.forEach(([cx, cy, cz, radius], index) => {
    const crown = new THREE.Mesh(
      new THREE.IcosahedronGeometry(radius, 1),
      new THREE.MeshStandardMaterial({ color: foliage[index], roughness: 1, flatShading: true }),
    );
    crown.position.set(cx, cy, cz);
    crown.scale.set(1, 0.9, 0.95);
    crown.castShadow = true;
    crown.receiveShadow = true;
    tree.add(crown);
  });
  cityGroup.add(tree);
  cityColliders.push({ x, z, radius: 0.72 * scale });
}
function addStreetlight(x, z) {
  const group = new THREE.Group();
  group.position.set(x, 0, z);
  const metal = new THREE.MeshStandardMaterial({ color: 0x465b56, metalness: 0.42, roughness: 0.55 });
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.12, 4.2, 8), metal);
  pole.position.y = 2.1;
  group.add(pole);
  const arm = box(group, 1.05, 0.12, 0.12, metal, 0.42, 4.05, 0, { castShadow: false });
  arm.rotation.z = -0.18;
  const bulbMaterial = new THREE.MeshStandardMaterial({
    color: 0xfff0b5,
    emissive: 0xffc767,
    emissiveIntensity: 0.04,
    roughness: 0.2,
  });
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 6), bulbMaterial);
  bulb.position.set(0.85, 3.82, 0);
  group.add(bulb);
  cityGroup.add(group);
  cityColliders.push({ x, z, radius: 0.32 });
}

function addBench(x, z, facing = 0) {
  const group = new THREE.Group();
  group.position.set(x, 0, z);
  group.rotation.y = facing;
  const wood = new THREE.MeshStandardMaterial({ color: 0x956e4e, roughness: 0.95 });
  const legs = new THREE.MeshStandardMaterial({ color: 0x465a54, metalness: 0.32, roughness: 0.65 });
  box(group, 2.4, 0.14, 0.55, wood, 0, 0.58, 0);
  box(group, 2.4, 0.75, 0.13, wood, 0, 1.02, -0.2);
  for (const xOffset of [-0.85, 0.85]) box(group, 0.13, 0.55, 0.48, legs, xOffset, 0.3, 0);
  cityGroup.add(group);
}

function addBuilding(district) {
  const root = new THREE.Group();
  root.position.set(district.x, 0, district.z);
  root.userData.districtId = district.id;
  const direction = district.z < 0 ? 1 : -1;
  const plasterPalette = {
    innovation: 0xe1d4bd, lab: 0xd9e4df, town: 0xe8dabb, product: 0xe6d8c2,
    customer: 0xe8d2c5, marketing: 0xe8d8d0, sales: 0xd8e4d9, bank: 0xd8d2b9,
    quality: 0xd8dce8, park: 0xe0dfc5,
  };
  const mainColor = new THREE.MeshStandardMaterial({ color: plasterPalette[district.style] || 0xe1d4bd, roughness: 0.94 });
  const trim = new THREE.MeshStandardMaterial({ color: district.accent, roughness: 0.78 });
  const roof = new THREE.MeshStandardMaterial({ color: 0xffffff, map: roofTexture, roughness: 0.94 });
  box(root, 11.6, 0.48, 9.4, sidewalkMaterial, 0, 0.24, 0);
  const height = district.style === "town" || district.style === "bank" ? 9.5 : 7.7;
  box(root, 9.2, height, 7.2, mainColor, 0, height / 2 + 0.48, 0);
  box(root, 9.5, 0.3, 7.5, trim, 0, height + 0.55, 0);
  const facadeZ = direction * 3.66;
  const windowRows = 2;
  for (let row = 0; row < windowRows; row += 1) {
    const y = 2.15 + row * 2.65;
    for (const x of [-3.1, -1.05, 1.05, 3.1]) {
      box(root, 1.25, 1.15, 0.14, windowMaterial, x, y, facadeZ, { castShadow: false });
      box(root, 1.38, 0.09, 0.18, trim, x, y + 0.62, facadeZ, { castShadow: false });
      box(root, 0.08, 1.18, 0.16, trim, x - 0.66, y, facadeZ, { castShadow: false });
      box(root, 0.08, 1.18, 0.16, trim, x + 0.66, y, facadeZ, { castShadow: false });
    }
  }
  // Side windows make the buildings read as complete 3D architecture when approached.
  for (const side of [-1, 1]) {
    for (const z of [-2.3, 0, 2.3]) {
      box(root, 0.14, 1.28, 1.5, trim, side * 4.61, 3.2, z, { castShadow: false });
      box(root, 0.08, 1.08, 1.28, windowMaterial, side * 4.7, 3.2, z, { castShadow: false });
    }
  }
  const doorMaterial = new THREE.MeshStandardMaterial({
    color: 0x315e58,
    emissive: 0x183a38,
    emissiveIntensity: 0.2,
    metalness: 0.22,
    roughness: 0.28,
  });
  box(root, 1.5, 2.25, 0.22, doorMaterial, 0, 1.65, direction * 3.76, { castShadow: false });
  box(root, 1.8, 0.16, 0.55, trim, 0, 0.68, direction * 4.05);
  if (district.style === "town") {
    const dome = new THREE.Mesh(new THREE.SphereGeometry(2.15, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), trim);
    dome.position.y = height + 0.7;
    dome.castShadow = true;
    root.add(dome);
    const spire = new THREE.Mesh(new THREE.ConeGeometry(0.38, 1.5, 8), roof);
    spire.position.y = height + 2.75;
    root.add(spire);
    for (const x of [-2.4, 2.4]) {
      const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.25, 2.6, 8), trim);
      pillar.position.set(x, 1.8, direction * 4.2);
      root.add(pillar);
    }
  } else if (district.style === "bank") {
    for (const x of [-3, -1.5, 0, 1.5, 3]) {
      const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.3, 4.8, 8), trim);
      pillar.position.set(x, 2.9, direction * 4.1);
      root.add(pillar);
    }
    box(root, 10.1, 0.42, 8, roof, 0, height + 1.03, 0);
    const crest = new THREE.Mesh(new THREE.SphereGeometry(0.68, 10, 8), trim);
    crest.position.set(0, height + 1.65, 0);
    root.add(crest);
  } else if (district.style === "lab") {
    const dome = new THREE.Mesh(new THREE.SphereGeometry(3.2, 12, 8), windowMaterial);
    dome.scale.y = 0.48;
    dome.position.set(0, height + 1.28, -0.2);
    dome.castShadow = true;
    root.add(dome);
    const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.08, 2.4, 6), roof);
    antenna.position.set(2.5, height + 1.7, -1);
    root.add(antenna);
  } else if (district.style === "innovation" || district.style === "product") {
    const roofShape = new THREE.Mesh(new THREE.ConeGeometry(5.3, 2.6, 4), roof);
    roofShape.position.y = height + 1.75;
    roofShape.rotation.y = Math.PI / 4;
    roofShape.castShadow = true;
    root.add(roofShape);
    const vent = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.43, 1.8, 8), trim);
    vent.position.set(2.4, height + 1.5, -1.6);
    root.add(vent);
  } else if (district.style === "park") {
    const canopy = new THREE.Mesh(
      new THREE.CylinderGeometry(0.3, 0.3, 1.6, 8),
      new THREE.MeshStandardMaterial({ color: 0x825c42, roughness: 1 }),
    );
    canopy.position.y = height + 0.9;
    root.add(canopy);
    const leaves = new THREE.Mesh(new THREE.ConeGeometry(5.1, 3.7, 8), trim);
    leaves.position.y = height + 3.05;
    leaves.castShadow = true;
    root.add(leaves);
  } else {
    const roofShape = new THREE.Mesh(new THREE.ConeGeometry(6.6, 2.4, 4), roof);
    roofShape.rotation.y = Math.PI / 4;
    roofShape.position.y = height + 1.6;
    roofShape.castShadow = true;
    root.add(roofShape);
  }
  // Layered façade details make each workplace read as a proper game location.
  box(root, 9.45, 0.28, 7.48, roof, 0, 0.62, 0);
  box(root, 3.8, 0.22, 1.15, trim, 0, 3.0, direction * 4.18);
  for (const x of [-1.58, 1.58]) {
    const column = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.18, 2.55, 8), trim);
    column.position.set(x, 1.65, direction * 4.18);
    column.castShadow = true;
    root.add(column);
  }
  const doorGlow = new THREE.Mesh(
    new THREE.BoxGeometry(1.15, 1.72, 0.06),
    new THREE.MeshStandardMaterial({ color: district.accent, emissive: district.accent, emissiveIntensity: 0.12, roughness: 0.24 }),
  );
  doorGlow.position.set(0, 1.68, direction * 3.9);
  root.add(doorGlow);
  for (const side of [-1, 1]) {
    box(root, 0.32, 0.28, 0.5, roof, side * 3.55, height + 0.82, -2.35);
    box(root, 0.32, 0.28, 0.5, roof, side * 3.55, height + 0.82, 2.35);
  }
  // Warm timber framing, layered roof planes, dormers, lanterns and flower boxes
  // make each workplace read as a fantasy guild building instead of a bare block.
  const timber = new THREE.MeshStandardMaterial({ color: 0x634632, roughness: 0.96 });
  const timberLight = new THREE.MeshStandardMaterial({ color: 0x9a714d, roughness: 0.92 });
  const stone = new THREE.MeshStandardMaterial({ color: 0x9c9988, roughness: 1 });
  const lantern = new THREE.MeshStandardMaterial({ color: 0xffd78a, emissive: 0xffa83d, emissiveIntensity: 0.72, roughness: 0.28 });
  // A pair of broad pitched roof planes overlays the older roof silhouette.
  const leftRoof = box(root, 6.45, 0.34, 9.65, roof, -1.72, height + 1.38, 0);
  leftRoof.rotation.z = 0.49;
  const rightRoof = box(root, 6.45, 0.34, 9.65, roof, 1.72, height + 1.38, 0);
  rightRoof.rotation.z = -0.49;
  box(root, 0.42, 0.38, 9.85, timber, 0, height + 2.95, 0);
  box(root, 10.05, 0.34, 0.42, timber, 0, height + 0.68, direction * 4.1);
  // Front timber frame and diagonals.
  for (const x of [-4.12, -2.0, 0, 2.0, 4.12]) {
    box(root, 0.22, Math.min(height - 0.35, 7.15), 0.23, timber, x, height / 2 + 0.48, direction * 3.78);
  }
  for (const y of [1.08, 3.2, 5.7, height + 0.24]) {
    box(root, 9.15, 0.2, 0.25, timber, 0, y, direction * 3.82);
  }
  for (const x of [-3.1, 3.1]) {
    const brace = box(root, 2.0, 0.16, 0.2, timberLight, x, 1.95, direction * 3.84);
    brace.rotation.z = x < 0 ? -0.72 : 0.72;
  }
  // Stone entrance, small balcony rail and warm lanterns.
  box(root, 2.35, 0.26, 0.9, stone, 0, 0.18, direction * 4.45);
  for (const x of [-1.9, 1.9]) {
    box(root, 0.14, 1.0, 0.14, timber, x, 2.65, direction * 4.3);
    box(root, 0.14, 1.0, 0.14, timber, x, 2.65, direction * 5.1);
  }
  box(root, 4.0, 0.14, 0.9, timber, 0, 3.12, direction * 4.72);
  for (const x of [-4.15, 4.15]) {
    box(root, 0.48, 0.72, 0.38, timber, x, 4.25, direction * 4.05);
    const glow = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 8), lantern);
    glow.position.set(x, 4.23, direction * 4.28);
    root.add(glow);
  }
  // Flower boxes under the lower windows.
  for (const x of [-3.1, -1.05, 1.05, 3.1]) {
    box(root, 1.34, 0.18, 0.48, timber, x, 1.48, direction * 3.98);
    for (let flower = 0; flower < 3; flower += 1) {
      const blossom = new THREE.Mesh(
        new THREE.SphereGeometry(0.12, 7, 6),
        new THREE.MeshStandardMaterial({ color: [0xf0bd69, 0xe58a91, 0xc6a5e7][(flower + Math.abs(x)) % 3], roughness: 0.8 }),
      );
      blossom.position.set(x - 0.34 + flower * 0.34, 1.7 + (flower % 2) * 0.08, direction * 4.05);
      root.add(blossom);
    }
  }
  // A chimney and two roof dormers break up the roof silhouette.
  const chimney = box(root, 0.82, 2.2, 0.82, stone, 3.15, height + 2.1, -2.2);
  chimney.castShadow = true;
  box(root, 1.06, 0.2, 1.06, timber, 3.15, height + 3.25, -2.2);
  for (const x of [-2.35, 2.35]) {
    const dormer = new THREE.Group();
    dormer.position.set(x, height + 1.65, direction * 1.35);
    box(dormer, 1.2, 1.35, 0.62, mainColor, 0, 0.1, 0);
    const dormerRoof = new THREE.Mesh(new THREE.ConeGeometry(1.0, 0.9, 4), roof);
    dormerRoof.position.y = 0.95;
    dormerRoof.rotation.y = Math.PI / 4;
    dormer.add(dormerRoof);
    box(dormer, 0.58, 0.68, 0.06, windowMaterial, 0, 0.18, direction * 0.34, { castShadow: false });
    root.add(dormer);
  }

  const signZ = direction * 4.02;
  makeSign(root, district.title, "AI MONEY TOWN GUILD", 0, height + 1.3, signZ, 7.8, 1.55, "#193b36");
  const doorX = district.x;
  const doorZ = district.z + direction * 4.6;
  cityGroup.add(root);
  cityColliders.push({
    minX: district.x - 5.1,
    maxX: district.x + 5.1,
    minZ: district.z - 4.15,
    maxZ: district.z + 4.15,
  });
  clickTargets.push({ object: root.children[1], type: "building", districtId: district.id });
  district.door = { x: doorX, z: doorZ, direction };
  district.height = height;
}

function buildValleyTerrain() {
  const geometry = new THREE.PlaneGeometry(340, 270, 84, 68);
  const positions = geometry.attributes.position;
  const colors = new Float32Array(positions.count * 3);
  const grass = new THREE.Color(0x82b575);
  const deepGrass = new THREE.Color(0x548363);
  const rock = new THREE.Color(0x777d70);
  const highRock = new THREE.Color(0xb5b4a5);
  for (let index = 0; index < positions.count; index += 1) {
    const x = positions.getX(index);
    const z = -positions.getY(index);
    const radius = Math.hypot(x, z);
    const edge = THREE.MathUtils.smoothstep(radius, 62, 150);
    const rolling = 5.0 + 5.5 * Math.sin(x * 0.031 + z * 0.019) * Math.cos(z * 0.027 - x * 0.014)
      + 3.2 * Math.max(0, Math.sin((x + z) * 0.022));
    const height = Math.max(0, edge * rolling);
    positions.setZ(index, height);
    const color = height < 1.6
      ? grass.clone().lerp(deepGrass, Math.max(0, Math.sin(x * 0.055) * Math.cos(z * 0.048)) * 0.22)
      : height < 9 ? deepGrass.clone().lerp(rock, (height - 1.6) / 7.4)
        : rock.clone().lerp(highRock, THREE.MathUtils.clamp((height - 9) / 16, 0, 0.8));
    colors[index * 3] = color.r;
    colors[index * 3 + 1] = color.g;
    colors[index * 3 + 2] = color.b;
  }
  geometry.attributes.position.needsUpdate = true;
  geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
  geometry.computeVertexNormals();
  const ground = new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({ color: 0xffffff, vertexColors: true, roughness: 1 }));
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -0.13;
  ground.receiveShadow = true;
  cityGroup.add(ground);
}

function addFantasyLandscape() {
  // An enclosing ring of irregular rock peaks gives the valley a distant horizon.
  const rockMaterial = new THREE.MeshStandardMaterial({ color: 0x777d78, roughness: 1, flatShading: true });
  const snowMaterial = new THREE.MeshStandardMaterial({ color: 0xe0e9e4, roughness: 0.94, flatShading: true });
  let seed = 39021;
  const random = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  const peakPositions = [
    [-145, -108], [-90, -128], [-18, -132], [66, -126], [137, -94],
    [153, -15], [145, 76], [76, 119], [-12, 128], [-104, 115], [-155, 40], [-151, -35],
  ];
  peakPositions.forEach(([x, z], index) => {
    const group = new THREE.Group();
    group.position.set(x, 2, z);
    group.rotation.y = random() * Math.PI;
    const geometry = new THREE.SphereGeometry(1, 18, 12);
    const vertices = geometry.attributes.position;
    for (let vertex = 0; vertex < vertices.count; vertex += 1) {
      const vx = vertices.getX(vertex);
      const vy = vertices.getY(vertex);
      const vz = vertices.getZ(vertex);
      const jagged = 1 + 0.12 * Math.sin(vx * 8 + index) * Math.cos(vz * 7 - vy * 4);
      vertices.setXYZ(vertex, vx * jagged, vy * (1 + 0.1 * Math.sin(vx * 5 + vz * 3)), vz * jagged);
    }
    geometry.computeVertexNormals();
    const mountain = new THREE.Mesh(geometry, rockMaterial);
    mountain.scale.set(17 + random() * 15, 29 + random() * 22, 16 + random() * 13);
    mountain.castShadow = true;
    group.add(mountain);
    const snow = new THREE.Mesh(new THREE.ConeGeometry(8 + random() * 4, 15 + random() * 8, 7), snowMaterial);
    snow.position.y = 22 + random() * 12;
    snow.rotation.y = random() * Math.PI;
    snow.castShadow = true;
    group.add(snow);
    cityGroup.add(group);
  });

  // Curved stream at the edge of the central meadow; each segment follows the bend.
  const water = new THREE.MeshStandardMaterial({ color: 0x66c1d0, roughness: 0.2, metalness: 0.08, transparent: true, opacity: 0.83 });
  const bankStone = new THREE.MeshStandardMaterial({ color: 0x9eaa9d, roughness: 1 });
  for (let segment = 0; segment < 14; segment += 1) {
    const z = -55 + segment * 8.2;
    const x = 62 + Math.sin(segment * 0.42) * 7;
    const ribbon = new THREE.Mesh(new THREE.PlaneGeometry(10, 8.8), water);
    ribbon.rotation.x = -Math.PI / 2;
    ribbon.rotation.z = Math.sin(segment * 0.42) * 0.18;
    ribbon.position.set(x, 0.035, z);
    cityGroup.add(ribbon);
    if (segment % 2 === 0) {
      const pebble = new THREE.Mesh(new THREE.SphereGeometry(0.8 + random() * 0.5, 8, 6), bankStone);
      pebble.scale.set(1.5, 0.42, 0.8);
      pebble.position.set(x + (segment % 4 ? 5.2 : -5.2), 0.15, z + 1.2);
      cityGroup.add(pebble);
    }
  }

  // Trees are distributed in loose clusters, not in a repeated grid.
  for (let index = 0; index < 56; index += 1) {
    const angle = random() * Math.PI * 2;
    const radius = 76 + random() * 48;
    const x = Math.cos(angle) * radius;
    const z = Math.sin(angle) * radius * 0.76;
    addTree(x, z, 0.82 + random() * 0.62);
  }

  // Small flower patches add colour around the paths without overloading the GPU.
  const flowerMaterial = [0xf3c76c, 0xe88d9d, 0xf2e8b7, 0xbca4e8].map((color) =>
    new THREE.MeshStandardMaterial({ color, roughness: 0.85 }),
  );
  const stemMaterial = new THREE.MeshStandardMaterial({ color: 0x4c8650, roughness: 1 });
  for (let patch = 0; patch < 18; patch += 1) {
    const angle = random() * Math.PI * 2;
    const radius = 48 + random() * 30;
    const px = Math.cos(angle) * radius;
    const pz = Math.sin(angle) * radius * 0.72;
    if (Math.abs(px) < 47 && Math.abs(pz) < 45) continue;
    const group = new THREE.Group();
    group.position.set(px, 0, pz);
    for (let flower = 0; flower < 5; flower += 1) {
      const fx = (random() - 0.5) * 4.2;
      const fz = (random() - 0.5) * 4.2;
      const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.05, 0.45, 5), stemMaterial);
      stem.position.set(fx, 0.23, fz);
      const bloom = new THREE.Mesh(new THREE.SphereGeometry(0.14 + random() * 0.07, 7, 6), flowerMaterial[Math.floor(random() * flowerMaterial.length)]);
      bloom.position.set(fx, 0.49, fz);
      group.add(stem, bloom);
    }
    cityGroup.add(group);
  }

  // Low stone walls, signposts and a small woodland lookout make the outskirts explorable.
  const stone = new THREE.MeshStandardMaterial({ color: 0x8f9386, roughness: 1 });
  for (const [x, z, rotation] of [[-68, -54, 0.25], [78, 48, -0.32], [-82, 55, 0.1], [104, -33, -0.18]]) {
    const wall = box(cityGroup, 14, 1.05, 0.65, stone, x, 0.52, z);
    wall.rotation.y = rotation;
  }
  const lookout = new THREE.Group();
  lookout.position.set(-83, 0, -58);
  const timber = new THREE.MeshStandardMaterial({ color: 0x745238, roughness: 0.96 });
  for (const x of [-1.8, 1.8]) for (const z of [-1.8, 1.8]) {
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.18, 5.2, 7), timber);
    post.position.set(x, 2.6, z);
    lookout.add(post);
  }
  const platform = new THREE.Mesh(new THREE.BoxGeometry(4.6, 0.34, 4.6), timber);
  platform.position.y = 2.0;
  lookout.add(platform);
  const canopy = new THREE.Mesh(new THREE.ConeGeometry(3.4, 2.2, 4), new THREE.MeshStandardMaterial({ color: 0x66413b, roughness: 0.94 }));
  canopy.position.y = 5.7;
  canopy.rotation.y = Math.PI / 4;
  lookout.add(canopy);
  cityGroup.add(lookout);
}

function buildTown() {
  buildValleyTerrain();
  addRoad(108, 8, 0, 0);
  for (let x = -51; x <= 51; x += 6) {
    box(cityGroup, 2.8, 0.035, 0.16, roadMarkMaterial, x, 0.07, 0, { castShadow: false });
  }
  for (const district of districts) {
    const direction = district.z < 0 ? 1 : -1;
    const doorZ = district.z + direction * 4.6;
    addRoad(3.1, Math.abs(doorZ), district.x, doorZ / 2);
  }
  for (const district of districts) addBuilding(district);
  for (let x = -48; x <= 48; x += 12) {
    if (Math.abs(x) < 7) continue;
    for (const side of [-1, 1]) {
      addTree(x + (side < 0 ? 1.5 : -1.5), side * 5.5, 0.8 + ((Math.abs(x) + side + 5) % 3) * 0.1);
    }
  }
  for (let x = -45; x <= 45; x += 15) {
    for (const side of [-1, 1]) addStreetlight(x, side * 5.15);
  }
  for (const side of [-1, 1]) {
    for (const x of [-30, -10, 10, 30]) addBench(x, side * 6.5, side < 0 ? Math.PI : 0);
  }
  for (let x = -52; x <= 52; x += 13) {
    addTree(x, -31, 1.05);
    addTree(x + 5, 31, 1.05);
  }
  for (const district of districts) {
    const path = box(cityGroup, 5.1, 0.08, Math.max(2, Math.abs(district.door.z) - 2), sidewalkMaterial,
      district.x, 0.02, district.door.z / 2, { castShadow: false });
    path.receiveShadow = true;
    if (district.id === "recreation") {
      const lawn = new THREE.Mesh(
        new THREE.CircleGeometry(4.5, 18),
        new THREE.MeshStandardMaterial({ color: 0x92c97c, roughness: 1 }),
      );
      lawn.rotation.x = -Math.PI / 2;
      lawn.position.set(district.x, 0.01, district.z + 9 * district.door.direction);
      cityGroup.add(lawn);
      addBench(district.x - 3.3, district.z + 9 * district.door.direction);
      addTree(district.x + 3.3, district.z + 9 * district.door.direction, 0.9);
    }
    void path;
  }
  addCityLandmarks();
  addFantasyLandscape();
}

function addParkedCar(x, z, color, accent = 0xf7f6e8) {
  const car = new THREE.Group();
  car.position.set(x, 0, z);
  const paint = new THREE.MeshStandardMaterial({ color, metalness: 0.18, roughness: 0.34 });
  const glass = new THREE.MeshStandardMaterial({ color: 0x263f4b, metalness: 0.25, roughness: 0.2 });
  const rubber = new THREE.MeshStandardMaterial({ color: 0x202b2d, roughness: 0.95 });
  const chrome = new THREE.MeshStandardMaterial({ color: 0xd8e0d9, metalness: 0.65, roughness: 0.32 });
  box(car, 3.15, 0.58, 1.55, paint, 0, 0.62, 0);
  box(car, 1.82, 0.68, 1.25, glass, 0, 1.18, -0.02);
  box(car, 1.72, 0.12, 1.3, paint, 0, 1.57, -0.02);
  for (const wx of [-0.98, 0.98]) {
    for (const wz of [-0.82, 0.82]) {
      const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.18, 12), rubber);
      wheel.rotation.x = Math.PI / 2;
      wheel.position.set(wx, 0.48, wz);
      wheel.castShadow = true;
      car.add(wheel);
      const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.13, 0.19, 10), chrome);
      hub.rotation.x = Math.PI / 2;
      hub.position.copy(wheel.position);
      car.add(hub);
    }
  }
  const lamp = new THREE.MeshStandardMaterial({ color: accent, emissive: accent, emissiveIntensity: 0.32, roughness: 0.2 });
  for (const xOffset of [-1.42, 1.42]) {
    box(car, 0.22, 0.18, 0.08, lamp, xOffset, 0.78, -0.79, { castShadow: false });
    box(car, 0.2, 0.16, 0.08, new THREE.MeshStandardMaterial({ color: 0xd74b4b, emissive: 0x5a1515, emissiveIntensity: 0.18 }), xOffset, 0.72, 0.79, { castShadow: false });
  }
  cityGroup.add(car);
  cityColliders.push({ minX: x - 1.75, maxX: x + 1.75, minZ: z - 1.0, maxZ: z + 1.0 });
}

function addCityLandmarks() {
  const curb = new THREE.MeshStandardMaterial({ color: 0xc8d3c4, roughness: 0.9 });
  const stripe = new THREE.MeshStandardMaterial({ color: 0xf7f1d8, roughness: 0.8 });
  const planterStone = new THREE.MeshStandardMaterial({ color: 0x8b9e91, roughness: 0.95 });
  const soil = new THREE.MeshStandardMaterial({ color: 0x574b3a, roughness: 1 });
  const leaf = new THREE.MeshStandardMaterial({ color: 0x4f9e69, roughness: 1, flatShading: true });
  const flowerColors = [0xf7c65d, 0xf58e91, 0xf1e7a0, 0xb6a3ed];

  // Raised sidewalks frame the main avenue and make the street layout legible.
  for (const z of [-4.35, 4.35]) {
    box(cityGroup, 108, 0.18, 0.72, curb, 0, 0.02, z, { castShadow: false });
  }
  // A wide pedestrian crossing at the town-square junction.
  for (let x = -2.8; x <= 2.8; x += 0.92) {
    box(cityGroup, 0.52, 0.045, 6.5, stripe, x, 0.075, 0, { castShadow: false });
  }

  // Central fountain landmark; walkers can pass around its circular edge.
  const fountain = new THREE.Group();
  fountain.position.set(0, 0, 0);
  const stone = new THREE.MeshStandardMaterial({ color: 0xb8c2bc, roughness: 0.72 });
  const darkStone = new THREE.MeshStandardMaterial({ color: 0x71867f, roughness: 0.8 });
  const water = new THREE.MeshStandardMaterial({ color: 0x5fc4d6, metalness: 0.15, roughness: 0.2, transparent: true, opacity: 0.92 });
  const base = new THREE.Mesh(new THREE.CylinderGeometry(3.35, 3.55, 0.42, 32), darkStone);
  base.position.y = 0.21;
  base.receiveShadow = true;
  fountain.add(base);
  const basin = new THREE.Mesh(new THREE.CylinderGeometry(2.95, 3.15, 0.38, 32), stone);
  basin.position.y = 0.58;
  basin.castShadow = true;
  fountain.add(basin);
  const waterSurface = new THREE.Mesh(new THREE.CylinderGeometry(2.65, 2.65, 0.08, 32), water);
  waterSurface.position.y = 0.79;
  fountain.add(waterSurface);
  const pedestal = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.65, 1.35, 12), stone);
  pedestal.position.y = 1.42;
  pedestal.castShadow = true;
  fountain.add(pedestal);
  const orb = new THREE.Mesh(new THREE.IcosahedronGeometry(0.7, 1), new THREE.MeshStandardMaterial({ color: 0x72d7e8, emissive: 0x1d7583, emissiveIntensity: 0.28, roughness: 0.2 }));
  orb.position.y = 2.25;
  orb.castShadow = true;
  fountain.add(orb);
  cityGroup.add(fountain);
  cityColliders.push({ x: 0, z: 0, radius: 3.0 });

  const planterPositions = [
    [-13, -8], [13, -8], [-13, 8], [13, 8],
    [-33, 8], [-27, -8], [27, 8], [33, -8],
    [-7, -27], [7, -27], [-7, 27], [7, 27],
  ];
  planterPositions.forEach(([x, z], index) => {
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    box(group, 3.2, 0.38, 1.8, planterStone, 0, 0.2, 0);
    box(group, 2.88, 0.12, 1.48, soil, 0, 0.43, 0, { castShadow: false });
    for (let p = 0; p < 3; p += 1) {
      const shrub = new THREE.Mesh(new THREE.IcosahedronGeometry(0.46, 1), leaf);
      shrub.position.set(-0.82 + p * 0.82, 0.72 + (p % 2) * 0.08, 0);
      shrub.castShadow = true;
      group.add(shrub);
      const flower = new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 6), new THREE.MeshStandardMaterial({ color: flowerColors[(index + p) % flowerColors.length], roughness: 0.55 }));
      flower.position.set(-0.82 + p * 0.82, 1.05 + (p % 2) * 0.08, 0.05);
      group.add(flower);
    }
    cityGroup.add(group);
    cityColliders.push({ minX: x - 1.8, maxX: x + 1.8, minZ: z - 1.05, maxZ: z + 1.05 });
  });

  // Small colourful information kiosks bring scale and activity to the square.
  for (const [x, z, color] of [[-9, -11, 0xe7a74c], [9, 11, 0x639bd5], [-31, -1, 0x7aaf72], [31, 1, 0xc17da9]]) {
    const kiosk = new THREE.Group();
    kiosk.position.set(x, 0, z);
    const body = new THREE.MeshStandardMaterial({ color, roughness: 0.72 });
    const roof = new THREE.MeshStandardMaterial({ color: 0x344e4b, roughness: 0.84 });
    box(kiosk, 2.2, 1.85, 1.8, body, 0, 1.05, 0);
    box(kiosk, 2.55, 0.28, 2.1, roof, 0, 2.12, 0);
    box(kiosk, 1.45, 0.78, 0.08, windowMaterial, 0, 1.22, 0.94, { castShadow: false });
    const awning = box(kiosk, 2.42, 0.16, 0.72, stripe, 0, 1.78, 1.22, { castShadow: false });
    awning.rotation.x = -0.12;
    cityGroup.add(kiosk);
    cityColliders.push({ minX: x - 1.3, maxX: x + 1.3, minZ: z - 1.1, maxZ: z + 1.1 });
  }
}

function createCharacter(employee, uniformColor) {
  const group = new THREE.Group();
  group.userData.employeeId = employee.id;
  const cloth = new THREE.MeshStandardMaterial({ color: uniformColor, roughness: 0.86 });
  const skin = new THREE.MeshStandardMaterial({ color: 0xe9bd99, roughness: 0.92 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x34433e, roughness: 0.9 });
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 10), skin);
  head.position.y = 1.58;
  head.castShadow = true;
  group.add(head);
  const eyeMaterial = new THREE.MeshStandardMaterial({ color: 0x263a42, roughness: 0.4 });
  for (const x of [-0.09, 0.09]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.032, 8, 6), eyeMaterial);
    eye.position.set(x, 1.61, 0.255);
    group.add(eye);
  }
  const hair = new THREE.Mesh(
    new THREE.SphereGeometry(0.285, 10, 8, 0, Math.PI * 2, 0, Math.PI * 0.48),
    dark,
  );
  hair.position.y = 1.69;
  hair.castShadow = true;
  group.add(hair);
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.34, 0.61, 4, 8), cloth);
  torso.position.y = 0.98;
  torso.castShadow = true;
  group.add(torso);
  const legs = [];
  for (const x of [-0.15, 0.15]) {
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.105, 0.38, 3, 6), dark);
    leg.position.set(x, 0.33, 0);
    leg.castShadow = true;
    group.add(leg);
    legs.push(leg);
  }
  const arms = [];
  for (const x of [-0.43, 0.43]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.105, 0.48, 3, 6), cloth);
    arm.position.set(x, 1.02, 0);
    arm.rotation.z = x < 0 ? -0.14 : 0.14;
    arm.castShadow = true;
    group.add(arm);
    arms.push(arm);
  }
  const hitbox = new THREE.Mesh(
    new THREE.CylinderGeometry(0.56, 0.56, 2.25, 8),
    new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, colorWrite: false, depthWrite: false }),
  );
  hitbox.position.y = 1.12;
  hitbox.userData.employeeId = employee.id;
  group.add(hitbox);
  const label = new THREE.Sprite(new THREE.SpriteMaterial({
    map: textTexture(employee.name, employee.role, "#21372d", "#f3f8e9"),
    transparent: true,
    depthWrite: false,
  }));
  label.scale.set(3.9, 0.96, 1);
  label.position.y = 2.55;
  group.add(label);
  return {
    group,
    head,
    torso,
    arms,
    legs,
    hitbox,
    label,
    employee,
    activity: "idle",
    taskId: null,
    lastTaskStatus: null,
    target: null,
    celebrationUntil: 0,
    walkPhase: 0,
  };
}

function stationPosition(employee, active = false) {
  const district = districtById.get(employeeBuildings[employee.id]) || districtById.get("town-hall");
  const side = employee.id.length % 2 === 0 ? -1 : 1;
  const offset = active ? side * 2.3 : side * 0.1;
  return new THREE.Vector3(district.x + offset, 0, district.door.z + district.door.direction * 2.4);
}

const uniformColors = [0x3b7c8b, 0x468f68, 0x8165ae, 0x3f896a, 0xc06878, 0xa57b42, 0x5b718e, 0x9a617d];
function updateCharacters(employees) {
  employees.forEach((employee, index) => {
    let character = employeeCharacters.get(employee.id);
    if (!character) {
      character = createCharacter(employee, uniformColors[index % uniformColors.length]);
      character.group.position.copy(stationPosition(employee));
      employeeGroup.add(character.group);
      employeeCharacters.set(employee.id, character);
      clickTargets.push({ object: character.hitbox, type: "employee", employeeId: employee.id });
    }
    const oldTask = character.employee.current_task;
    const newTask = employee.current_task;
    if (character.taskId !== null && oldTask?.status !== "completed" && newTask?.status === "completed") {
      character.celebrationUntil = performance.now() + 3600;
    }
    character.employee = employee;
    character.label.material.map?.dispose();
    character.label.material.map = textTexture(employee.name, employee.role, "#21372d", "#f3f8e9");
    character.label.material.needsUpdate = true;
    const taskId = newTask?.id ?? null;
    if (taskId !== character.taskId || newTask?.status !== character.lastTaskStatus) {
      character.target = stationPosition(employee, Boolean(newTask && newTask.status !== "completed"));
    }
    character.taskId = taskId;
    character.lastTaskStatus = newTask?.status ?? null;
  });
}

function activityFor(character, now) {
  const employee = character.employee;
  if (character.target && character.group.position.distanceTo(character.target) > 0.12) return "walking";
  if (employee.status === "offline") return "resting";
  if (discussionWindow && now < discussionWindow.until &&
      [discussionWindow.sender_employee_id, discussionWindow.recipient_employee_id].includes(employee.id)) {
    return "discussing";
  }
  if (character.celebrationUntil > now) return "celebrating";
  const task = employee.current_task;
  if (task?.status === "in_progress") {
    return employee.role.toLowerCase().includes("research") ? "researching" : "working";
  }
  if (task?.status === "pending") return "queued";
  return "idle";
}

function animateCharacter(character, delta, now) {
  const activity = activityFor(character, now);
  character.activity = activity;
  if (character.labelActivity !== activity) {
    character.label.material.map?.dispose();
    character.label.material.map = textTexture(
      character.employee.name,
      `${character.employee.role} · ${activity}`,
      "#21372d",
      "#f3f8e9",
    );
    character.label.material.needsUpdate = true;
    character.labelActivity = activity;
  }
  const moving = character.target && character.group.position.distanceTo(character.target) > 0.12;
  if (moving) {
    const position = character.group.position;
    const direction = character.target.clone().sub(position);
    direction.y = 0;
    const distance = direction.length();
    direction.normalize();
    const step = Math.min(distance, delta * 2.15);
    position.addScaledVector(direction, step);
    character.group.rotation.y = Math.atan2(direction.x, direction.z);
    character.walkPhase += delta * 9;
    character.legs[0].rotation.x = Math.sin(character.walkPhase) * 0.55;
    character.legs[1].rotation.x = -Math.sin(character.walkPhase) * 0.55;
    character.arms[0].rotation.x = -Math.sin(character.walkPhase) * 0.38;
    character.arms[1].rotation.x = Math.sin(character.walkPhase) * 0.38;
  } else {
    character.group.position.y = Math.sin(now * 0.002 + character.employee.id.length) * 0.035;
    character.legs.forEach((leg) => { leg.rotation.x *= 0.82; });
    const breath = Math.sin(now * 0.0025 + character.employee.id.length);
    character.torso.scale.y = 1 + breath * 0.025;
    character.head.rotation.z = activity === "researching" ? Math.sin(now * 0.0015) * 0.12 : 0;
    if (activity === "working" || activity === "researching") {
      character.arms[0].rotation.x = -0.28 + Math.sin(now * 0.008) * 0.1;
      character.arms[1].rotation.x = -0.28 + Math.cos(now * 0.007) * 0.1;
      character.arms[0].rotation.z = -0.16;
      character.arms[1].rotation.z = 0.16;
    } else if (activity === "discussing") {
      character.arms[0].rotation.z = -0.48 - Math.sin(now * 0.01) * 0.34;
      character.arms[1].rotation.z = 0.48 + Math.cos(now * 0.011) * 0.34;
    } else if (activity === "celebrating") {
      character.arms[0].rotation.z = -2.35 + Math.sin(now * 0.01) * 0.1;
      character.arms[1].rotation.z = 2.35 - Math.sin(now * 0.01) * 0.1;
    } else if (activity === "resting") {
      character.arms[0].rotation.z = -0.52;
      character.arms[1].rotation.z = 0.52;
      character.torso.rotation.x = 0.11;
    } else {
      character.arms[0].rotation.z = -0.14;
      character.arms[1].rotation.z = 0.14;
      character.torso.rotation.x = 0;
    }
    character.arms[0].rotation.x *= 0.7;
    character.arms[1].rotation.x *= 0.7;
  }
}

let minimapCanvas = null;
let minimapContext = null;
let minimapElapsed = 0;

function createMinimap() {
  if (minimapCanvas) return;
  const panel = document.createElement("div");
  panel.className = "city-minimap-panel";
  panel.setAttribute("aria-label", "Town minimap");
  const title = document.createElement("span");
  title.textContent = "TOWN MAP";
  minimapCanvas = document.createElement("canvas");
  minimapCanvas.width = 184;
  minimapCanvas.height = 132;
  minimapCanvas.setAttribute("aria-label", "Map of buildings, employees and your player location");
  panel.append(title, minimapCanvas);
  viewport.append(panel);
  minimapContext = minimapCanvas.getContext("2d");
  drawMinimap();
}

function drawMinimap() {
  if (!minimapContext || !minimapCanvas) return;
  const context = minimapContext;
  const width = minimapCanvas.width;
  const height = minimapCanvas.height;
  const mapX = (x) => 8 + ((x + 170) / 340) * (width - 16);
  const mapY = (z) => 7 + ((z + 135) / 270) * (height - 14);
  context.clearRect(0, 0, width, height);
  context.fillStyle = "#19382d";
  context.fillRect(0, 0, width, height);
  context.strokeStyle = "#536d5d";
  context.lineCap = "round";
  context.lineWidth = 7;
  context.beginPath();
  context.moveTo(mapX(-53), mapY(0));
  context.lineTo(mapX(53), mapY(0));
  for (const district of districts) {
    context.moveTo(mapX(district.x), mapY(0));
    context.lineTo(mapX(district.x), mapY(district.door.z));
  }
  context.stroke();
  for (const district of districts) {
    const x = mapX(district.x);
    const y = mapY(district.z);
    context.fillStyle = `#${district.color.toString(16).padStart(6, "0")}`;
    context.fillRect(x - 5, y - 4, 10, 8);
    context.strokeStyle = "#f1f5e8";
    context.lineWidth = 0.8;
    context.strokeRect(x - 5, y - 4, 10, 8);
  }
  if (!activeInterior) {
    for (const employee of townState?.employees || []) {
      const character = employeeCharacters.get(employee.id);
      if (!character) continue;
      context.fillStyle = "#84dfaa";
      context.beginPath();
      context.arc(mapX(character.group.position.x), mapY(character.group.position.z), 2, 0, Math.PI * 2);
      context.fill();
    }
  }
  const playerX = mapX(player.position.x);
  const playerY = mapY(player.position.z);
  context.save();
  context.translate(playerX, playerY);
  context.rotate(-yaw);
  context.fillStyle = "#ffd66c";
  context.strokeStyle = "#4a3520";
  context.lineWidth = 1.2;
  context.beginPath();
  context.moveTo(0, -6);
  context.lineTo(4.5, 4);
  context.lineTo(0, 2.2);
  context.lineTo(-4.5, 4);
  context.closePath();
  context.fill();
  context.stroke();
  context.restore();
}

function buildWorld() {
  buildTown();
  createMinimap();
  const loader = $("#city-loading");
  loader.hidden = true;
}

function setGraphics(value) {
  quality = value;
  const ratio = window.devicePixelRatio || 1;
  const maxRatio = quality === "high" ? 1.5 : quality === "medium" ? 1.15 : 0.85;
  renderer.setPixelRatio(Math.min(ratio, maxRatio));
  renderer.shadowMap.enabled = quality !== "low";
  sun.castShadow = quality !== "low";
  sun.shadow.mapSize.setScalar(quality === "high" ? 1024 : 512);
  renderer.setSize(viewport.clientWidth, viewport.clientHeight, false);
  localStorage.setItem("ai-money-town-graphics", quality);
}

function resize() {
  const width = Math.max(1, viewport.clientWidth);
  const height = Math.max(1, viewport.clientHeight);
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  renderer.setSize(width, height, false);
}

function setPrompt(key, content, action) {
  if (currentPrompt === key) return;
  currentPrompt = key;
  promptElement.replaceChildren();
  promptElement.hidden = !content;
  if (!content) return;
  const label = document.createElement("span");
  label.textContent = content;
  promptElement.append(label);
  if (action) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "city-prompt-button";
    button.textContent = action.label;
    button.addEventListener("click", action.run);
    promptElement.append(button);
  }
}

function horizontalDistance(position, x, z) {
  return Math.hypot(position.x - x, position.z - z);
}

function nearestEmployee() {
  if (!townState) return null;
  const source = activeInterior ? interiorCharacters : employeeCharacters;
  let nearest = null;
  let nearestDistance = Infinity;
  for (const employee of townState.employees) {
    const character = source.get(employee.id);
    if (!character) continue;
    const distance = horizontalDistance(player.position, character.group.position.x, character.group.position.z);
    if (distance < nearestDistance) {
      nearest = employee;
      nearestDistance = distance;
    }
  }
  return nearestDistance <= 2.6 ? nearest : null;
}

function nearestDoor() {
  let nearest = null;
  let nearestDistance = Infinity;
  for (const district of districts) {
    const distance = horizontalDistance(player.position, district.door.x, district.door.z);
    if (distance < nearestDistance) {
      nearest = district;
      nearestDistance = distance;
    }
  }
  return nearestDistance <= 3.2 ? nearest : null;
}

function updatePrompt() {
  if (activeInterior) {
    const employee = nearestEmployee();
    if (employee) {
      setPrompt(`employee:${employee.id}`, `E · Talk with ${employee.name}`, {
        label: employee.role.toLowerCase().includes("town manager") ? "Talk with Mayor" : "Talk with employee",
        run: () => interactEmployee(employee),
      });
    } else if (activeInterior.id === "central-bank") {
      setPrompt("bank-ledger", "Central Bank · Virtual treasury", {
        label: "View ledger",
        run: openBank,
      });
    } else {
      setPrompt("exit-building", `${activeInterior.title} · Interior`, {
        label: "Exit building",
        run: exitBuilding,
      });
    }
    return;
  }
  const employee = nearestEmployee();
  const door = nearestDoor();
  if (employee && door) {
    setPrompt(`dual:${employee.id}:${door.id}`, `E · Talk with ${employee.name}`, {
      label: `F · Enter ${door.title}`,
      run: () => enterBuilding(door),
    });
  } else if (employee) {
    setPrompt(`employee:${employee.id}`, `E · Talk with ${employee.name}`, {
      label: employee.role.toLowerCase().includes("town manager") ? "Talk with Mayor" : "Talk with employee",
      run: () => interactEmployee(employee),
    });
  } else if (door) {
    setPrompt(`door:${door.id}`, `F · Enter ${door.title}`, {
      label: "Enter building",
      run: () => enterBuilding(door),
    });
  } else {
    setPrompt("", "");
  }
}

function addRoomDesk(parent, x, z, label, active = false) {
  const wood = new THREE.MeshStandardMaterial({ color: active ? 0x7eaa83 : 0xa78562, roughness: 0.9 });
  const metal = new THREE.MeshStandardMaterial({ color: 0x465852, metalness: 0.25, roughness: 0.7 });
  box(parent, 2.45, 0.15, 1.1, wood, x, 1.08, z);
  for (const dx of [-0.95, 0.95]) box(parent, 0.12, 1.05, 0.12, metal, x + dx, 0.52, z);
  box(parent, 0.92, 0.58, 0.11, metal, x, 1.48, z - 0.28);
  box(parent, 0.78, 0.43, 0.06, new THREE.MeshStandardMaterial({
    color: 0x263e47,
    emissive: active ? 0x164e44 : 0x17313e,
    emissiveIntensity: active ? 0.55 : 0.18,
  }), x, 1.5, z - 0.2, { castShadow: false });
  const seat = box(parent, 0.8, 0.22, 0.72, new THREE.MeshStandardMaterial({ color: 0x4d786a }), x, 0.62, z + 1.05);
  seat.rotation.x = -0.08;
  makeSign(parent, label, active ? "ACTIVE BACKEND TASK" : "WORKSTATION", x, 2.35, z - 0.83, 2.1, 0.52, active ? "#1d5445" : "#33463e");
  interiorColliders.push({ minX: x - 1.35, maxX: x + 1.35, minZ: z - 0.45, maxZ: z + 0.45 });
}

function buildInterior(district) {
  interiorGroup = new THREE.Group();
  interiorGroup.name = `${district.title} interior`;
  interiorColliders = [];
  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(16, 16),
    new THREE.MeshStandardMaterial({ color: district.accent, roughness: 1 }),
  );
  floor.rotation.x = -Math.PI / 2;
  floor.position.y = -0.06;
  floor.receiveShadow = true;
  interiorGroup.add(floor);
  const wall = new THREE.MeshStandardMaterial({ color: 0xf0eee4, roughness: 0.98 });
  const exterior = new THREE.MeshStandardMaterial({ color: district.color, roughness: 0.92 });
  box(interiorGroup, 16, 6.2, 0.3, wall, 0, 3.05, -8);
  box(interiorGroup, 0.3, 6.2, 16, wall, -8, 3.05, 0);
  box(interiorGroup, 0.3, 6.2, 16, wall, 8, 3.05, 0);
  box(interiorGroup, 5.8, 6.2, 0.3, wall, -5.1, 3.05, 8);
  box(interiorGroup, 5.8, 6.2, 0.3, wall, 5.1, 3.05, 8);
  box(interiorGroup, 16.4, 0.3, 16.4, exterior, 0, -0.24, 0);
  for (const x of [-5.8, 5.8]) {
    const window = new THREE.Mesh(
      new THREE.BoxGeometry(1.7, 1.7, 0.12),
      new THREE.MeshStandardMaterial({ color: 0x8ec9d3, emissive: 0x31565a, emissiveIntensity: 0.28, roughness: 0.28 }),
    );
    window.position.set(x, 2.4, -7.78);
    interiorGroup.add(window);
  }
  const staff = townState.employees.filter((employee) => employeeBuildings[employee.id] === district.id);
  const workTitle = staff[0]?.current_task?.title || "Available workstation";
  makeSign(interiorGroup, district.title, staff.length ? `${staff[0].name} · ${workTitle}` : "Open collaborative workspace",
    0, 4.1, -7.76, 8.5, 1.2, "#254737");
  const stations = [-4.7, -1.6, 1.6, 4.7];
  for (const [index, x] of stations.entries()) {
    addRoomDesk(interiorGroup, x, -1.1, staff[index]?.name || `Team desk ${index + 1}`, Boolean(staff[index]?.current_task));
  }
  const plant = new THREE.Group();
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.35, 0.45, 8), exterior);
  pot.position.y = 0.22;
  plant.add(pot);
  const leaves = new THREE.Mesh(new THREE.SphereGeometry(0.58, 8, 6), new THREE.MeshStandardMaterial({ color: 0x5c9b68 }));
  leaves.position.y = 0.85;
  plant.add(leaves);
  plant.position.set(-6.3, 0, 5.7);
  interiorGroup.add(plant);
  scene.add(interiorGroup);
  interiorCharacters = new Map();
  for (const [index, employee] of staff.entries()) {
    const character = createCharacter(employee, uniformColors[townState.employees.indexOf(employee) % uniformColors.length]);
    character.group.position.set(stations[index] || 0, 0, -2.85);
    character.group.rotation.y = 0;
    interiorGroup.add(character.group);
    interiorCharacters.set(employee.id, character);
    clickTargets.push({ object: character.hitbox, type: "employee", employeeId: employee.id });
  }
  activeInterior = district;
  cityGroup.visible = false;
  employeeGroup.visible = false;
  // Spawn near the centre; the old z=6.3 spawn pushed the follow camera
  // outside the room, where it looked through a wall into the blue background.
  player.position.set(0, 0, 1.6);
  player.rotation.y = 0;
  yaw = 0;
  pitch = 0.42;
  cameraDistance = 5.4;
  if (returnTownButton) returnTownButton.hidden = false;
  if (returnTownDialogButton) returnTownDialogButton.hidden = false;
  locationName.textContent = district.title;
  updateCamera(1);
  camera.updateMatrixWorld(true);
}

function enterBuilding(district) {
  if (activeInterior) return;
  buildInterior(district);
  setPrompt("", "");
  if (district.id === "central-bank") openBank();
}

function exitBuilding() {
  if (!activeInterior) return;
  const district = activeInterior;
  const targetsToRemove = new Set([...interiorCharacters.values()].map((character) => character.hitbox));
  for (let index = clickTargets.length - 1; index >= 0; index -= 1) {
    if (targetsToRemove.has(clickTargets[index].object)) clickTargets.splice(index, 1);
  }
  scene.remove(interiorGroup);
  interiorGroup = null;
  interiorCharacters.clear();
  interiorColliders = [];
  activeInterior = null;
  cityGroup.visible = true;
  employeeGroup.visible = true;
  if (returnTownButton) returnTownButton.hidden = true;
  if (returnTownDialogButton) returnTownDialogButton.hidden = true;
  player.position.set(district.door.x, 0, district.door.z + district.door.direction * 1.8);
  cameraDistance = 34;
  pitch = 0.52;
  locationName.textContent = "AI Money Town";
  updateCamera(1);
  camera.updateMatrixWorld(true);
  setPrompt("", "");
}

function collides(x, z) {
  if (activeInterior) {
    if (Math.abs(x) > 7.15 || Math.abs(z) > 7.15) return true;
    return interiorColliders.some((item) =>
      x + 0.4 > item.minX && x - 0.4 < item.maxX && z + 0.4 > item.minZ && z - 0.4 < item.maxZ,
    );
  }
  if (Math.abs(x) > 161 || Math.abs(z) > 124) return true;
  for (const item of cityColliders) {
    if (item.radius) {
      if (horizontalDistance({ x, z }, item.x, item.z) < item.radius + 0.46) return true;
    } else if (x + 0.45 > item.minX && x - 0.45 < item.maxX && z + 0.45 > item.minZ && z - 0.45 < item.maxZ) {
      return true;
    }
  }
  return false;
}

function showDialog(title, kicker) {
  keyState.clear();
  dialogTitle.textContent = title;
  dialogKicker.textContent = kicker;
  dialogContent.replaceChildren();
  dialogContent.className = "city-dialog-content";
  if (!dialog.open) dialog.showModal();
}

function detailLine(text) {
  const line = document.createElement("p");
  line.className = "detail-line";
  line.textContent = text;
  return line;
}

function statCard(label, value) {
  const card = document.createElement("div");
  card.className = "city-panel-stat";
  const caption = document.createElement("small");
  caption.textContent = label;
  const strong = document.createElement("strong");
  strong.textContent = value;
  card.append(caption, strong);
  return card;
}

function money(cents) {
  return new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format((cents || 0) / 100);
}

async function fetchJson(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.detail || `Town service returned ${response.status}.`);
  return body;
}

async function openEmployee(employeeId) {
  try {
    const [profile, messages] = await Promise.all([
      fetchJson(`/api/employees/${encodeURIComponent(employeeId)}/profile`),
      fetchJson(`/api/employees/${encodeURIComponent(employeeId)}/messages`),
    ]);
    const employee = townState?.employees.find((item) => item.id === employeeId);
    const task = profile.current_project;
    showDialog(`${profile.employee.name} · ${profile.employee.role}`, "YOUR AI TEAMMATE");

    const intro = document.createElement("div");
    intro.className = "employee-chat-intro";
    const introTitle = document.createElement("strong");
    introTitle.textContent = `Talk with ${profile.employee.name}`;
    const introCopy = document.createElement("p");
    introCopy.textContent = profile.employee.specialty || "A member of your AI Money Town team.";
    const introStatus = document.createElement("span");
    introStatus.className = "employee-chat-status";
    const localAi = townState?.ollama;
    introStatus.textContent = localAi?.connected
      ? `READY · ${localAi.models?.length || 0} LOCAL MODEL(S)`
      : "LOCAL AI OFFLINE · START OLLAMA TO CHAT";
    introStatus.classList.toggle("offline", !localAi?.connected);
    intro.append(introTitle, introCopy, introStatus);
    dialogContent.append(intro);

    const summary = document.createElement("div");
    summary.className = "employee-current-work";
    const workLabel = document.createElement("small");
    workLabel.textContent = "CURRENT FOCUS";
    const workTitle = document.createElement("strong");
    workTitle.textContent = task ? task.title : "Available for a new assignment";
    const workMeta = document.createElement("span");
    workMeta.textContent = `${profile.employee.role} · ${districtById.get(employeeBuildings[employeeId])?.title || "Town Hall"}`;
    summary.append(workLabel, workTitle, workMeta);
    dialogContent.append(summary);

    const progress = document.createElement("div");
    progress.className = "city-panel-grid employee-stats";
    progress.append(
      statCard("Tasks completed", `${employee?.completed_task_count || 0} / ${employee?.total_task_count || 0}`),
      statCard("Simulated morale", `${profile.profile.morale}/100`),
      statCard("Experience", `${profile.profile.experience_points} XP · ${profile.profile.career_level}`),
      statCard("Reputation", `${profile.profile.reputation}/100`),
    );
    dialogContent.append(progress);

    const chatPanel = document.createElement("section");
    chatPanel.className = "employee-chat-panel";
    const chatHeader = document.createElement("div");
    chatHeader.className = "employee-chat-heading";
    const chatTitle = document.createElement("strong");
    chatTitle.textContent = "Conversation";
    const chatHint = document.createElement("span");
    chatHint.textContent = "Talk naturally — ask questions or give your teammate an instruction.";
    chatHeader.append(chatTitle, chatHint);
    const conversation = document.createElement("div");
    conversation.className = "city-conversation employee-conversation";
    conversation.setAttribute("aria-live", "polite");
    appendMessages(conversation, messages.slice(-14));

    const quickPrompts = document.createElement("div");
    quickPrompts.className = "employee-quick-prompts";
    for (const prompt of ["What are you working on?", "Share your latest idea", "What do you need from me?"]) {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "employee-prompt-chip";
      chip.textContent = prompt;
      chip.addEventListener("click", () => {
        input.value = prompt;
        input.focus();
      });
      quickPrompts.append(chip);
    }

    const chatForm = document.createElement("form");
    chatForm.className = "employee-chat-composer";
    const input = document.createElement("textarea");
    input.name = "content";
    input.maxLength = 4000;
    input.required = true;
    input.rows = 2;
    input.placeholder = `Message ${profile.employee.name}…`;
    input.setAttribute("aria-label", `Message ${profile.employee.name}`);
    const composerFooter = document.createElement("div");
    composerFooter.className = "employee-composer-footer";
    const hint = document.createElement("small");
    hint.textContent = "Enter to send · Shift + Enter for a new line";
    const send = document.createElement("button");
    send.className = "button button-dark employee-send-button";
    send.type = "submit";
    send.textContent = "Send message  ↗";
    composerFooter.append(hint, send);
    chatForm.append(input, composerFooter);
    chatPanel.append(chatHeader, conversation, quickPrompts, chatForm);
    dialogContent.append(chatPanel);

    const addNotice = (text, className = "employee-chat-notice") => {
      const notice = document.createElement("p");
      notice.className = className;
      notice.textContent = text;
      conversation.append(notice);
      conversation.scrollTop = conversation.scrollHeight;
      return notice;
    };

    input.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && !event.shiftKey) {
        event.preventDefault();
        chatForm.requestSubmit();
      }
    });
    chatForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const content = input.value.trim();
      if (!content || send.disabled) return;
      input.value = "";
      input.disabled = true;
      send.disabled = true;
      send.textContent = "Thinking…";
      appendMessages(conversation, [{ role: "user", content }]);
      const thinking = addNotice(`${profile.employee.name} is thinking…`, "employee-thinking");
      const assistantLine = document.createElement("div");
      assistantLine.className = "city-chat-line assistant";
      const assistantSpeaker = document.createElement("strong");
      assistantSpeaker.textContent = profile.employee.name.toUpperCase();
      const assistantBubble = document.createElement("p");
      assistantBubble.textContent = "";
      assistantLine.append(assistantSpeaker, assistantBubble);
      let receivedAnswer = false;
      try {
        const response = await fetch(`/api/employees/${encodeURIComponent(employeeId)}/messages/stream`, {
          method: "POST",
          headers: { "Content-Type": "application/json", "Accept": "text/event-stream" },
          body: JSON.stringify({ content }),
        });
        if (!response.ok) {
          const problem = await response.json().catch(() => ({}));
          throw new Error(problem.detail || `Town service returned ${response.status}.`);
        }
        if (!response.body) throw new Error("This browser does not support the live chat stream.");
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffered = "";
        let completed = false;
        const handleEvent = (block) => {
          const dataLine = block.split("\n").find((line) => line.startsWith("data:"));
          if (!dataLine) return;
          let packet;
          try { packet = JSON.parse(dataLine.slice(5).trim()); }
          catch { throw new Error("The local AI returned an unreadable chat event."); }
          if (packet.type === "meta") {
            introStatus.textContent = `LIVE LOCAL CONVERSATION · ${packet.model}`;
          } else if (packet.type === "status") {
            thinking.textContent = packet.detail || `${profile.employee.name} is preparing a reply…`;
          } else if (packet.type === "token") {
            if (!receivedAnswer) {
              receivedAnswer = true;
              thinking.remove();
              conversation.append(assistantLine);
            }
            assistantBubble.textContent += packet.content || "";
            conversation.scrollTop = conversation.scrollHeight;
          } else if (packet.type === "error") {
            throw new Error(packet.detail || "The local AI could not respond.");
          } else if (packet.type === "done") {
            completed = true;
          }
        };
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          buffered += decoder.decode(value, { stream: true });
          const blocks = buffered.split("\n\n");
          buffered = blocks.pop() || "";
          for (const block of blocks) handleEvent(block);
        }
        buffered += decoder.decode();
        if (buffered.trim()) handleEvent(buffered);
        if (!completed) throw new Error("The chat stream ended before the teammate finished replying.");
        if (!receivedAnswer) throw new Error("The local model finished without returning any answer text.");
        await syncTown();
      } catch (error) {
        thinking.remove();
        if (receivedAnswer) assistantLine.classList.add("employee-chat-error");
        const detail = error.message || "The local AI could not respond.";
        const friendly = detail.toLowerCase().includes("ollama") || detail.toLowerCase().includes("connection refused")
          ? "I can't reach Ollama on this computer. Open Ollama, check that a chat model is installed, then try again."
          : detail.toLowerCase().includes("model") && detail.toLowerCase().includes("not found")
            ? "That model is not available in Ollama. Install qwen3.5:0.8b or choose another installed chat model."
            : `I couldn't get a reply: ${detail}`;
        addNotice(friendly, "employee-chat-error");
      } finally {
        input.disabled = false;
        send.disabled = false;
        send.textContent = "Send message  ↗";
        input.focus();
      }
    });

    const achievementsHeading = document.createElement("h3");
    achievementsHeading.textContent = "Recent recognition";
    dialogContent.append(achievementsHeading);
    input.focus({ preventScroll: true });
    if (!profile.achievements.length) dialogContent.append(detailLine("No achievements recorded yet. Your teammate is ready to build their first one."));
    for (const achievement of profile.achievements.slice(0, 5)) {
      dialogContent.append(detailLine(`${achievement.badge} · ${achievement.trophy} · +${achievement.experience_points} XP`));
    }
  } catch (error) {
    showDialog("Employee profile unavailable", "TOWN API ERROR");
    dialogContent.append(detailLine(error.message));
  }
}

function appendMessages(parent, messages) {
  if (!messages.length) {
    const empty = document.createElement("p");
    empty.className = "employee-chat-empty";
    empty.textContent = "No messages yet. Say hello and start a conversation.";
    parent.append(empty);
    return;
  }
  for (const message of messages) {
    const line = document.createElement("div");
    line.className = `city-chat-line ${message.role === "user" ? "user" : "assistant"}`;
    const speaker = document.createElement("strong");
    speaker.textContent = message.role === "user" ? "YOU" : "TEAMMATE";
    const bubble = document.createElement("p");
    bubble.textContent = message.content;
    line.append(speaker, bubble);
    parent.append(line);
  }
  parent.scrollTop = parent.scrollHeight;
}
function openMayor() {
  if (!townState) return;
  const manager = townState.employees.find((employee) =>
    employee.id === "town-manager" || employee.role.toLowerCase().includes("town manager"),
  );
  if (!manager) {
    showDialog("Mayor unavailable", "EMPLOYEE RECORD MISSING");
    dialogContent.append(detailLine("No Town Manager employee record is available from the backend."));
    return;
  }
  showDialog(`${manager.name} · Mayor's Office`, "TOWN HALL · PORTFOLIO REPORT");
  const businesses = townState.businesses;
  const operating = businesses.filter((business) =>
    ["live_business", "growing", "stable"].includes(business.stage),
  );
  const declines = businesses.filter((business) =>
    ["declining", "revival", "temporarily_dormant"].includes(business.stage),
  );
  const verifiedProfitable = businesses.filter((business) => business.verified_profit_cents > 0);
  const cells = document.createElement("div");
  cells.className = "city-panel-grid";
  cells.append(
    statCard("Operating businesses", String(operating.length)),
    statCard("Declining / revival", String(declines.length)),
    statCard("Verified-positive businesses", String(verifiedProfitable.length)),
    statCard("Available ledger funds", money(townState.treasury.available_business_funds_cents)),
    statCard("Verified ledger revenue", money(townState.treasury.actual_revenue_cents)),
    statCard("Pending payments", money(townState.treasury.pending_payments_cents)),
  );
  dialogContent.append(cells);
  const projectsTitle = document.createElement("h3");
  projectsTitle.textContent = "Business portfolio";
  dialogContent.append(projectsTitle);
  if (!businesses.length) dialogContent.append(detailLine("No approved businesses are in the portfolio yet."));
  for (const business of businesses.slice(0, 8)) {
    dialogContent.append(detailLine(`${business.title} · ${business.stage.replaceAll("_", " ")} · Verified profit ${money(business.verified_profit_cents)} · simulated estimates excluded`));
  }
  const staffHeading = document.createElement("h3");
  staffHeading.textContent = "Employee workload and performance";
  dialogContent.append(staffHeading);
  for (const employee of townState.employees) {
    const task = employee.current_task;
    dialogContent.append(detailLine(`${employee.name} · ${task ? `${task.status.replaceAll("_", " ")}: ${task.title}` : "No current task"} · ${employee.completed_task_count}/${employee.total_task_count} tasks completed · simulated morale ${employee.morale}/100`));
  }
  if (townState.latest_report) {
    const report = townState.latest_report.content;
    const heading = document.createElement("h3");
    heading.textContent = "Latest Mayor report";
    dialogContent.append(heading);
    const reportLine = report.declines_detected?.length
      ? report.declines_detected.map((item) => item.reason).join(" ")
      : "No decline detected in the latest recorded portfolio review.";
    dialogContent.append(detailLine(`${reportLine} Actual ledger revenue ${money(report.actual_revenue_cents)}. Available funds ${money(report.available_business_funds_cents)}.`));
  }
  const priorityHeading = document.createElement("h3");
  priorityHeading.textContent = "Give the Mayor an instruction";
  dialogContent.append(priorityHeading);
  const instructionForm = document.createElement("form");
  instructionForm.className = "inline-form";
  const instruction = document.createElement("input");
  instruction.required = true;
  instruction.maxLength = 160;
  instruction.placeholder = "Describe a town priority to queue…";
  const submit = document.createElement("button");
  submit.type = "submit";
  submit.className = "button button-dark";
  submit.textContent = "Queue instruction";
  instructionForm.append(instruction, submit);
  instructionForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    submit.disabled = true;
    try {
      await fetchJson("/api/tasks", {
        method: "POST",
        body: JSON.stringify({
          title: `Mayor instruction: ${instruction.value.trim()}`,
          description: "Owner-provided priority queued for the Town Manager in the persistent task board.",
          employee_id: manager.id,
        }),
      });
      await syncTown();
      openMayor();
    } catch (error) {
      dialogContent.append(detailLine(`Instruction was not queued: ${error.message}`));
    } finally {
      submit.disabled = false;
    }
  });
  dialogContent.append(instructionForm, detailLine("The instruction is saved as a real Town Manager task. The Mayor does not claim it is completed until the backend records completion."));
}

function openBank() {
  if (!townState) return;
  const finance = townState.treasury;
  showDialog("Central Bank & Treasury", "VIRTUAL ACCOUNTING LEDGER");
  const grid = document.createElement("div");
  grid.className = "city-panel-grid";
  for (const [label, value] of [
    ["Verified earnings", money(finance.actual_revenue_cents)],
    ["Settled payments", money(finance.settled_payments_cents)],
    ["Pending payments", money(finance.pending_payments_cents)],
    ["Expenses", money(finance.expenses_cents)],
    ["Reinvestment", money(finance.reinvestment_cents)],
    ["Profit", money(finance.profit_cents)],
    ["Available funds", money(finance.available_business_funds_cents)],
    ["Withdrawal requests", money(finance.withdrawal_requests_cents)],
  ]) grid.append(statCard(label, value));
  dialogContent.append(
    grid,
    detailLine(`Estimated revenue: ${money(finance.estimated_revenue_cents)} · Simulation only; never included in the ledger balance.`),
  );
  const note = document.createElement("p");
  note.className = "city-bank-note";
  note.textContent = "This is the existing SQLite virtual ledger, not a bank account. Settlements require owner reconciliation and evidence. Withdrawal integration is disabled; no transfer can occur here.";
  dialogContent.append(note);
  const dashboardLink = document.createElement("a");
  dashboardLink.href = "#treasury";
  dashboardLink.className = "button button-outline";
  dashboardLink.textContent = "Open treasury controls in dashboard";
  dashboardLink.addEventListener("click", () => {
    dialog.close();
    showDashboard("#treasury");
  });
  dialogContent.append(dashboardLink);
}

function openBuilding(district) {
  enterBuilding(district);
}

function interactEmployee(employee) {
  // The Mayor is an employee too: approaching or clicking Avery opens the same
  // real conversation UI instead of trapping the owner in a read-only report.
  openEmployee(employee.id);
}

function pickTarget(event) {
  const bounds = renderer.domElement.getBoundingClientRect();
  pointer.x = ((event.clientX - bounds.left) / bounds.width) * 2 - 1;
  pointer.y = -((event.clientY - bounds.top) / bounds.height) * 2 + 1;
  raycaster.setFromCamera(pointer, camera);
  const targets = clickTargets.map((target) => target.object);
  const hit = raycaster.intersectObjects(targets, false)[0];
  if (!hit) return false;
  const target = clickTargets.find((item) => item.object === hit.object);
  if (!target) return false;
  if (target.type === "employee") {
    const employee = townState?.employees.find((item) => item.id === target.employeeId);
    if (employee) interactEmployee(employee);
  }
  else openBuilding(districtById.get(target.districtId));
  return true;
}

function movementInput(delta) {
  if ($("#city-screen").hidden || dialog.open) {
    keyState.clear();
    playerIsMoving = false;
    return;
  }
  const forward = Number(keyState.has("KeyW") || keyState.has("ArrowUp"))
    - Number(keyState.has("KeyS") || keyState.has("ArrowDown"));
  const strafe = Number(keyState.has("KeyD") || keyState.has("ArrowRight"))
    - Number(keyState.has("KeyA") || keyState.has("ArrowLeft"));
  if (!forward && !strafe) {
    playerIsMoving = false;
    playerLegs.forEach((leg) => { leg.rotation.x *= 0.72; });
    playerArms.forEach((arm) => { arm.rotation.x *= 0.72; });
    return;
  }

  const magnitude = Math.hypot(forward, strafe) || 1;
  const f = forward / magnitude;
  const r = strafe / magnitude;
  const speed = 8.2 * (keyState.has("ShiftLeft") || keyState.has("ShiftRight") ? 1.55 : 1);
  // Use the live orbit yaw rather than the camera's interpolated matrix. WASD
  // therefore changes direction immediately as the player rotates the camera.
  movementForward.set(-Math.sin(yaw), 0, -Math.cos(yaw)).normalize();
  movementRight.set(Math.cos(yaw), 0, -Math.sin(yaw)).normalize();
  const dx = (movementForward.x * f + movementRight.x * r) * delta * speed;
  const dz = (movementForward.z * f + movementRight.z * r) * delta * speed;
  const distance = Math.hypot(dx, dz);
  const steps = Math.max(1, Math.ceil(distance / 0.18));
  const stepX = dx / steps;
  const stepZ = dz / steps;

  // Substeps prevent tunnelling through narrow colliders; axis sliding keeps controls forgiving.
  for (let index = 0; index < steps; index += 1) {
    const nextX = player.position.x + stepX;
    if (!collides(nextX, player.position.z)) player.position.x = nextX;
    const nextZ = player.position.z + stepZ;
    if (!collides(player.position.x, nextZ)) player.position.z = nextZ;
  }
  const desiredFacing = Math.atan2(-dx, -dz);
  const facingDelta = Math.atan2(Math.sin(desiredFacing - player.rotation.y), Math.cos(desiredFacing - player.rotation.y));
  player.rotation.y += facingDelta * Math.min(1, delta * 13);
  playerIsMoving = true;
  playerWalkPhase += delta * 11;
  const swing = Math.sin(playerWalkPhase) * 0.62;
  playerLegs[0].rotation.x = swing;
  playerLegs[1].rotation.x = -swing;
  playerArms[0].rotation.x = -swing * 0.48;
  playerArms[1].rotation.x = swing * 0.48;
}
function updateCamera(delta) {
  const inside = Boolean(activeInterior);
  // Long look-ahead is suitable for the outdoor valley but wrong indoors:
  // it points through a wall. Use a compact camera fully inside the room.
  const lookAhead = inside ? 2.2 : 24;
  const followDistance = inside ? 5.4 : cameraDistance;
  const target = new THREE.Vector3(
    player.position.x - Math.sin(yaw) * lookAhead,
    player.position.y + (inside ? 2.0 : 3.0),
    player.position.z - Math.cos(yaw) * lookAhead,
  );
  const horizontalDistance = followDistance * Math.cos(pitch);
  const desired = new THREE.Vector3(
    player.position.x + Math.sin(yaw) * horizontalDistance,
    player.position.y + 2.1 + followDistance * Math.sin(pitch),
    player.position.z + Math.cos(yaw) * horizontalDistance,
  );
  if (inside) {
    desired.x = THREE.MathUtils.clamp(desired.x, -7.1, 7.1);
    desired.z = THREE.MathUtils.clamp(desired.z, -7.1, 7.1);
    desired.y = THREE.MathUtils.clamp(desired.y, 1.65, 5.15);
  }
  camera.position.lerp(desired, 1 - Math.exp(-delta * 7.5));
  camera.lookAt(target);
}

let lastWorldStatus = "";
function updateWorldStatus() {
  const element = $("#city-render-status");
  if (!element) return;
  const draws = renderer.info.render.calls;
  const visible = cityGroup.visible && cityGroup.children.length > 0;
  const label = activeInterior
    ? `Inside ${activeInterior.title} · ${interiorGroup?.children.length || 0} interior objects · ${draws} draw calls`
    : visible && draws > 0
      ? `World visible · ${cityGroup.children.length} scene groups · ${draws} draw calls`
      : `World not rendering · ${cityGroup.children.length} scene groups · ${draws} draw calls`;
  if (label !== lastWorldStatus) {
    element.textContent = label;
    element.dataset.state = visible && draws > 0 ? "ready" : "warning";
    lastWorldStatus = label;
  }
}

function resetTownView() {
  if (activeInterior) exitBuilding();
  keyState.clear();
  player.position.set(0, 0, 32);
  player.rotation.y = 0;
  yaw = 0;
  pitch = 0.55;
  cameraDistance = 44;
  if (returnTownButton) returnTownButton.hidden = true;
  if (returnTownDialogButton) returnTownDialogButton.hidden = true;
  cityGroup.visible = true;
  employeeGroup.visible = true;
  player.visible = true;
  updateCamera(1);
  camera.updateMatrixWorld(true);
  renderer.render(scene, camera);
  updateWorldStatus();
}

function updateDayNight(elapsed) {
  const phase = ((elapsed / 900) % 1) * Math.PI * 2 + Math.PI / 2;
  const daylight = THREE.MathUtils.clamp((Math.sin(phase) + 0.12) / 1.12, 0.12, 1);
  const daySky = new THREE.Color(0xa9d9ec);
  const nightSky = new THREE.Color(0x28364c);
  scene.background.copy(nightSky).lerp(daySky, daylight);
  scene.fog.color.copy(scene.background);
  hemiLight.intensity = 0.36 + daylight * 0.92;
  sun.intensity = 0.18 + daylight * 2.2;
  sun.color.set(daylight < 0.32 ? 0xff9f68 : 0xffedc4);
  windowMaterial.emissiveIntensity = 0.04 + (1 - daylight) * 0.5;
}

function animate() {
  if (disposed) return;
  const delta = Math.min(clock.getDelta(), 0.05);
  simulationElapsed += delta;
  minimapElapsed += delta;
  const now = performance.now();
  if (!$("#city-screen").hidden) {
    // Recover from a stale visibility flag instead of leaving a blue viewport.
    if (!activeInterior && (!cityGroup.visible || !employeeGroup.visible)) {
      cityGroup.visible = true;
      employeeGroup.visible = true;
    }
    movementInput(delta);
    updateCamera(delta);
    for (const character of employeeCharacters.values()) animateCharacter(character, delta, now);
    for (const character of interiorCharacters.values()) animateCharacter(character, delta, now);
    updateDayNight(simulationElapsed);
    updatePrompt();
    if (minimapElapsed >= 0.16) { minimapElapsed = 0; drawMinimap(); }
    try {
      renderer.render(scene, camera);
      updateWorldStatus();
    } catch (error) {
      disposed = true;
      loadingElement.hidden = true;
      errorElement.hidden = false;
      errorElement.textContent = `The 3D renderer stopped: ${error.message}. Try Graphics: Low, then reload the town.`;
      return;
    }
  }
  syncTimer += delta;
  if (syncTimer >= 8) {
    syncTimer = 0;
    void syncTown();
  }
  requestAnimationFrame(animate);
}

function updateHud(state) {
  const queued = state.tasks.pending || 0;
  const running = state.tasks.in_progress || 0;
  const active = queued + running;
  const operating = state.businesses.filter((business) =>
    ["live_business", "growing", "stable"].includes(business.stage),
  ).length;
  metricsElement.replaceChildren();
  for (const [value, label] of [
    [String(state.employees.length), "employees"],
    [String(running), `working · ${queued} queued`],
    [String(state.businesses.length), "businesses"],
    [money(state.treasury.available_business_funds_cents), "available funds"],
  ]) {
    const metric = document.createElement("div");
    metric.className = "city-metric";
    const strong = document.createElement("strong");
    strong.textContent = value;
    const small = document.createElement("small");
    small.textContent = label;
    metric.append(strong, small);
    metricsElement.append(metric);
  }
  const chatModels = (state.ollama?.models || []).filter((model) => !/embed|coder|code/i.test(model));
  const aiLabel = state.ollama?.connected && chatModels.length
    ? `AI ready · ${chatModels.length} chat model(s)`
    : "AI offline · start Ollama";
  syncStatus.textContent = `Live town data · ${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} · ${operating} operating · ${aiLabel}`;
  $(".city-live-dot").classList.toggle("offline", !state.ollama?.connected);
  loadingElement.hidden = true;
  errorElement.hidden = true;
}

async function syncTown() {
  if (syncInFlight) return;
  syncInFlight = true;
  try {
    const state = await fetchJson("/api/city/state");
    townState = state;
    updateCharacters(state.employees);
    if (activeInterior) {
      for (const employee of state.employees) {
        const character = interiorCharacters.get(employee.id);
        if (character) character.employee = employee;
      }
    }
    if (state.latest_discussion && state.latest_discussion.id > latestDiscussionId) {
      latestDiscussionId = state.latest_discussion.id;
      discussionWindow = {
        ...state.latest_discussion,
        until: performance.now() + 8500,
      };
    }
    updateHud(state);
  } catch (error) {
    syncStatus.textContent = townState ? "Town API unavailable · showing last saved snapshot" : "Could not connect to town API";
    $(".city-live-dot").classList.add("offline");
    errorElement.hidden = false;
    errorElement.textContent = townState
      ? `Live connection lost: ${error.message}. The town is showing its last backend snapshot; it is not being updated.`
      : `Could not load live town data: ${error.message}. Start the FastAPI server and refresh the page.`;
    loadingElement.hidden = true;
  } finally {
    syncInFlight = false;
  }
}

function showDashboard(anchor = "#overview") {
  $("#city-screen").hidden = true;
  $("#overview").hidden = false;
  for (const link of document.querySelectorAll(".nav-link")) {
    link.classList.toggle("active", link.dataset.screen === "dashboard" ||
      (!link.dataset.screen && link.getAttribute("href") === anchor));
  }
  const target = document.querySelector(anchor);
  target?.scrollIntoView({ behavior: "smooth", block: "start" });
}

$("#city-dialog-close").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", (event) => {
  if (event.target === dialog) dialog.close();
});
$("#graphics-quality").addEventListener("change", (event) => setGraphics(event.currentTarget.value));
$("#city-recenter")?.addEventListener("click", resetTownView);
const zoomInButton = $("#city-zoom-in");
const zoomOutButton = $("#city-zoom-out");
function changeTownZoom(direction) {
  if (activeInterior) return;
  // The camera follows the player; a shorter distance zooms in.
  cameraDistance = THREE.MathUtils.clamp(cameraDistance + direction * 5, 16, 72);
  updateCamera(1);
}
zoomInButton?.addEventListener("click", () => changeTownZoom(-1));
zoomOutButton?.addEventListener("click", () => changeTownZoom(1));
returnTownButton?.addEventListener("click", () => {
  if (dialog.open) dialog.close();
  exitBuilding();
});
returnTownDialogButton?.addEventListener("click", () => {
  if (dialog.open) dialog.close();
  exitBuilding();
});
renderer.domElement.tabIndex = 0;
renderer.domElement.style.touchAction = "none";
dialog.addEventListener("close", () => renderer.domElement.focus({ preventScroll: true }));
renderer.domElement.addEventListener("contextmenu", (event) => event.preventDefault());
renderer.domElement.addEventListener("pointerdown", (event) => {
  if (event.button !== 0 && event.button !== 2) return;
  renderer.domElement.focus({ preventScroll: true });
  pointerDown = { id: event.pointerId, x: event.clientX, y: event.clientY, dragged: false };
  try { renderer.domElement.setPointerCapture(event.pointerId); } catch { /* capture is optional on older browsers */ }
});
renderer.domElement.addEventListener("pointermove", (event) => {
  if (!pointerDown || pointerDown.id !== event.pointerId) return;
  const dx = event.clientX - pointerDown.x;
  const dy = event.clientY - pointerDown.y;
  if (Math.abs(dx) + Math.abs(dy) > 3) pointerDown.dragged = true;
  if (pointerDown.dragged) {
    yaw -= dx * 0.0052;
    pitch = THREE.MathUtils.clamp(pitch - dy * 0.0038, 0.24, 0.78);
  }
  pointerDown.x = event.clientX;
  pointerDown.y = event.clientY;
});
renderer.domElement.addEventListener("pointerup", (event) => {
  if (!pointerDown || pointerDown.id !== event.pointerId) return;
  const wasDragged = pointerDown.dragged;
  pointerDown = null;
  if (!wasDragged && event.button === 0) pickTarget(event);
  try { renderer.domElement.releasePointerCapture(event.pointerId); } catch { /* already released */ }
});
renderer.domElement.addEventListener("lostpointercapture", () => { pointerDown = null; });
renderer.domElement.addEventListener("pointercancel", () => { pointerDown = null; });
renderer.domElement.addEventListener("wheel", (event) => {
  if (!activeInterior) cameraDistance = THREE.MathUtils.clamp(cameraDistance + event.deltaY * 0.035, 16, 72);
  event.preventDefault();
}, { passive: false });
window.addEventListener("resize", resize);
if (typeof ResizeObserver !== "undefined") {
  const cityResizeObserver = new ResizeObserver(() => resize());
  cityResizeObserver.observe(viewport);
}
new MutationObserver(() => {
  if (!$("#city-screen").hidden) resize();
}).observe($("#city-screen"), { attributes: true, attributeFilter: ["hidden"] });
const movementKeyCodes = new Set([
  "KeyW", "KeyA", "KeyS", "KeyD",
  "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight",
  "ShiftLeft", "ShiftRight",
]);
function isTextEntry(target) {
  return Boolean(target?.closest?.('input, textarea, select, [contenteditable="true"], [role="textbox"]'));
}
function clearMovementKeys() {
  keyState.clear();
  playerIsMoving = false;
}
window.addEventListener("blur", clearMovementKeys);
document.addEventListener("visibilitychange", () => {
  if (document.hidden) clearMovementKeys();
});
window.addEventListener("keydown", (event) => {
  if ($("#city-screen").hidden || dialog.open || isTextEntry(event.target) || isTextEntry(document.activeElement)) return;
  if (movementKeyCodes.has(event.code)) {
    event.preventDefault();
    keyState.add(event.code);
    return;
  }
  if (event.repeat) return;
  if (event.code === "KeyE") {
    event.preventDefault();
    const employee = nearestEmployee();
    if (employee) interactEmployee(employee);
    else if (activeInterior?.id === "central-bank") openBank();
    else if (activeInterior) exitBuilding();
  } else if (event.code === "KeyF") {
    event.preventDefault();
    if (activeInterior) exitBuilding();
    else {
      const door = nearestDoor();
      if (door) openBuilding(door);
    }
  } else if (event.code === "Escape" && activeInterior) {
    exitBuilding();
  }
});
window.addEventListener("keyup", (event) => keyState.delete(event.code));
try {
  const storedQuality = localStorage.getItem("ai-money-town-graphics");
  setGraphics(["low", "medium", "high"].includes(storedQuality) ? storedQuality : "low");
  $("#graphics-quality").value = quality;
  buildWorld();
  cityGroup.visible = true;
  employeeGroup.visible = true;
  player.visible = true;
  resize();
  updateCamera(1);
  camera.updateMatrixWorld(true);
  renderer.render(scene, camera);
  updateWorldStatus();
  void syncTown();
  requestAnimationFrame(animate);
} catch (error) {
  errorElement.hidden = false;
  errorElement.textContent = `The 3D town could not start: ${error.message}. The existing dashboard remains available.`;
  loadingElement.hidden = true;
}

function releaseCity() {
  disposed = true;
  renderer.dispose();
}
window.addEventListener("pagehide", releaseCity, { once: true });

// Exposed for the existing dashboard link in the town's bank and side navigation.
window.showTownDashboard = showDashboard;
window.__AMT_TOWN_DIAGNOSTICS = () => ({
  worldVisible: cityGroup.visible,
  worldObjects: cityGroup.children.length,
  employeesVisible: employeeGroup.visible,
  employees: employeeGroup.children.length,
  insideBuilding: activeInterior?.title || null,
  interiorObjects: interiorGroup?.children.length || 0,
  playerPosition: player.position.toArray(),
  cameraPosition: camera.position.toArray(),
  drawCalls: renderer.info.render.calls,
  triangles: renderer.info.render.triangles,
});
window.__AMT_TOWN_RETURN_OUTSIDE = () => {
  if (activeInterior) exitBuilding();
  else resetTownView();
};

// Temporary visual diagnostics: inspect actual visible meshes and add a magenta
// camera-centred probe to distinguish a scene-content issue from a renderer issue.
window.__AMT_TOWN_VISUAL_AUDIT = () => {
  const V = camera.position.constructor;
  scene.updateMatrixWorld(true);
  cityGroup.updateMatrixWorld(true);
  employeeGroup.updateMatrixWorld(true);
  camera.updateMatrixWorld(true);
  const report = { totalMeshes: 0, visibleMeshes: 0, meshesInFront: 0, meshCentersInFrame: 0,
    transparentMeshes: 0, zeroOpacityMeshes: 0, colorWriteDisabled: 0, materialHidden: 0, samples: [],
    camera: { position: camera.position.toArray(), direction: camera.getWorldDirection(new THREE.Vector3()).toArray(),
      near: camera.near, far: camera.far, fov: camera.fov, aspect: camera.aspect },
    world: { visible: cityGroup.visible, position: cityGroup.position.toArray(), scale: cityGroup.scale.toArray(), children: cityGroup.children.length } };
  cityGroup.traverse((object) => {
    if (!object.isMesh && !object.isSprite) return;
    if (object.isMesh) report.totalMeshes += 1;
    let ancestor = object;
    let chainVisible = true;
    while (ancestor) { if (ancestor.visible === false) chainVisible = false; ancestor = ancestor.parent; }
    if (!chainVisible) return;
    report.visibleMeshes += 1;
    const materials = Array.isArray(object.material) ? object.material : [object.material];
    for (const material of materials) {
      if (!material) continue;
      if (material.transparent) report.transparentMeshes += 1;
      if (material.opacity === 0) report.zeroOpacityMeshes += 1;
      if (material.colorWrite === false) report.colorWriteDisabled += 1;
      if (material.visible === false) report.materialHidden += 1;
    }
    const position = object.getWorldPosition(new V());
    const ndc = position.clone().project(camera);
    const inFront = ndc.z >= -1 && ndc.z <= 1;
    if (inFront) report.meshesInFront += 1;
    if (inFront && Math.abs(ndc.x) <= 1 && Math.abs(ndc.y) <= 1 && report.samples.length < 30) {
      const material = materials[0];
      report.meshCentersInFrame += 1;
      report.samples.push({ name: object.name || object.type, geometry: object.geometry?.type || object.type,
        position: position.toArray().map((n) => +n.toFixed(2)), ndc: ndc.toArray().map((n) => +n.toFixed(3)),
        material: material ? { type: material.type, visible: material.visible, transparent: material.transparent,
          opacity: material.opacity, color: material.color?.getHexString?.(), side: material.side, colorWrite: material.colorWrite } : null });
    }
  });
  return report;
};

