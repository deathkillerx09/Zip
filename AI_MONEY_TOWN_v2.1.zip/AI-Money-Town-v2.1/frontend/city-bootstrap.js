/*
 * Load the single bundled Three.js world and provide a visible fallback if WebGL
 * cannot start. Do not probe with a throwaway WebGL canvas first: creating and
 * immediately losing a context can exhaust or delay context allocation on some
 * integrated GPUs. Three.js itself performs the authoritative WebGL2 check.
 */
(() => {
  "use strict";
  const loading = document.querySelector("#city-loading");
  const errorPanel = document.querySelector("#city-error");
  const cityScreen = document.querySelector("#city-screen");
  const overview = document.querySelector("#overview");

  function showFallback(message) {
    if (loading) loading.hidden = true;
    if (!errorPanel) return;
    errorPanel.replaceChildren(document.createTextNode(message));
    const details = document.createElement("p");
    details.className = "city-fallback-help";
    details.textContent = "In Chrome, open Settings → System and turn on graphics acceleration, then relaunch the browser. You can still use the dashboard while 3D graphics are unavailable.";
    errorPanel.append(details);
    const button = document.createElement("button");
    button.type = "button";
    button.className = "button button-dark city-fallback-button";
    button.textContent = "Open dashboard";
    button.addEventListener("click", () => {
      if (cityScreen) cityScreen.hidden = true;
      if (overview) { overview.hidden = false; overview.scrollIntoView({ behavior: "smooth", block: "start" }); }
      document.querySelectorAll(".nav-link").forEach((link) => link.classList.toggle("active", link.dataset.screen === "dashboard"));
    });
    errorPanel.append(button);
    errorPanel.hidden = false;
  }

  let use3d = false;
  try { use3d = localStorage.getItem("ai-money-town-renderer") === "3d"; } catch (_) { use3d = false; }
  if (!use3d) {
    // The supported town is the isometric Canvas renderer. The bundled Three.js
    // scene stays available as an opt-in experiment but is not downloaded or
    // rendered by default, which keeps CPU and GPU load low on integrated graphics.
    if (loading) loading.hidden = true;
    return;
  }

  let moduleLoaded = false;
  window.addEventListener("error", (event) => {
    const isCityModule = typeof event.filename === "string" && event.filename.includes("/static/city.bundle.js");
    if (isCityModule || (loading && !loading.hidden)) showFallback(event.message || "The 3D town could not start.");
  }, true);
  window.addEventListener("unhandledrejection", (event) => {
    if (loading && !loading.hidden) {
      const reason = event.reason;
      showFallback(reason instanceof Error ? reason.message : "The 3D town failed during startup.");
    }
  });

  const cityModule = document.createElement("script");
  cityModule.type = "module";
  cityModule.src = "/static/city.bundle.js?v=queue-status-fix-20261125a";
  cityModule.addEventListener("load", () => { moduleLoaded = true; }, { once: true });
  cityModule.addEventListener("error", () => {
    showFallback("The 3D city module could not be loaded. Check /static/city.bundle.js and refresh.");
  }, { once: true });
  document.body.append(cityModule);
  window.setTimeout(() => {
    if (!moduleLoaded && loading && !loading.hidden && (!errorPanel || errorPanel.hidden)) {
      showFallback("The 3D city is taking too long to start. Try Graphics: Low, then refresh. If it still fails, check Chrome's WebGL/hardware-acceleration settings.");
    }
  }, 15000);
})();
