# Generated product files

The Product Builder writes every validated deliverable here, one folder per
deliverable:

```
workspace/products/business-<business id>-<slug>-<deliverable id>/
  index.html       the generated, validated application
  manifest.json    business, task, model, files, checksums and the validation report
```

Nothing here is published. A file is only written after it passed the automated
validation checks (structure, offline-only assets, no placeholders, interactive
elements, JavaScript syntax). Invalid model output produces a recorded failure
instead of a file.

You can open any file directly in a browser, or use the **Open product** /
**Download file** links in the Business Empire dialog (served through
`/api/deliverables/<id>/preview` with a sandbox CSP).
