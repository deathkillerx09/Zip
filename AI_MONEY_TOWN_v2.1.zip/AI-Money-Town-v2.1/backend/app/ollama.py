from __future__ import annotations

import json
import os
import socket
import time
from collections.abc import Iterator
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen


class OllamaError(Exception):
    """Raised when the local Ollama service cannot fulfill a request.

    ``kind`` lets callers separate a temporary problem (retry later) from a
    permanent one (bad model, malformed response) instead of guessing.
    """

    def __init__(self, message: str, *, kind: str = "unavailable", retryable: bool = True):
        super().__init__(message)
        self.kind = kind
        self.retryable = retryable


# Model preference per work category. A tiny model is fine for short chat replies,
# but product/document work benefits from a larger one when it is installed.
CATEGORY_MODEL_ENV = {
    "chat": "OLLAMA_CHAT_MODEL",
    "ideas": "OLLAMA_IDEA_MODEL",
    "research": "OLLAMA_MODEL_RESEARCH",
    "strategy": "OLLAMA_MODEL_STRATEGY",
    "product": "OLLAMA_MODEL_PRODUCT",
    "finance": "OLLAMA_MODEL_FINANCE",
    "quality": "OLLAMA_MODEL_QUALITY",
    "general": "OLLAMA_WORKER_MODEL",
}


def select_chat_model(models: list[str], configured: str | None = None) -> str | None:
    """Choose a small conversational model, never an embedding or code-only model."""
    available = set(models)
    if configured and configured in available and not any(tag in configured.lower() for tag in ("embed", "coder", "code")):
        return configured
    for candidate in (
        "qwen3.5:0.8b",
        "llama3.2:1b",
        "gemma2:2b",
        "qwen3:4b",
        "llama3.2:3b",
    ):
        if candidate in available:
            return candidate
    return next((model for model in models if not any(tag in model.lower() for tag in ("embed", "coder", "code"))), None)


def select_work_model(models: list[str], category: str = "general") -> str | None:
    """Prefer a category-specific model, then any configured worker model, then chat."""
    configured = (
        os.getenv(CATEGORY_MODEL_ENV.get(category, ""), "").strip()
        or os.getenv("OLLAMA_WORKER_MODEL", "").strip()
    )
    if configured and configured in set(models):
        return configured
    if configured:
        # Configured but not installed: fall back rather than failing the whole task,
        # and let the caller record which model actually ran.
        pass
    return select_chat_model(models, os.getenv("OLLAMA_CHAT_MODEL"))


def extract_json_payload(content: str):
    """Pull the first JSON object or array out of a model reply.

    Small local models wrap JSON in prose or code fences; this never invents
    data — it only locates an existing payload.
    """
    text = (content or "").strip()
    if text.startswith("```"):
        lines = [line for line in text.splitlines() if not line.strip().startswith("```")]
        text = "\n".join(lines).strip()
    for opener, closer in (("[", "]"), ("{", "}")):
        start = text.find(opener)
        end = text.rfind(closer)
        if start >= 0 and end > start:
            try:
                return json.loads(text[start:end + 1])
            except json.JSONDecodeError:
                continue
    return None


class OllamaClient:
    def __init__(self, base_url: str = "http://127.0.0.1:11434", timeout: float = 55.0):
        parsed = urlparse(base_url)
        local_hosts = {"127.0.0.1", "localhost", "::1"}
        allow_remote = os.getenv("AI_MONEY_TOWN_ALLOW_REMOTE_OLLAMA", "").strip().lower() in {"1", "true", "yes"}
        if parsed.scheme != "http":
            raise ValueError("Ollama must use an HTTP URL.")
        if parsed.hostname not in local_hosts and not allow_remote:
            raise ValueError(
                "Ollama must use a local HTTP URL (localhost or 127.0.0.1). "
                "Set AI_MONEY_TOWN_ALLOW_REMOTE_OLLAMA=1 only inside a private container network."
            )
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.last_error: str | None = None
        self.last_call_seconds: float | None = None
        self.last_model: str | None = None

    def _request(self, path: str, payload: dict | None = None) -> dict:
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        request = Request(
            f"{self.base_url}{path}",
            data=data,
            headers={"Content-Type": "application/json"},
            method="GET" if payload is None else "POST",
        )
        started = time.monotonic()
        try:
            with urlopen(request, timeout=self.timeout) as response:
                body = response.read().decode("utf-8")
        except HTTPError as error:
            detail = ""
            try:
                detail = error.read().decode("utf-8", "replace")[:400]
            except Exception:  # pragma: no cover - best-effort diagnostics only
                detail = ""
            self.last_error = f"HTTP {error.code}: {detail or error.reason}"
            raise OllamaError(
                f"Local Ollama returned HTTP {error.code}. {detail}".strip(),
                kind="http_error",
                retryable=error.code >= 500,
            ) from error
        except (socket.timeout, TimeoutError) as error:
            self.last_error = f"Timeout after {self.timeout:.0f}s"
            raise OllamaError(
                f"Local Ollama did not answer within {self.timeout:.0f}s. "
                "The model may be too large for this laptop; try a smaller model or raise OLLAMA_TIMEOUT_SECONDS.",
                kind="timeout",
                retryable=True,
            ) from error
        except (URLError, OSError) as error:
            self.last_error = str(error)
            raise OllamaError(
                f"Cannot reach local Ollama at {self.base_url}. Is it running? ({error})",
                kind="offline",
                retryable=True,
            ) from error
        finally:
            self.last_call_seconds = round(time.monotonic() - started, 2)
        try:
            return json.loads(body)
        except json.JSONDecodeError as error:
            self.last_error = "Invalid JSON response"
            raise OllamaError("Local Ollama returned an unreadable response.", kind="protocol", retryable=True) from error

    def status(self) -> dict:
        try:
            response = self._request("/api/tags")
            models = [model["name"] for model in response.get("models", []) if "name" in model]
            return {"connected": True, "models": models, "error": None, "base_url": self.base_url}
        except OllamaError as error:
            return {"connected": False, "models": [], "error": str(error), "base_url": self.base_url}

    def has_model(self, name: str) -> bool:
        return name in set(self.status().get("models") or [])

    def chat(
        self,
        model: str,
        messages: list[dict[str, str]],
        options: dict | None = None,
        *,
        retries: int = 1,
    ) -> str:
        """Send one chat request. Transient transport failures are retried once.

        Timeouts are never silently retried for the whole token budget: on a
        small laptop that would double the wait. The error carries ``kind`` so
        the scheduler can decide to requeue instead.
        """
        generation_options = {
            "temperature": 0.58,
            "num_ctx": int(os.getenv("OLLAMA_NUM_CTX", "1024")),
            "num_predict": int(os.getenv("OLLAMA_NUM_PREDICT", "64")),
        }
        if options:
            generation_options.update(options)
        attempt = 0
        while True:
            attempt += 1
            try:
                response = self._request(
                    "/api/chat",
                    {
                        "model": model,
                        "messages": messages,
                        "stream": False,
                        "think": False,
                        "keep_alive": os.getenv("OLLAMA_KEEP_ALIVE", "10m"),
                        "options": generation_options,
                    },
                )
                break
            except OllamaError as error:
                if attempt > retries or not error.retryable or error.kind == "timeout":
                    raise
                time.sleep(min(3.0, 0.5 * attempt))
        self.last_model = model
        if response.get("error"):
            raise OllamaError(
                f"Local model error: {response['error']}",
                kind="model_error",
                retryable=False,
            )
        try:
            content = response["message"]["content"]
        except (KeyError, TypeError) as error:
            raise OllamaError(
                "Local Ollama returned an invalid chat response.", kind="protocol", retryable=True
            ) from error
        if not isinstance(content, str) or not content.strip():
            raise OllamaError(
                "Local Ollama returned an empty chat response. The model may have run out of context or tokens.",
                kind="empty_response",
                retryable=True,
            )
        return content.strip()

    def chat_json(
        self,
        model: str,
        messages: list[dict[str, str]],
        options: dict | None = None,
    ):
        """Chat and parse JSON, with one explicit repair round for malformed output."""
        content = self.chat(model, messages, options)
        payload = extract_json_payload(content)
        if payload is not None:
            return payload, content
        repair = messages + [
            {"role": "assistant", "content": content[:1500]},
            {
                "role": "user",
                "content": (
                    "That reply was not valid JSON. Return ONLY the JSON value with no prose, "
                    "no markdown fences and no trailing text."
                ),
            },
        ]
        repaired = self.chat(model, repair, {**(options or {}), "temperature": 0.1})
        payload = extract_json_payload(repaired)
        if payload is None:
            raise OllamaError(
                "The local model did not return valid JSON, even after one repair attempt.",
                kind="invalid_json",
                retryable=False,
            )
        return payload, repaired

    def stream_chat(
        self,
        model: str,
        messages: list[dict[str, str]],
        options: dict | None = None,
    ) -> Iterator[str]:
        """Yield answer tokens from Ollama so the town chat never looks frozen."""
        generation_options = {
            "temperature": 0.58,
            "num_ctx": int(os.getenv("OLLAMA_NUM_CTX", "1024")),
            "num_predict": int(os.getenv("OLLAMA_NUM_PREDICT", "48")),
        }
        if options:
            generation_options.update(options)
        request = Request(
            f"{self.base_url}/api/chat",
            data=json.dumps({
                "model": model,
                "messages": messages,
                "stream": True,
                "think": False,
                "keep_alive": os.getenv("OLLAMA_KEEP_ALIVE", "10m"),
                "options": generation_options,
            }).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urlopen(request, timeout=self.timeout) as response:
                for raw_line in response:
                    if not raw_line.strip():
                        continue
                    try:
                        packet = json.loads(raw_line.decode("utf-8"))
                    except json.JSONDecodeError as error:
                        raise OllamaError(
                            "Local Ollama returned an invalid streaming response.",
                            kind="protocol",
                            retryable=True,
                        ) from error
                    if packet.get("error"):
                        raise OllamaError(str(packet["error"]), kind="model_error", retryable=False)
                    message = packet.get("message") or {}
                    token = message.get("content", "")
                    if token:
                        yield token
                    if packet.get("done"):
                        break
        except (HTTPError, URLError, TimeoutError, socket.timeout, OSError) as error:
            raise OllamaError(
                f"Local Ollama streaming request failed: {error}",
                kind="stream_failure",
                retryable=True,
            ) from error
