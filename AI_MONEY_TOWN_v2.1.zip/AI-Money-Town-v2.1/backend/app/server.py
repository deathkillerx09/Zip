"""ASGI entry point.

The FastAPI application is created here, not at import time in ``main``.
Importing ``app.main`` (for example from the test suite) must never touch the
owner's real database file.
"""

from .main import create_app

app = create_app()
