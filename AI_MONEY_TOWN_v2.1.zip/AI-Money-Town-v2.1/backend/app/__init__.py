"""AI Money Town application package."""
