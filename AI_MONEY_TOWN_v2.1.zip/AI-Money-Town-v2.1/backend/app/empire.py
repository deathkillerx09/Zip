from __future__ import annotations

import sqlite3

from fastapi import HTTPException

from .core import add_activity, timestamp


STAGES = (
    "research",
    "development",
    "simulation",
    "ready_for_approval",
    "live_business",
    "growing",
    "stable",
    "declining",
    "revival",
    "temporarily_dormant",
    "archived",
)

TRANSITIONS = {
    "research": {"development", "temporarily_dormant", "archived"},
    "development": {"research", "simulation", "temporarily_dormant", "archived"},
    "simulation": {"development", "ready_for_approval", "temporarily_dormant", "archived"},
    "ready_for_approval": {"simulation", "live_business", "temporarily_dormant", "archived"},
    "live_business": {"growing", "stable", "declining", "temporarily_dormant"},
    "growing": {"live_business", "stable", "declining", "temporarily_dormant"},
    "stable": {"growing", "declining", "temporarily_dormant"},
    "declining": {"revival", "temporarily_dormant", "archived", "growing", "stable"},
    "revival": {"research", "development", "simulation", "live_business", "declining", "temporarily_dormant", "archived"},
    "temporarily_dormant": {"revival", "archived"},
    "archived": {"revival"},
}

STAGE_ASSIGNMENTS = {
    "research": ("researcher", "Market research"),
    "development": ("builder", "Product development"),
    "simulation": ("finance-analyst", "Business simulation"),
    "ready_for_approval": ("town-manager", "Approval review"),
    "live_business": ("operations", "Business operations"),
    "growing": ("marketer", "Customer growth"),
    "stable": ("operations", "Retention and quality"),
    "revival": ("researcher", "Revival research"),
    "declining": ("researcher", "Decline investigation"),
}
RECOGNITION = {
    "product_improvement": ("Product Improvement", "Thoughtful Builder Trophy", 60, 6, 3),
    "customer_satisfaction": ("Customer Care", "Customer Champion Trophy", 65, 7, 4),
    "good_research": ("Research Excellence", "Insight Award", 45, 5, 3),
    "cost_savings": ("Responsible Savings", "Efficiency Trophy", 80, 6, 5),
    "security_quality": ("Security and Quality", "Trust Keeper Trophy", 90, 8, 6),
    "ethical_decision": ("Ethical Leadership", "Integrity Trophy", 90, 10, 8),
}


def _event(connection, business_id: int, kind: str, details: str, old: str | None = None, new: str | None = None):
    connection.execute(
        """
        INSERT INTO business_events (business_id, event_type, from_stage, to_stage, details, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (business_id, kind, old, new, details, timestamp()),
    )


def _assign(connection, business_id: int, stage: str) -> int | None:
    assignment = STAGE_ASSIGNMENTS.get(stage)
    if not assignment:
        return None
    preferred_employee, task_kind = assignment
    employee = connection.execute(
        """
        SELECT e.id FROM employees e
        JOIN employee_profiles p ON p.employee_id = e.id
        WHERE e.id = ?
        """,
        (preferred_employee,),
    ).fetchone()
    if employee is None:
        raise RuntimeError(f"Required employee role {preferred_employee} is missing.")
    if connection.execute(
        "SELECT COUNT(*) FROM tasks WHERE employee_id = ? AND status IN ('pending', 'in_progress')",
        (preferred_employee,),
    ).fetchone()[0] >= 3:
        return None
    business = connection.execute(
        """
        SELECT i.title FROM businesses b JOIN business_ideas i ON i.id = b.idea_id
        WHERE b.id = ?
        """,
        (business_id,),
    ).fetchone()
    if business is None:
        raise RuntimeError(f"Business {business_id} is missing.")
    now = timestamp()
    dedupe_key = f"business:{business_id}:stage:{stage}"
    cursor = connection.execute(
        """
        INSERT OR IGNORE INTO tasks
            (title, description, employee_id, status, created_at, updated_at,
             business_id, task_kind, mission_type, dedupe_key)
        VALUES (?, ?, ?, 'pending', ?, ?, ?, 'autonomous', ?, ?)
        """,
        (
            f"{task_kind}: {business['title']}",
            f"Review the {stage.replace('_', ' ')} stage and record evidence-based findings. "
            "This is internal work only; do not make purchases or treat estimates as real revenue.",
            employee["id"],
            now,
            now,
            business_id,
            stage,
            dedupe_key,
        ),
    )
    if cursor.rowcount != 1:
        return None
    task = connection.execute("SELECT id FROM tasks WHERE dedupe_key = ?", (dedupe_key,)).fetchone()
    connection.execute(
        """
        INSERT INTO business_assignments
            (business_id, employee_id, assignment_role, current_project, assigned_at)
        SELECT ?, ?, ?, ?, ?
        WHERE NOT EXISTS (
            SELECT 1 FROM business_assignments
            WHERE business_id = ? AND employee_id = ? AND assignment_role = ? AND released_at IS NULL
        )
        """,
        (
            business_id,
            employee["id"],
            stage,
            business["title"],
            now,
            business_id,
            employee["id"],
            stage,
        ),
    )
    if task:
        return task["id"]
    return None


def approve_idea(connection, idea_id: int) -> dict:
    idea = connection.execute(
        "SELECT * FROM business_ideas WHERE id = ?", (idea_id,)
    ).fetchone()
    if idea is None:
        raise HTTPException(status_code=404, detail="Business idea not found.")
    if idea["status"] != "approved":
        connection.execute("UPDATE business_ideas SET status = 'approved' WHERE id = ?", (idea_id,))
        add_activity(connection, f"Business idea approved for research: {idea['title']}")
    now = timestamp()
    connection.execute(
        """
        INSERT OR IGNORE INTO businesses (idea_id, stage, created_at, updated_at)
        VALUES (?, 'research', ?, ?)
        """,
        (idea_id, now, now),
    )
    business = connection.execute(
        "SELECT * FROM businesses WHERE idea_id = ?", (idea_id,)
    ).fetchone()
    created = connection.execute(
        "SELECT COUNT(*) AS count FROM business_events WHERE business_id = ?",
        (business["id"],),
    ).fetchone()["count"] == 0
    if created:
        _event(connection, business["id"], "created", "Approved idea entered the business research lifecycle.", None, "research")
        _assign(connection, business["id"], "research")
    return dict(business)


def transition_business(connection, business_id: int, target: str, details: str = "") -> dict:
    if target not in STAGES:
        raise HTTPException(status_code=422, detail="Unknown business lifecycle stage.")
    business = connection.execute(
        "SELECT * FROM businesses WHERE id = ?", (business_id,)
    ).fetchone()
    if business is None:
        raise HTTPException(status_code=404, detail="Business not found.")
    old = business["stage"]
    if target == old:
        return dict(business)
    if target not in TRANSITIONS[old]:
        raise HTTPException(
            status_code=409,
            detail=f"Transition from {old.replace('_', ' ')} to {target.replace('_', ' ')} is not allowed.",
        )
    now = timestamp()
    connection.execute(
        "UPDATE businesses SET stage = ?, updated_at = ? WHERE id = ?",
        (target, now, business_id),
    )
    _event(connection, business_id, "stage_transition", details or "Owner-directed lifecycle transition.", old, target)
    connection.execute(
        "UPDATE business_assignments SET released_at = ? WHERE business_id = ? AND released_at IS NULL",
        (now, business_id),
    )
    if target in STAGE_ASSIGNMENTS and target not in {"declining", "revival"}:
        _assign(connection, business_id, target)
    add_activity(connection, f"Business moved from {old.replace('_', ' ')} to {target.replace('_', ' ')}.")
    if target == "declining":
        create_revival_mission(connection, business_id, details or "Performance decline detected.")
    elif target == "revival":
        create_revival_mission(connection, business_id, details or "Preserved work entered revival review.")
    _reward_profitable_contributors(connection, business_id, target)
    return dict(connection.execute("SELECT * FROM businesses WHERE id = ?", (business_id,)).fetchone())


def record_metrics(connection, business_id: int, values: dict) -> dict:
    if connection.execute("SELECT 1 FROM businesses WHERE id = ?", (business_id,)).fetchone() is None:
        raise HTTPException(status_code=404, detail="Business not found.")
    cursor = connection.execute(
        """
        INSERT INTO business_metrics
            (business_id, estimated_revenue_cents, retention_pct, satisfaction_pct,
             growth_pct, customer_feedback, competitor_analysis, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            business_id,
            values["estimated_revenue_cents"],
            values["retention_pct"],
            values["satisfaction_pct"],
            values["growth_pct"],
            values["customer_feedback"].strip(),
            values["competitor_analysis"].strip(),
            timestamp(),
        ),
    )
    _event(
        connection,
        business_id,
        "simulation_metrics_recorded",
        "Non-financial and estimated performance metrics; not actual revenue.",
    )
    return dict(connection.execute("SELECT * FROM business_metrics WHERE id = ?", (cursor.lastrowid,)).fetchone())


def create_revival_mission(connection, business_id: int, reason: str) -> dict:
    business = connection.execute(
        """
        SELECT b.stage, m.* FROM businesses b
        LEFT JOIN business_metrics m ON m.id = (
            SELECT MAX(id) FROM business_metrics WHERE business_id = b.id
        )
        WHERE b.id = ?
        """,
        (business_id,),
    ).fetchone()
    if business is None:
        raise HTTPException(status_code=404, detail="Business not found.")
    mission = connection.execute(
        """
        SELECT * FROM revival_missions
        WHERE business_id = ? AND phase NOT IN ('paused', 'resolved', 'experiment_recommended')
        ORDER BY id DESC LIMIT 1
        """,
        (business_id,),
    ).fetchone()
    if mission is not None:
        return dict(mission)
    feedback = business["customer_feedback"] or ""
    competitor = business["competitor_analysis"] or ""
    now = timestamp()
    cursor = connection.execute(
        """
        INSERT INTO revival_missions
            (business_id, phase, decline_reason, customer_feedback,
             sales_retention_analysis, competitor_analysis, created_at, updated_at)
        VALUES (?, 'investigating', ?, ?, ?, ?, ?, ?)
        """,
        (
            business_id,
            reason,
            feedback,
            f"Latest retention: {business['retention_pct'] if business['retention_pct'] is not None else 'unknown'}%; "
            "verified sales are reported separately from estimated sales.",
            competitor,
            now,
            now,
        ),
    )
    _event(connection, business_id, "revival_mission_opened", reason)
    assign_revival_task(connection, business_id, "researcher", "investigating", cursor.lastrowid)
    return dict(connection.execute("SELECT * FROM revival_missions WHERE id = ?", (cursor.lastrowid,)).fetchone())


def advance_revival(connection, mission_id: int, phase: str, new_market_information: str = "") -> dict:
    phases = (
        "investigating",
        "solution_planning",
        "development",
        "simulation",
        "experiment_recommended",
        "paused",
        "resolved",
    )
    if phase not in phases:
        raise HTTPException(status_code=422, detail="Unknown revival mission phase.")
    mission = connection.execute(
        "SELECT * FROM revival_missions WHERE id = ?", (mission_id,)
    ).fetchone()
    if mission is None:
        raise HTTPException(status_code=404, detail="Revival mission not found.")
    next_phase = {
        "investigating": {"solution_planning", "paused"},
        "solution_planning": {"development", "paused"},
        "development": {"simulation", "paused"},
        "simulation": {"experiment_recommended", "paused"},
        "experiment_recommended": {"paused", "resolved"},
        "paused": {"investigating"},
        "resolved": set(),
    }
    if phase == mission["phase"]:
        return dict(mission)
    if phase not in next_phase[mission["phase"]]:
        raise HTTPException(status_code=409, detail="Revival mission phase transition is not allowed.")
    now = timestamp()
    restart_attempt = mission["phase"] == "paused" and phase == "investigating"
    connection.execute(
        """
        UPDATE revival_missions
        SET phase = ?, new_market_information = ?, updated_at = ?,
            attempt_number = attempt_number + ? WHERE id = ?
        """,
        (phase, new_market_information.strip(), now, int(restart_attempt), mission_id),
    )
    business_id = mission["business_id"]
    _event(
        connection,
        business_id,
        "revival_phase_transition",
        f"Revival mission {mission_id} moved from {mission['phase']} to {phase}."
        + (f" New market information: {new_market_information.strip()}" if new_market_information.strip() else ""),
    )
    if phase == "paused":
        current = connection.execute(
            "SELECT stage FROM businesses WHERE id = ?", (business_id,)
        ).fetchone()
        if current and current["stage"] in {"declining", "revival"}:
            transition_business(connection, business_id, "temporarily_dormant", "Revival work paused to prevent unfunded spending.")
        add_activity(connection, f"Revival spending paused for business {business_id}; work is preserved.")
    elif phase == "investigating" and mission["phase"] == "paused":
        transition_business(connection, business_id, "revival", new_market_information)
        assign_revival_task(connection, business_id, "researcher", "investigating", mission_id)
    elif phase == "solution_planning":
        current = connection.execute(
            "SELECT stage FROM businesses WHERE id = ?", (business_id,)
        ).fetchone()
        if current and current["stage"] == "declining":
            transition_business(connection, business_id, "revival", "Revival investigation identified a path worth evaluating.")
        assign_revival_task(connection, business_id, "strategist", phase, mission_id)
    elif phase in {"solution_planning", "development", "simulation"}:
        role = {
            "development": "builder",
            "simulation": "finance-analyst",
        }[phase]
        assign_revival_task(connection, business_id, role, phase, mission_id)
    elif phase == "experiment_recommended":
        add_activity(connection, f"Controlled real-world experiment recommended for business {business_id}; owner approval and funding are still required.")
    if phase == "resolved":
        _event(connection, business_id, "revival_resolved", new_market_information)
    return dict(connection.execute("SELECT * FROM revival_missions WHERE id = ?", (mission_id,)).fetchone())


def request_revival(connection, business_id: int, new_market_information: str) -> dict:
    business = connection.execute(
        "SELECT stage FROM businesses WHERE id = ?", (business_id,)
    ).fetchone()
    if business is None:
        raise HTTPException(status_code=404, detail="Business not found.")
    if business["stage"] not in {"declining", "temporarily_dormant", "archived"}:
        raise HTTPException(
            status_code=409,
            detail="Revival can be requested only for declining, dormant, or archived businesses.",
        )
    reason = "Owner supplied new market information; preserved work will be reassessed."
    mission = create_revival_mission(connection, business_id, reason)
    connection.execute(
        "UPDATE revival_missions SET new_market_information = ?, updated_at = ? WHERE id = ?",
        (new_market_information.strip(), timestamp(), mission["id"]),
    )
    if business["stage"] != "revival":
        transition_business(connection, business_id, "revival", new_market_information)
    return dict(connection.execute(
        "SELECT * FROM revival_missions WHERE id = ?", (mission["id"],)
    ).fetchone())


def pause_unprofitable_business(connection, business_id: int, verified_profit_cents: int) -> None:
    business = connection.execute(
        "SELECT stage FROM businesses WHERE id = ?", (business_id,)
    ).fetchone()
    if business is None or business["stage"] not in {"live_business", "growing", "stable"}:
        return
    details = (
        f"Verified ledger profit is negative ({verified_profit_cents} cents). "
        "Costly work is paused; free internal analysis may continue."
    )
    transition_business(connection, business_id, "temporarily_dormant", details)
    mission = create_revival_mission(connection, business_id, details)
    assign_revival_task(connection, business_id, "researcher", "investigating", mission["id"])


def assign_revival_task(connection, business_id: int, employee_id: str, phase: str, mission_id: int) -> int:
    business = connection.execute(
        """
        SELECT i.title FROM businesses b JOIN business_ideas i ON i.id = b.idea_id
        WHERE b.id = ?
        """,
        (business_id,),
    ).fetchone()
    if business is None:
        raise HTTPException(status_code=404, detail="Business not found.")
    employee = connection.execute("SELECT 1 FROM employees WHERE id = ?", (employee_id,)).fetchone()
    if employee is None:
        raise RuntimeError(f"Required employee {employee_id} is missing.")
    title = f"Revival {phase.replace('_', ' ')}: {business['title']}"
    now = timestamp()
    mission = connection.execute(
        "SELECT attempt_number FROM revival_missions WHERE id = ?", (mission_id,)
    ).fetchone()
    if mission is None:
        raise HTTPException(status_code=404, detail="Revival mission not found.")
    dedupe_key = f"revival:{mission_id}:{mission['attempt_number']}:{phase}"
    connection.execute(
        """
        INSERT OR IGNORE INTO tasks
            (title, description, employee_id, status, created_at, updated_at,
             business_id, task_kind, mission_type, dedupe_key)
        VALUES (?, ?, ?, 'pending', ?, ?, ?, 'autonomous', ?, ?)
        """,
        (
            title,
            "Internal analysis only. Preserve the existing work and do not spend money. "
            "Compare customer feedback, retention, verified sales, and competitors.",
            employee_id,
            now,
            now,
            business_id,
            phase,
            dedupe_key,
        ),
    )
    connection.execute(
        """
        INSERT INTO business_assignments
            (business_id, employee_id, assignment_role, current_project, assigned_at)
        SELECT ?, ?, ?, ?, ?
        WHERE NOT EXISTS (
            SELECT 1 FROM business_assignments
            WHERE business_id = ? AND employee_id = ? AND assignment_role = ? AND released_at IS NULL
        )
        """,
        (business_id, employee_id, phase, business["title"], now, business_id, employee_id, phase),
    )
    task = connection.execute("SELECT id FROM tasks WHERE dedupe_key = ?", (dedupe_key,)).fetchone()
    if task is None:
        raise RuntimeError("Revival task was not persisted.")
    return task["id"]


def _reward_profitable_contributors(connection, business_id: int, stage: str) -> None:
    if stage not in {"live_business", "growing", "stable"}:
        return
    totals = connection.execute(
        """
        SELECT
            COALESCE(SUM(CASE WHEN transaction_type = 'payment_settled' AND is_verified = 1
                THEN amount_cents ELSE 0 END), 0)
          - COALESCE(SUM(CASE WHEN transaction_type IN ('refund', 'processing_fee', 'expense', 'reinvestment')
                AND is_verified = 1 THEN amount_cents ELSE 0 END), 0) AS profit_cents
        FROM transactions WHERE business_id = ?
        """,
        (business_id,),
    ).fetchone()
    if totals["profit_cents"] <= 0:
        return
    contributors = connection.execute(
        """
        SELECT DISTINCT employee_id FROM business_assignments WHERE business_id = ?
        UNION SELECT DISTINCT employee_id FROM tasks WHERE business_id = ? AND status = 'completed'
        """,
        (business_id, business_id),
    )
    for row in contributors:
        award_reward(
            connection,
            employee_id=row["employee_id"],
            business_id=business_id,
            achievement_code="verified_profitable_business",
            badge="Verified Profit Contributor",
            trophy="Sustainable Business Trophy",
            experience_points=100,
            morale_delta=8,
            reputation_delta=5,
            evidence_ref=f"verified-ledger-profit:{business_id}",
        )


def reward_profitable_contributors(connection, business_id: int) -> None:
    business = connection.execute(
        "SELECT stage FROM businesses WHERE id = ?", (business_id,)
    ).fetchone()
    if business is not None:
        _reward_profitable_contributors(connection, business_id, business["stage"])


def award_reward(
    connection,
    employee_id: str,
    business_id: int | None,
    achievement_code: str,
    badge: str,
    trophy: str,
    experience_points: int,
    morale_delta: int,
    reputation_delta: int,
    evidence_ref: str,
) -> dict:
    if experience_points <= 0 or experience_points > 10000:
        raise HTTPException(status_code=422, detail="Experience award is outside the allowed range.")
    if not evidence_ref.strip():
        raise HTTPException(status_code=422, detail="Evidence reference is required for a recognition award.")
    if connection.execute("SELECT 1 FROM employees WHERE id = ?", (employee_id,)).fetchone() is None:
        raise HTTPException(status_code=404, detail="Employee not found.")
    try:
        cursor = connection.execute(
            """
            INSERT INTO employee_rewards
                (employee_id, business_id, achievement_code, badge, trophy,
                 experience_points, morale_delta, reputation_delta, evidence_ref, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                employee_id,
                business_id,
                achievement_code,
                badge,
                trophy,
                experience_points,
                morale_delta,
                reputation_delta,
                evidence_ref.strip(),
                timestamp(),
            ),
        )
    except sqlite3.IntegrityError as error:
        if "UNIQUE constraint failed" in str(error):
            raise HTTPException(status_code=409, detail="This employee already received this achievement.") from error
        raise
    profile = connection.execute(
        "SELECT * FROM employee_profiles WHERE employee_id = ?", (employee_id,)
    ).fetchone()
    xp = profile["experience_points"] + experience_points
    levels = ((1500, "principal"), (800, "lead"), (350, "specialist"), (100, "associate"))
    level = next((name for threshold, name in levels if xp >= threshold), "novice")
    connection.execute(
        """
        UPDATE employee_profiles SET
            experience_points = ?,
            morale = MIN(100, MAX(0, morale + ?)),
            reputation = MIN(100, MAX(0, reputation + ?)),
            performance_rating = MIN(5.0, performance_rating + 0.1),
            career_level = ?,
            virtual_trophies = virtual_trophies + 1,
            workplace_upgrades = workplace_upgrades + 1,
            updated_at = ?
        WHERE employee_id = ?
        """,
        (xp, morale_delta, reputation_delta, level, timestamp(), employee_id),
    )
    add_activity(connection, f"Simulated recognition awarded to {employee_id}: {badge}.")
    return dict(connection.execute("SELECT * FROM employee_rewards WHERE id = ?", (cursor.lastrowid,)).fetchone())


def award_recognition(
    connection,
    employee_id: str,
    business_id: int | None,
    achievement_code: str,
    evidence_ref: str,
) -> dict:
    if achievement_code not in RECOGNITION:
        raise HTTPException(status_code=422, detail="Unknown employee recognition category.")
    if business_id is not None and connection.execute(
        "SELECT 1 FROM businesses WHERE id = ?", (business_id,)
    ).fetchone() is None:
        raise HTTPException(status_code=404, detail="Business not found.")
    badge, trophy, xp, morale, reputation = RECOGNITION[achievement_code]
    return award_reward(
        connection,
        employee_id,
        business_id,
        achievement_code,
        badge,
        trophy,
        xp,
        morale,
        reputation,
        evidence_ref,
    )


def empire_data(connection) -> list[dict]:
    result = []
    for row in connection.execute(
        """
        SELECT b.*, i.title, i.description,
            m.estimated_revenue_cents, m.retention_pct, m.satisfaction_pct,
            m.growth_pct, m.customer_feedback, m.competitor_analysis, m.created_at AS metrics_created_at
        FROM businesses b
        JOIN business_ideas i ON i.id = b.idea_id
        LEFT JOIN business_metrics m ON m.id = (
            SELECT MAX(id) FROM business_metrics WHERE business_id = b.id
        )
        ORDER BY b.updated_at DESC, b.id DESC
        """
    ):
        financials = connection.execute(
            """
            SELECT
                COALESCE(SUM(CASE WHEN transaction_type = 'payment_settled' AND is_verified = 1
                    THEN amount_cents ELSE 0 END), 0) AS actual_sales_cents,
                COALESCE(SUM(CASE WHEN transaction_type = 'payment_pending'
                    THEN amount_cents ELSE 0 END), 0)
                  - COALESCE(SUM(CASE WHEN transaction_type = 'payment_settled'
                        THEN amount_cents ELSE 0 END), 0) AS pending_payment_cents,
                COALESCE(SUM(CASE WHEN transaction_type IN ('refund', 'processing_fee', 'expense', 'reinvestment')
                        AND is_verified = 1 THEN amount_cents ELSE 0 END), 0) AS actual_costs_cents
            FROM transactions WHERE business_id = ?
            """,
            (row["id"],),
        ).fetchone()
        item = dict(row)
        item.update(dict(financials))
        item["verified_profit_cents"] = financials["actual_sales_cents"] - financials["actual_costs_cents"]
        item["employees"] = [
            dict(assignment)
            for assignment in connection.execute(
                """
                SELECT a.employee_id, e.name, e.role, a.assignment_role, a.current_project, a.assigned_at
                FROM business_assignments a JOIN employees e ON e.id = a.employee_id
                WHERE a.business_id = ? AND a.released_at IS NULL ORDER BY a.id
                """,
                (row["id"],),
            )
        ]
        result.append(item)
    return result


def business_history(connection, business_id: int) -> dict:
    business = connection.execute(
        """
        SELECT b.*, i.title, i.description FROM businesses b
        JOIN business_ideas i ON i.id = b.idea_id WHERE b.id = ?
        """,
        (business_id,),
    ).fetchone()
    if business is None:
        raise HTTPException(status_code=404, detail="Business not found.")
    from .finance import finance_summary

    return {
        "business": dict(business),
        "financials": finance_summary(connection, business_id),
        "transactions": finance_transactions_for_business(connection, business_id),
        "metrics": [dict(row) for row in connection.execute(
            "SELECT * FROM business_metrics WHERE business_id = ? ORDER BY id DESC", (business_id,)
        )],
        "events": [dict(row) for row in connection.execute(
            "SELECT * FROM business_events WHERE business_id = ? ORDER BY id DESC", (business_id,)
        )],
        "assignments": [dict(row) for row in connection.execute(
            """
            SELECT a.*, e.name, e.role FROM business_assignments a
            JOIN employees e ON e.id = a.employee_id
            WHERE a.business_id = ? ORDER BY a.id DESC
            """,
            (business_id,),
        )],
        "tasks": [dict(row) for row in connection.execute(
            "SELECT * FROM tasks WHERE business_id = ? ORDER BY id DESC", (business_id,)
        )],
        "revival_missions": [dict(row) for row in connection.execute(
            "SELECT * FROM revival_missions WHERE business_id = ? ORDER BY id DESC", (business_id,)
        )],
        "artifacts": [dict(row) for row in connection.execute(
            "SELECT * FROM business_artifacts WHERE business_id = ? ORDER BY id DESC", (business_id,)
        )],
        "deliverables": [dict(row) for row in connection.execute(
            "SELECT * FROM deliverables WHERE business_id = ? ORDER BY id DESC", (business_id,)
        )],
    }


def finance_transactions_for_business(connection, business_id: int) -> list[dict]:
    return [
        dict(row)
        for row in connection.execute(
            "SELECT * FROM transactions WHERE business_id = ? ORDER BY id DESC",
            (business_id,),
        )
    ]
