from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
import secrets
import threading
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, Header, HTTPException, Query
from fastapi.responses import FileResponse, StreamingResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator

from . import deliverables, empire, finance
from .core import add_activity, timestamp
from .database import Database
from .ollama import OllamaClient, OllamaError, select_work_model, select_chat_model
from .people import employee_profile
from .scheduler import (
    max_attempts,
    process_next_autonomous_task,
    queue_status,
    record_task_event,
    run_management_cycle,
    scheduler_interval,
    scheduler_loop,
)


logger = logging.getLogger(__name__)

ROOT = Path(__file__).resolve().parents[2]
WEB_ROOT = ROOT / "frontend"


class TaskCreate(BaseModel):
    title: str = Field(min_length=1, max_length=160)
    description: str = Field(default="", max_length=2000)
    employee_id: str

    @field_validator("title")
    @classmethod
    def title_must_not_be_blank(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Title cannot be blank.")
        return value


class TaskUpdate(BaseModel):
    status: Literal["pending", "in_progress", "completed", "failed"]
    result: str | None = Field(default=None, max_length=4000)


class IdeaCreate(BaseModel):
    title: str = Field(min_length=1, max_length=160)
    description: str = Field(default="", max_length=3000)

    @field_validator("title")
    @classmethod
    def title_must_not_be_blank(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Title cannot be blank.")
        return value


class IdeaUpdate(BaseModel):
    status: Literal["proposed", "evaluating", "approved", "archived"]


class MessageCreate(BaseModel):
    content: str = Field(min_length=1, max_length=4000)
    model: str | None = None


class BusinessTransition(BaseModel):
    target: Literal[
        "research", "development", "simulation", "ready_for_approval",
        "live_business", "growing", "stable", "declining", "revival",
        "temporarily_dormant", "archived",
    ]
    note: str = Field(default="", max_length=2000)


class BusinessMetricsCreate(BaseModel):
    estimated_revenue_cents: int = Field(default=0, ge=0, le=10**14)
    retention_pct: float = Field(ge=0, le=100)
    satisfaction_pct: float = Field(ge=0, le=100)
    growth_pct: float = Field(ge=-100, le=10000)
    customer_feedback: str = Field(default="", max_length=4000)
    competitor_analysis: str = Field(default="", max_length=4000)


class BusinessAssignment(BaseModel):
    employee_id: str
    assignment_role: str = Field(min_length=1, max_length=80)
    title: str = Field(min_length=1, max_length=160)
    description: str = Field(default="", max_length=2000)


class RevivalAdvance(BaseModel):
    phase: Literal[
        "investigating", "solution_planning", "development", "simulation",
        "experiment_recommended", "paused", "resolved",
    ]
    new_market_information: str = Field(default="", max_length=4000)


class SpendingLimitUpdate(BaseModel):
    amount_cents: int = Field(ge=0, le=10**12)


class PendingPaymentCreate(BaseModel):
    business_id: int
    amount_cents: int = Field(gt=0, le=10**14)
    external_reference: str = Field(min_length=1, max_length=200)
    note: str = Field(default="", max_length=1000)


class SettlementCreate(BaseModel):
    amount_cents: int = Field(gt=0, le=10**14)
    evidence_ref: str = Field(min_length=1, max_length=300)


class FinancialAdjustment(BaseModel):
    business_id: int | None = None
    transaction_type: Literal["refund", "processing_fee", "expense", "reinvestment"]
    amount_cents: int = Field(gt=0, le=10**14)
    external_reference: str = Field(min_length=1, max_length=200)
    evidence_ref: str = Field(min_length=1, max_length=300)
    note: str = Field(default="", max_length=1000)


class WithdrawalRequest(BaseModel):
    amount_cents: int = Field(gt=0, le=10**14)
    external_reference: str = Field(min_length=1, max_length=200)


class RecognitionCreate(BaseModel):
    business_id: int | None = None
    achievement_code: Literal[
        "product_improvement", "customer_satisfaction", "good_research",
        "cost_savings", "security_quality", "ethical_decision",
    ]
    evidence_ref: str = Field(min_length=1, max_length=300)


class TeamShareCreate(BaseModel):
    recipient_employee_id: str
    request: str = Field(min_length=1, max_length=2000)
    model: str | None = None


class ProductBuildRequest(BaseModel):
    kind: Literal["web_app", "landing_page"] = "web_app"


class TaskPriorityUpdate(BaseModel):
    priority: int = Field(ge=-10, le=100)


def _rate_limit_per_minute() -> int:
    try:
        return max(5, int(os.getenv("AI_MONEY_TOWN_RATE_LIMIT_PER_MINUTE", "240")))
    except ValueError:
        return 240


def create_app(
    database_path: str | Path | None = None,
    ollama_client: OllamaClient | None = None,
    scheduler_enabled: bool = True,
) -> FastAPI:
    db = Database(database_path or os.getenv("AI_MONEY_TOWN_DB", ROOT / "data" / "town.db"))
    db.initialize()
    ollama = ollama_client or OllamaClient(
        os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434"),
        timeout=float(os.getenv("OLLAMA_TIMEOUT_SECONDS", "55")),
    )
    model_lock = threading.BoundedSemaphore(1)
    # Interactive owner chats take priority over background employee work.
    interactive_chat_waiting = threading.Event()

    @asynccontextmanager
    async def lifespan(application: FastAPI):
        manager_task = None
        if scheduler_enabled:
            manager_task = asyncio.create_task(
                scheduler_loop(db, scheduler_interval(), ollama, model_lock, interactive_chat_waiting),
                name="ai-money-town-mayor",
            )
        try:
            yield
        finally:
            if manager_task is not None:
                manager_task.cancel()
                try:
                    await manager_task
                except asyncio.CancelledError:
                    pass

    app = FastAPI(title="AI Money Town", version="2.1.0", lifespan=lifespan)
    app.state.database = db

    write_hits: dict[tuple[str, str], deque[float]] = defaultdict(deque)
    limit_per_minute = _rate_limit_per_minute()
    max_body_bytes = int(os.getenv("AI_MONEY_TOWN_MAX_BODY_BYTES", str(2 * 1024 * 1024)))

    @app.middleware("http")
    async def abuse_guards(request, call_next):
        """Cap request body size and write/expensive-request rate per client.

        A local town does not need to defend against the internet, but one runaway
        browser tab must not be able to flood the model queue or the ledger.
        """
        content_length = request.headers.get("content-length")
        if content_length and content_length.isdigit() and int(content_length) > max_body_bytes:
            return Response(
                content="Request body too large.",
                status_code=413,
                media_type="text/plain",
            )
        path = request.url.path
        expensive = request.method in {"POST", "PUT", "PATCH", "DELETE"} or path in {
            "/api/city/state", "/api/dashboard", "/api/automation/status",
        }
        if expensive:
            client = request.client.host if request.client else "local"
            key = (client, "expensive")
            window = write_hits[key]
            now = time.monotonic()
            while window and now - window[0] > 60:
                window.popleft()
            if len(window) >= limit_per_minute:
                return Response(
                    content=f"Too many requests. Limit is {limit_per_minute} per minute; slow down and retry shortly.",
                    status_code=429,
                    media_type="text/plain",
                    headers={"Retry-After": "30"},
                )
            window.append(now)
        return await call_next(request)

    @app.middleware("http")
    async def optional_private_site_gate(request, call_next):
        # Local development remains frictionless when these variables are unset.
        # Cloud deployments should set both values to protect every page and API.
        username = os.getenv("AI_MONEY_TOWN_ACCESS_USERNAME", "").strip()
        password = os.getenv("AI_MONEY_TOWN_ACCESS_PASSWORD", "")
        if not username and not password:
            return await call_next(request)
        if not username or not password:
            return Response(
                content="Private site access is misconfigured. Set both access variables.",
                status_code=503,
                media_type="text/plain",
            )
        header = request.headers.get("authorization", "")
        supplied_user = supplied_password = ""
        if header.lower().startswith("basic "):
            try:
                decoded = base64.b64decode(header.split(" ", 1)[1], validate=True).decode("utf-8")
                supplied_user, supplied_password = decoded.split(":", 1)
            except (ValueError, UnicodeDecodeError):
                supplied_user = supplied_password = ""
        valid = (
            secrets.compare_digest(supplied_user, username)
            and secrets.compare_digest(supplied_password, password)
        )
        if not valid:
            return Response(
                content="Sign in to access AI Money Town.",
                status_code=401,
                headers={"WWW-Authenticate": 'Basic realm="AI Money Town", charset="UTF-8"'},
                media_type="text/plain",
            )
        return await call_next(request)

    app.mount("/static", StaticFiles(directory=WEB_ROOT), name="static")

    def authorize_owner(token: str | None) -> None:
        configured = os.getenv("AI_MONEY_TOWN_OWNER_TOKEN")
        if not configured:
            raise HTTPException(
                status_code=503,
                detail="Owner actions are disabled. Configure AI_MONEY_TOWN_OWNER_TOKEN first.",
            )
        if not token or not secrets.compare_digest(configured, token):
            raise HTTPException(status_code=401, detail="A valid owner authorization token is required.")

    @app.get("/api/owner/status")
    def owner_authorization_status(x_owner_token: str | None = Header(default=None)):
        authorize_owner(x_owner_token)
        return {"authorized": True}

    @app.get("/", include_in_schema=False)
    def dashboard_page():
        return FileResponse(WEB_ROOT / "index.html")

    @app.get("/api/dashboard")
    def get_dashboard():
        with db.read() as connection:
            employees = [dict(row) for row in connection.execute("SELECT * FROM employees ORDER BY rowid")]
            tasks = [
                dict(row)
                for row in connection.execute(
                    """
                    SELECT tasks.*, employees.name AS employee_name
                    FROM tasks JOIN employees ON employees.id = tasks.employee_id
                    ORDER BY CASE tasks.status WHEN 'in_progress' THEN 0 WHEN 'pending' THEN 1 ELSE 2 END,
                             tasks.updated_at DESC
                    """
                )
            ]
            ideas = [
                dict(row)
                for row in connection.execute("SELECT * FROM business_ideas ORDER BY id DESC")
            ]
            activity = [
                dict(row)
                for row in connection.execute("SELECT * FROM activity ORDER BY id DESC LIMIT 20")
            ]
            failed_count = connection.execute(
                "SELECT COUNT(*) FROM tasks WHERE status = 'failed'"
            ).fetchone()[0]
            product_summary = deliverables.summarize(connection)
        ollama_state = ollama.status()
        return {
            "town": {
                "employee_count": len(employees),
                "active_task_count": sum(task["status"] in ("pending", "in_progress") for task in tasks),
                "completed_task_count": sum(task["status"] == "completed" for task in tasks),
                "failed_task_count": failed_count,
                "idea_count": len(ideas),
            },
            "employees": employees,
            "tasks": tasks,
            "ideas": ideas,
            "activity": activity,
            "deliverables": product_summary,
            "ollama": ollama_state,
            "worker": {
                "model_ready": bool(ollama_state.get("connected") and ollama_state.get("models")),
                "blocked_reason": (
                    "Ready to work." if ollama_state.get("connected") and ollama_state.get("models")
                    else (ollama_state.get("error") or "No local model is installed.")
                ),
                "concurrency": 1,
            },
        }

    @app.get("/api/automation/status")
    def get_automation_status():
        with db.read() as connection:
            task_counts = {
                row["status"]: row["count"]
                for row in connection.execute("SELECT status, COUNT(*) AS count FROM tasks GROUP BY status")
            }
            idea_counts = {
                row["status"]: row["count"]
                for row in connection.execute("SELECT status, COUNT(*) AS count FROM business_ideas GROUP BY status")
            }
            business_counts = {
                row["stage"]: row["count"]
                for row in connection.execute("SELECT stage, COUNT(*) AS count FROM businesses GROUP BY stage")
            }
            pending_review = connection.execute(
                "SELECT COUNT(*) FROM businesses WHERE stage = 'ready_for_approval'"
            ).fetchone()[0]
            last_idea_batch = connection.execute(
                "SELECT content, created_at FROM management_reports WHERE report_type = 'idea_generation' ORDER BY id DESC LIMIT 1"
            ).fetchone()
            funds = finance.finance_summary(connection)
            failed_count = int(connection.execute(
                "SELECT COUNT(*) FROM tasks WHERE status = 'failed'"
            ).fetchone()[0])
            retry_waiting = int(connection.execute(
                """SELECT COUNT(*) FROM tasks WHERE status = 'pending'
                   AND next_attempt_at IS NOT NULL AND attempts > 0"""
            ).fetchone()[0])
            last_error = connection.execute(
                """SELECT id, title, last_error FROM tasks
                   WHERE last_error != '' ORDER BY updated_at DESC LIMIT 1"""
            ).fetchone()
        last_batch = None
        if last_idea_batch:
            try:
                last_batch = json.loads(last_idea_batch["content"])
            except (TypeError, json.JSONDecodeError):
                last_batch = {"created_at": last_idea_batch["created_at"], "status": "report_unreadable"}
        return {
            "mode": "local_autonomous_internal_business_pipeline",
            "scheduler_enabled": scheduler_enabled,
            "scheduler_interval_seconds": scheduler_interval(),
            "idea_batch_target": int(os.getenv("AI_MONEY_TOWN_IDEA_BATCH_SIZE", "10")),
            "idea_target_per_hour": int(os.getenv("AI_MONEY_TOWN_IDEA_TARGET_PER_HOUR", "50")),
            "idea_batch_interval_seconds": max(300, int(os.getenv("AI_MONEY_TOWN_IDEA_INTERVAL_SECONDS", "720"))),
            "initial_idea_delay_seconds": max(30, min(1800, int(os.getenv("AI_MONEY_TOWN_INITIAL_IDEA_DELAY_SECONDS", "90")))),
            "task_counts": task_counts,
            "idea_counts": idea_counts,
            "business_counts": business_counts,
            "businesses_waiting_for_owner_review": pending_review,
            "failed_task_count": failed_count,
            "retry_waiting_task_count": retry_waiting,
            "last_task_error": dict(last_error) if last_error else None,
            "worker_concurrency": 1,
            "task_concurrency_note": "One local model call at a time; chat always takes priority.",
            "last_idea_batch": last_batch,
            "actual_revenue_cents": funds["actual_revenue_cents"],
            "available_business_funds_cents": funds["available_business_funds_cents"],
            "spending_limit_cents": funds["daily_spending_limit_cents"],
            "simulated_demand_is_not_revenue": True,
            "public_launch_and_customer_outreach_require_owner_approval": True,
            "real_bank_or_card_payout_connected": False,
            "ollama": ollama.status(),
        }

    @app.get("/api/city/state")
    def get_city_state():
        with db.read() as connection:
            employees = []
            for row in connection.execute(
                """
                SELECT e.id, e.name, e.role, e.specialty, e.status,
                    p.morale, p.experience_points, p.performance_rating,
                    p.reputation, p.career_level, p.virtual_trophies,
                    t.id AS task_id, t.title AS task_title, t.description AS task_description,
                    t.status AS task_status, t.result AS task_result, t.updated_at AS task_updated_at,
                    t.completed_at AS task_completed_at, t.business_id AS task_business_id,
                    task_idea.title AS task_business_title, task_business.stage AS task_business_stage,
                    a.assignment_role, a.current_project,
                    assignment_idea.title AS assignment_business_title,
                    assignment_business.stage AS assignment_business_stage,
                    (SELECT COUNT(*) FROM tasks all_tasks WHERE all_tasks.employee_id = e.id)
                        AS total_task_count,
                    (SELECT COUNT(*) FROM tasks done_tasks
                        WHERE done_tasks.employee_id = e.id AND done_tasks.status = 'completed')
                        AS completed_task_count
                FROM employees e
                LEFT JOIN employee_profiles p ON p.employee_id = e.id
                LEFT JOIN tasks t ON t.id = (
                    SELECT candidate.id FROM tasks candidate
                    WHERE candidate.employee_id = e.id
                    ORDER BY CASE candidate.status
                        WHEN 'in_progress' THEN 0 WHEN 'pending' THEN 1 ELSE 2 END,
                        candidate.updated_at DESC, candidate.id DESC
                    LIMIT 1
                )
                LEFT JOIN businesses task_business ON task_business.id = t.business_id
                LEFT JOIN business_ideas task_idea ON task_idea.id = task_business.idea_id
                LEFT JOIN business_assignments a ON a.id = (
                    SELECT current_assignment.id FROM business_assignments current_assignment
                    WHERE current_assignment.employee_id = e.id
                        AND current_assignment.released_at IS NULL
                    ORDER BY current_assignment.id DESC LIMIT 1
                )
                LEFT JOIN businesses assignment_business ON assignment_business.id = a.business_id
                LEFT JOIN business_ideas assignment_idea ON assignment_idea.id = assignment_business.idea_id
                ORDER BY e.rowid
                """
            ):
                employee = dict(row)
                employee["current_task"] = None
                if employee["task_id"] is not None:
                    employee["current_task"] = {
                        "id": employee["task_id"],
                        "title": employee["task_title"],
                        "description": employee["task_description"],
                        "status": employee["task_status"],
                        "result": employee["task_result"],
                        "updated_at": employee["task_updated_at"],
                        "completed_at": employee["task_completed_at"],
                        "business_id": employee["task_business_id"],
                        "business_title": employee["task_business_title"],
                        "business_stage": employee["task_business_stage"],
                    }
                employee["current_assignment"] = None
                if employee["assignment_role"] is not None:
                    employee["current_assignment"] = {
                        "role": employee["assignment_role"],
                        "project": employee["current_project"],
                        "business_title": employee["assignment_business_title"],
                        "business_stage": employee["assignment_business_stage"],
                    }
                for key in (
                    "task_id", "task_title", "task_description", "task_status", "task_result",
                    "task_updated_at", "task_completed_at", "task_business_id",
                    "task_business_title", "task_business_stage", "assignment_role",
                    "current_project", "assignment_business_title", "assignment_business_stage",
                ):
                    employee.pop(key)
                employees.append(employee)

            task_counts = {
                row["status"]: row["count"]
                for row in connection.execute(
                    "SELECT status, COUNT(*) AS count FROM tasks GROUP BY status"
                )
            }
            task_summary = {
                "active": int(task_counts.get("pending", 0) + task_counts.get("in_progress", 0)),
                "completed": int(task_counts.get("completed", 0)),
                "failed": int(task_counts.get("failed", 0)),
            }
            ideas = [dict(row) for row in connection.execute(
                "SELECT id, title, description, status, created_at FROM business_ideas ORDER BY id DESC LIMIT 12"
            )]
            ideas_last_hour = int(connection.execute(
                "SELECT COUNT(*) FROM business_ideas WHERE datetime(created_at) >= datetime('now', '-1 hour')"
            ).fetchone()[0])
            ideas_total = int(connection.execute("SELECT COUNT(*) FROM business_ideas").fetchone()[0])
            latest_idea_report = connection.execute(
                "SELECT created_at FROM management_reports WHERE report_type = 'idea_generation' ORDER BY id DESC LIMIT 1"
            ).fetchone()
            idea_stats = {
                "target_per_hour": int(os.getenv("AI_MONEY_TOWN_IDEA_TARGET_PER_HOUR", "50")),
                "created_last_hour": ideas_last_hour,
                "total_count": ideas_total,
                "latest_batch_at": latest_idea_report["created_at"] if latest_idea_report else None,
            }
            businesses = empire.empire_data(connection)
            treasury = finance.finance_summary(connection)
            product_summary = deliverables.summarize(connection)
            failed_tasks = int(connection.execute(
                "SELECT COUNT(*) FROM tasks WHERE status = 'failed'"
            ).fetchone()[0])
            latest_failure = connection.execute(
                "SELECT id, title, last_error FROM tasks WHERE status = 'failed' ORDER BY updated_at DESC LIMIT 1"
            ).fetchone()
            deliverable_rows = deliverables.list_deliverables(connection, None, 12)
            report = connection.execute(
                "SELECT content, created_at FROM management_reports ORDER BY id DESC LIMIT 1"
            ).fetchone()
            discussion = connection.execute(
                """
                SELECT m.id, m.sender_employee_id, sender.name AS sender_name,
                    m.recipient_employee_id, recipient.name AS recipient_name, m.created_at
                FROM team_messages m
                JOIN employees sender ON sender.id = m.sender_employee_id
                JOIN employees recipient ON recipient.id = m.recipient_employee_id
                ORDER BY m.id DESC LIMIT 1
                """
            ).fetchone()
        return {
            "employees": employees,
            "tasks": task_counts,
            "task_summary": task_summary,
            "ideas": ideas,
            "idea_stats": idea_stats,
            "businesses": businesses,
            "treasury": treasury,
            "latest_report": (
                {**dict(report), "content": json.loads(report["content"])} if report else None
            ),
            "latest_discussion": dict(discussion) if discussion else None,
            "products": {**product_summary, "recent": deliverable_rows},
            "failed_tasks": {"count": failed_tasks, "latest": dict(latest_failure) if latest_failure else None},
            "ollama": ollama.status(),
        }

    @app.get("/api/empire")
    def get_empire():
        with db.connect() as connection:
            businesses = empire.empire_data(connection)
            summary = finance.finance_summary(connection)
            missions = [
                dict(row)
                for row in connection.execute(
                    """
                    SELECT m.*, i.title AS business_title FROM revival_missions m
                    JOIN businesses b ON b.id = m.business_id
                    JOIN business_ideas i ON i.id = b.idea_id
                    ORDER BY m.id DESC
                    """
                )
            ]
        return {
            "businesses": businesses,
            "revival_missions": missions,
            "finance": summary,
            "lifecycle_stages": list(empire.STAGES),
        }

    @app.get("/api/businesses/{business_id}")
    def get_business(business_id: int):
        with db.connect() as connection:
            return empire.business_history(connection, business_id)

    @app.post("/api/businesses/{business_id}/transition")
    def transition_business(
        business_id: int,
        update: BusinessTransition,
        x_owner_token: str | None = Header(default=None),
    ):
        authorize_owner(x_owner_token)
        with db.connect() as connection:
            return empire.transition_business(connection, business_id, update.target, update.note)

    class RevivalRequest(BaseModel):
        new_market_information: str = Field(min_length=1, max_length=4000)

    @app.post("/api/businesses/{business_id}/revival", status_code=201)
    def request_business_revival(
        business_id: int,
        request: RevivalRequest,
        x_owner_token: str | None = Header(default=None),
    ):
        authorize_owner(x_owner_token)
        with db.connect() as connection:
            return empire.request_revival(connection, business_id, request.new_market_information)

    @app.post("/api/businesses/{business_id}/metrics", status_code=201)
    def record_business_metrics(
        business_id: int,
        metrics: BusinessMetricsCreate,
        x_owner_token: str | None = Header(default=None),
    ):
        authorize_owner(x_owner_token)
        with db.connect() as connection:
            return empire.record_metrics(connection, business_id, metrics.model_dump())

    @app.post("/api/businesses/{business_id}/assignments", status_code=201)
    def assign_business_task(
        business_id: int,
        assignment: BusinessAssignment,
        x_owner_token: str | None = Header(default=None),
    ):
        authorize_owner(x_owner_token)
        now = timestamp()
        with db.connect() as connection:
            business = connection.execute(
                """
                SELECT i.title FROM businesses b JOIN business_ideas i ON i.id = b.idea_id
                WHERE b.id = ?
                """,
                (business_id,),
            ).fetchone()
            if business is None:
                raise HTTPException(status_code=404, detail="Business not found.")
            if connection.execute(
                "SELECT 1 FROM employees WHERE id = ?", (assignment.employee_id,)
            ).fetchone() is None:
                raise HTTPException(status_code=404, detail="Employee not found.")
            if connection.execute(
                "SELECT COUNT(*) FROM tasks WHERE employee_id = ? AND status IN ('pending', 'in_progress')",
                (assignment.employee_id,),
            ).fetchone()[0] >= 3:
                raise HTTPException(status_code=409, detail="Employee has reached the active task limit.")
            cursor = connection.execute(
                """
                INSERT INTO tasks
                    (title, description, employee_id, status, created_at, updated_at, business_id, task_kind, mission_type)
                VALUES (?, ?, ?, 'pending', ?, ?, ?, 'owner', ?)
                """,
                (
                    assignment.title.strip(),
                    assignment.description.strip(),
                    assignment.employee_id,
                    now,
                    now,
                    business_id,
                    assignment.assignment_role.strip(),
                ),
            )
            connection.execute(
                """
                INSERT INTO business_assignments
                    (business_id, employee_id, assignment_role, current_project, assigned_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (business_id, assignment.employee_id, assignment.assignment_role.strip(), business["title"], now),
            )
            add_activity(connection, f"Employee assigned to business {business['title']}: {assignment.title.strip()}")
            return dict(connection.execute("SELECT * FROM tasks WHERE id = ?", (cursor.lastrowid,)).fetchone())

    @app.get("/api/revival-missions")
    def list_revival_missions():
        with db.connect() as connection:
            return [
                dict(row)
                for row in connection.execute(
                    """
                    SELECT m.*, i.title AS business_title FROM revival_missions m
                    JOIN businesses b ON b.id = m.business_id
                    JOIN business_ideas i ON i.id = b.idea_id ORDER BY m.id DESC
                    """
                )
            ]

    @app.post("/api/revival-missions/{mission_id}/advance")
    def advance_revival_mission(
        mission_id: int,
        update: RevivalAdvance,
        x_owner_token: str | None = Header(default=None),
    ):
        authorize_owner(x_owner_token)
        with db.connect() as connection:
            return empire.advance_revival(
                connection, mission_id, update.phase, update.new_market_information
            )

    @app.get("/api/management/reports")
    def list_management_reports(limit: int = Query(default=30, ge=1, le=100)):
        with db.connect() as connection:
            return [
                {**dict(row), "content": json.loads(row["content"])}
                for row in connection.execute(
                    "SELECT * FROM management_reports ORDER BY id DESC LIMIT ?", (limit,)
                )
            ]

    @app.post("/api/management/run", status_code=201)
    def run_management_report(x_owner_token: str | None = Header(default=None)):
        authorize_owner(x_owner_token)
        return run_management_cycle(db)

    @app.get("/api/finance/summary")
    def get_finance_summary():
        with db.connect() as connection:
            return finance.finance_summary(connection)

    @app.get("/api/finance/transactions")
    def list_financial_transactions(limit: int = Query(default=100, ge=1, le=500)):
        with db.connect() as connection:
            return finance.finance_transactions(connection, limit)

    @app.put("/api/finance/spending-limit")
    def update_spending_limit(
        update: SpendingLimitUpdate,
        x_owner_token: str | None = Header(default=None),
    ):
        authorize_owner(x_owner_token)
        with db.connect() as connection:
            return finance.set_spending_limit(connection, update.amount_cents)

    @app.post("/api/finance/pending-payments", status_code=201)
    def create_pending_payment(
        payment: PendingPaymentCreate,
        x_owner_token: str | None = Header(default=None),
    ):
        authorize_owner(x_owner_token)
        with db.connect() as connection:
            return finance.record_pending_payment(connection, **payment.model_dump())

    @app.post("/api/finance/pending-payments/{pending_id}/settle", status_code=201)
    def settle_pending_payment(
        pending_id: int,
        settlement: SettlementCreate,
        x_owner_token: str | None = Header(default=None),
    ):
        authorize_owner(x_owner_token)
        with db.connect() as connection:
            transaction = finance.settle_payment(connection, pending_id, **settlement.model_dump())
            empire.reward_profitable_contributors(connection, transaction["business_id"])
            return transaction

    @app.post("/api/finance/adjustments", status_code=201)
    def create_financial_adjustment(
        adjustment: FinancialAdjustment,
        x_owner_token: str | None = Header(default=None),
    ):
        authorize_owner(x_owner_token)
        with db.connect() as connection:
            return finance.record_adjustment(connection, **adjustment.model_dump())

    @app.post("/api/finance/withdrawal-requests", status_code=202)
    def create_withdrawal_request(
        request: WithdrawalRequest,
        x_owner_token: str | None = Header(default=None),
    ):
        authorize_owner(x_owner_token)
        with db.connect() as connection:
            transaction = finance.request_withdrawal(connection, **request.model_dump())
            return {
                "transaction": transaction,
                "execution_status": "disabled",
                "message": "Virtual ledger request saved only. No bank or payout integration is configured; no money was transferred.",
            }

    @app.get("/api/employees")
    def list_employees():
        with db.connect() as connection:
            return [dict(row) for row in connection.execute("SELECT * FROM employees ORDER BY rowid")]

    @app.get("/api/employees/{employee_id}/profile")
    def get_employee_profile(employee_id: str):
        with db.connect() as connection:
            return employee_profile(connection, employee_id)

    @app.post("/api/employees/{employee_id}/rewards", status_code=201)
    def award_employee_recognition(
        employee_id: str,
        reward: RecognitionCreate,
        x_owner_token: str | None = Header(default=None),
    ):
        authorize_owner(x_owner_token)
        with db.connect() as connection:
            return empire.award_recognition(
                connection,
                employee_id,
                reward.business_id,
                reward.achievement_code,
                reward.evidence_ref,
            )

    @app.post("/api/employees/{employee_id}/share", status_code=201)
    def share_employee_finding(employee_id: str, share: TeamShareCreate):
        interactive_chat_waiting.set()
        if not model_lock.acquire(timeout=90):
            interactive_chat_waiting.clear()
            raise HTTPException(status_code=503, detail="The local AI is busy. Please try again shortly.")
        try:
            with db.connect() as connection:
                sender = connection.execute("SELECT * FROM employees WHERE id = ?", (employee_id,)).fetchone()
                recipient = connection.execute(
                    "SELECT * FROM employees WHERE id = ?", (share.recipient_employee_id,)
                ).fetchone()
            if sender is None or recipient is None:
                raise HTTPException(status_code=404, detail="Sender or recipient employee not found.")
            status = ollama.status()
            if not status["connected"]:
                raise HTTPException(status_code=503, detail=status["error"])
            model = select_chat_model(
                status["models"],
                share.model or os.getenv("OLLAMA_CHAT_MODEL"),
            )
            if not model or model not in status["models"]:
                raise HTTPException(status_code=503, detail="No available local Ollama model.")
            prompt = (
                f"You are {sender['name']} ({sender['role']}). Share a concise business finding with "
                f"{recipient['name']} ({recipient['role']}) based on this request: {share.request.strip()}. "
                "This is simulated internal analysis, not verified market research. Do not claim real revenue "
                "or take actions, make purchases, or promise outcomes."
            )
            try:
                content = ollama.chat(
                    model,
                    [{"role": "system", "content": "You are an internal AI employee. Be explicit about uncertainty."},
                     {"role": "user", "content": prompt}],
                )
            except OllamaError as error:
                raise HTTPException(status_code=503, detail=str(error)) from error
            with db.connect() as connection:
                cursor = connection.execute(
                    """
                    INSERT INTO team_messages
                        (sender_employee_id, recipient_employee_id, request, content, model, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        employee_id,
                        share.recipient_employee_id,
                        share.request.strip(),
                        content,
                        model,
                        timestamp(),
                    ),
                )
                add_activity(connection, f"{sender['name']} shared an internal finding with {recipient['name']}.")
                return dict(
                    connection.execute("SELECT * FROM team_messages WHERE id = ?", (cursor.lastrowid,)).fetchone()
                )
        finally:
            model_lock.release()

    @app.post("/api/tasks", status_code=201)
    def create_task(task: TaskCreate):
        now = timestamp()
        with db.connect() as connection:
            employee = connection.execute(
                "SELECT name FROM employees WHERE id = ?", (task.employee_id,)
            ).fetchone()
            if employee is None:
                raise HTTPException(status_code=404, detail="Employee not found.")
            cursor = connection.execute(
                """
                INSERT INTO tasks (title, description, employee_id, status, created_at, updated_at)
                VALUES (?, ?, ?, 'pending', ?, ?)
                """,
                (task.title.strip(), task.description.strip(), task.employee_id, now, now),
            )
            add_activity(connection, f"Task assigned to {employee['name']}: {task.title.strip()}")
            row = connection.execute(
                """
                SELECT tasks.*, employees.name AS employee_name FROM tasks
                JOIN employees ON employees.id = tasks.employee_id WHERE tasks.id = ?
                """,
                (cursor.lastrowid,),
            ).fetchone()
            return dict(row)

    @app.patch("/api/tasks/{task_id}")
    def update_task(task_id: int, update: TaskUpdate):
        now = timestamp()
        with db.connect() as connection:
            task = connection.execute(
                "SELECT title FROM tasks WHERE id = ?", (task_id,)
            ).fetchone()
            if task is None:
                raise HTTPException(status_code=404, detail="Task not found.")
            completed_at = now if update.status == "completed" else None
            previous = connection.execute(
                "SELECT status, attempts FROM tasks WHERE id = ?", (task_id,)
            ).fetchone()
            if previous["status"] == "failed" and update.status == "completed":
                # A failed task is not completed work. Requeue it so the employee
                # actually runs it (or the owner retries it explicitly).
                raise HTTPException(
                    status_code=409,
                    detail="A failed task cannot be marked completed. Retry it instead so the work really runs.",
                )
            connection.execute(
                """
                UPDATE tasks SET status = ?, updated_at = ?, completed_at = ?,
                    result = COALESCE(?, result),
                    next_attempt_at = NULL
                WHERE id = ?
                """,
                (update.status, now, completed_at, update.result, task_id),
            )
            record_task_event(
                connection, task_id, "status_changed",
                f"Status changed from {previous['status']} to {update.status} by the owner."
                + (f" Result note: {update.result.strip()[:400]}" if update.result else ""),
            )
            add_activity(connection, f"Task updated to {update.status.replace('_', ' ')}: {task['title']}")
            row = connection.execute(
                """
                SELECT tasks.*, employees.name AS employee_name FROM tasks
                JOIN employees ON employees.id = tasks.employee_id WHERE tasks.id = ?
                """,
                (task_id,),
            ).fetchone()
            if row["business_id"] is not None and update.status == "completed":
                empire.reward_profitable_contributors(connection, row["business_id"])
            return dict(row)

    @app.post("/api/ideas", status_code=201)
    def create_idea(idea: IdeaCreate):
        with db.connect() as connection:
            cursor = connection.execute(
                "INSERT INTO business_ideas (title, description, created_at) VALUES (?, ?, ?)",
                (idea.title.strip(), idea.description.strip(), timestamp()),
            )
            add_activity(connection, f"Business idea added: {idea.title.strip()}")
            return dict(
                connection.execute(
                    "SELECT * FROM business_ideas WHERE id = ?", (cursor.lastrowid,)
                ).fetchone()
            )

    @app.patch("/api/ideas/{idea_id}")
    def update_idea(
        idea_id: int,
        update: IdeaUpdate,
        x_owner_token: str | None = Header(default=None),
    ):
        if update.status == "approved":
            authorize_owner(x_owner_token)
        with db.connect() as connection:
            idea = connection.execute(
                "SELECT title FROM business_ideas WHERE id = ?", (idea_id,)
            ).fetchone()
            if idea is None:
                raise HTTPException(status_code=404, detail="Business idea not found.")
            if update.status == "approved":
                business = empire.approve_idea(connection, idea_id)
                return {**dict(connection.execute(
                    "SELECT * FROM business_ideas WHERE id = ?", (idea_id,)
                ).fetchone()), "business_id": business["id"]}
            connection.execute(
                "UPDATE business_ideas SET status = ? WHERE id = ?",
                (update.status, idea_id),
            )
            add_activity(connection, f"Business idea marked {update.status}: {idea['title']}")
            return dict(
                connection.execute(
                    "SELECT * FROM business_ideas WHERE id = ?", (idea_id,)
                ).fetchone()
            )

    @app.get("/api/employees/{employee_id}/messages")
    def list_messages(employee_id: str):
        with db.connect() as connection:
            if connection.execute(
                "SELECT 1 FROM employees WHERE id = ?", (employee_id,)
            ).fetchone() is None:
                raise HTTPException(status_code=404, detail="Employee not found.")
            return [
                dict(row)
                for row in connection.execute(
                    "SELECT * FROM messages WHERE employee_id = ? ORDER BY id",
                    (employee_id,),
                )
            ]

    @app.post("/api/employees/{employee_id}/messages/stream")
    def stream_employee_message(employee_id: str, message: MessageCreate):
        content = message.content.strip()
        if not content:
            raise HTTPException(status_code=422, detail="Message cannot be blank.")
        with db.connect() as connection:
            employee = connection.execute("SELECT * FROM employees WHERE id = ?", (employee_id,)).fetchone()
            if employee is None:
                raise HTTPException(status_code=404, detail="Employee not found.")
            history = [
                {"role": row["role"], "content": row["content"]}
                for row in connection.execute(
                    "SELECT role, content FROM messages WHERE employee_id = ? ORDER BY id DESC LIMIT 8",
                    (employee_id,),
                )
            ]

        def event(payload: dict) -> str:
            return "data: " + json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n\n"

        def generate():
            interactive_chat_waiting.set()
            yield event({"type": "status", "detail": "Prioritising your conversation over background work…"})
            acquired = model_lock.acquire(timeout=32)
            if not acquired:
                interactive_chat_waiting.clear()
                yield event({"type": "error", "detail": "The local AI is busy with a background task. Please try again in a few seconds; chat has priority over the next task."})
                return
            try:
                status = ollama.status()
                if not status.get("connected"):
                    yield event({"type": "error", "detail": status.get("error") or "Ollama is offline. Start Ollama and try again."})
                    return
                configured_model = message.model or os.getenv("OLLAMA_CHAT_MODEL")
                model = select_chat_model(status.get("models", []), configured_model)
                if not model:
                    yield event({"type": "error", "detail": "No conversational model is installed. In PowerShell run: ollama pull qwen3.5:0.8b"})
                    return
                system_message = (
                    f"You are {employee['name']}, the {employee['role']} at AI Money Town. "
                    f"Specialty: {employee['specialty']}. Be a friendly, natural teammate: direct, warm, "
                    "practical, and concise. Answer first in 1-3 short sentences. Avoid long reasoning and "
                    "do not repeat greetings or your job title. Be honest about work not yet done. Separate "
                    "ideas and simulations from verified facts. Never make purchases, contact customers, "
                    "publish, transfer money, or claim simulated revenue is real."
                )
                if employee_id == "finance-analyst":
                    system_message += (
                        " You are the town's Banker and Treasurer, but this application is only a virtual "
                        "accounting ledger. You do not physically hold money, connect to a bank, or deposit "
                        "funds onto a card. If asked to deposit or withdraw, explain that no payout provider "
                        "or eligible destination account is connected. Never claim a transfer happened. "
                        "When the owner later has an eligible account, a real provider integration and required "
                        "authorizations must be configured before any payout can occur. Never ask for or store card numbers."
                    )
                conversation = [
                    {"role": "system", "content": system_message},
                    *reversed(history),
                    {"role": "user", "content": content},
                ]
                now = timestamp()
                with db.connect() as connection:
                    connection.execute(
                        "INSERT INTO messages (employee_id, role, content, created_at) VALUES (?, 'user', ?, ?)",
                        (employee_id, content, now),
                    )
                    add_activity(connection, f"{employee['name']} received a message.")
                yield event({"type": "meta", "model": model, "employee": employee["name"]})
                answer_parts: list[str] = []
                stream_method = getattr(ollama, "stream_chat", None)
                if callable(stream_method):
                    try:
                        for token in stream_method(
                            model, conversation, options={"num_predict": 48, "num_ctx": 1024, "temperature": 0.58}
                        ):
                            answer_parts.append(token)
                            yield event({"type": "token", "content": token})
                    except OllamaError:
                        # Some older Ollama/model combinations fail on streaming.
                        # If no answer token arrived, retry once using the regular chat endpoint.
                        if answer_parts:
                            raise
                        yield event({"type": "status", "detail": "Retrying with the standard local chat endpoint…"})
                        answer = ollama.chat(
                            model, conversation, options={"num_predict": 48, "num_ctx": 1024, "temperature": 0.58}
                        )
                        answer_parts.append(answer)
                        yield event({"type": "token", "content": answer})
                else:
                    answer = ollama.chat(
                        model, conversation, options={"num_predict": 48, "num_ctx": 1024, "temperature": 0.58}
                    )
                    answer_parts.append(answer)
                    yield event({"type": "token", "content": answer})
                answer = "".join(answer_parts).strip()
                if not answer:
                    # A few Ollama/model combinations finish a stream without content chunks.
                    # Retry once through the non-streaming endpoint before reporting failure.
                    yield event({"type": "status", "detail": "Finishing the reply through the standard local chat endpoint…"})
                    answer = ollama.chat(
                        model, conversation,
                        options={"num_predict": 48, "num_ctx": 1024, "temperature": 0.58},
                    ).strip()
                    if answer:
                        yield event({"type": "token", "content": answer})
                if not answer:
                    yield event({"type": "error", "detail": "Ollama finished without answer text. Check the selected model by running: ollama run qwen3.5:0.8b"})
                    return
                finished_at = timestamp()
                with db.connect() as connection:
                    connection.execute(
                        "INSERT INTO messages (employee_id, role, content, created_at) VALUES (?, 'assistant', ?, ?)",
                        (employee_id, answer, finished_at),
                    )
                    add_activity(connection, f"{employee['name']} replied in a conversation.")
                yield event({"type": "done", "model": model})
            except OllamaError as error:
                yield event({"type": "error", "detail": str(error)})
            except Exception:
                logger.exception("Employee chat stream failed for employee %s.", employee_id)
                yield event({"type": "error", "detail": "The local chat encountered an unexpected error. Check the town server window for details."})
            finally:
                model_lock.release()
                interactive_chat_waiting.clear()

        return StreamingResponse(
            generate(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no"},
        )

    @app.post("/api/employees/{employee_id}/messages", status_code=201)
    def send_message(employee_id: str, message: MessageCreate):
        content = message.content.strip()
        if not content:
            raise HTTPException(status_code=422, detail="Message cannot be blank.")
        with db.connect() as connection:
            employee = connection.execute(
                "SELECT * FROM employees WHERE id = ?", (employee_id,)
            ).fetchone()
            if employee is None:
                raise HTTPException(status_code=404, detail="Employee not found.")
            history = [
                {"role": row["role"], "content": row["content"]}
                for row in connection.execute(
                    """
                    SELECT role, content FROM messages
                    WHERE employee_id = ? ORDER BY id DESC LIMIT 8
                    """,
                    (employee_id,),
                )
            ]
        interactive_chat_waiting.set()
        acquired = model_lock.acquire(timeout=150)
        if not acquired:
            interactive_chat_waiting.clear()
            raise HTTPException(status_code=503, detail="The local AI is still finishing another task. Please try again shortly.")
        try:
            status = ollama.status()
            if not status["connected"]:
                raise HTTPException(status_code=503, detail=status["error"])
            models = status["models"]
            configured_model = message.model or os.getenv("OLLAMA_CHAT_MODEL")
            model = select_chat_model(models, configured_model)
            if not model or model not in status["models"]:
                raise HTTPException(
                    status_code=503,
                    detail="No conversational Ollama model is installed. Install qwen3.5:0.8b or configure OLLAMA_CHAT_MODEL.",
                )
            system_message = (
                f"You are {employee['name']}, the {employee['role']} at AI Money Town. "
                f"Specialty: {employee['specialty']}. Be a friendly, natural teammate: direct, "
                "warm, practical, and concise. Answer the question first in 2-5 short sentences. "
                "Use your department's perspective and ask at most one follow-up question. "
                "Do not repeat greetings or your job title. Be honest about what you have and "
                "have not done. Separate ideas and simulations from verified facts. You cannot "
                "make purchases, contact customers, publish, transfer money, or claim simulated "
                "revenue as real."
            )
            if employee_id == "finance-analyst":
                system_message += (
                    " You are the town's Banker and Treasurer, but this application is only a virtual "
                    "accounting ledger. You do not physically hold money, connect to a bank, or deposit "
                    "funds onto a card. If asked to deposit or withdraw, explain that no payout provider "
                    "or eligible destination account is connected. Never claim a transfer happened. "
                    "When the owner later has an eligible account, a real provider integration and required "
                    "authorizations must be configured before any payout can occur. Never ask for or store card numbers."
                )
            answer = ollama.chat(
                model,
                [{"role": "system", "content": system_message}, *reversed(history), {"role": "user", "content": content}],
                options={"num_predict": 88, "num_ctx": 2048, "temperature": 0.62},
            )
            now = timestamp()
            with db.connect() as connection:
                connection.executemany(
                    """
                    INSERT INTO messages (employee_id, role, content, created_at)
                    VALUES (?, ?, ?, ?)
                    """,
                    [
                        (employee_id, "user", content, now),
                        (employee_id, "assistant", answer, now),
                    ],
                )
                add_activity(connection, f"{employee['name']} had a conversation.")
                rows = connection.execute(
                    """
                    SELECT * FROM messages WHERE employee_id = ? ORDER BY id DESC LIMIT 2
                    """,
                    (employee_id,),
                ).fetchall()
            return {"messages": [dict(row) for row in reversed(rows)], "model": model}
        except OllamaError as error:
            raise HTTPException(status_code=503, detail=str(error)) from error
        finally:
            model_lock.release()
            interactive_chat_waiting.clear()

    @app.get("/api/system/health")
    def system_health():
        database_ok = True
        database_error = None
        try:
            with db.connect() as connection:
                connection.execute("SELECT 1").fetchone()
        except Exception as error:  # noqa: BLE001 - health must report, not raise
            database_ok = False
            database_error = str(error)
        workspace = deliverables.workspace_root()
        try:
            workspace.mkdir(parents=True, exist_ok=True)
            workspace_writable = os.access(workspace, os.W_OK)
        except OSError:
            workspace_writable = False
        ollama_state = ollama.status()
        queue = queue_status(db, ollama)
        return {
            "version": app.version,
            "database": {"ok": database_ok, "path": str(db.path), "error": database_error},
            "workspace": {"path": str(workspace), "writable": workspace_writable},
            "scheduler": {
                "enabled": scheduler_enabled,
                "interval_seconds": scheduler_interval(),
                "task_concurrency": 1,
                "max_attempts": max_attempts(),
            },
            "ollama": ollama_state,
            "worker": queue,
            "model_roles": {
                "chat": os.getenv("OLLAMA_CHAT_MODEL") or None,
                "ideas": os.getenv("OLLAMA_IDEA_MODEL") or None,
                "product": os.getenv("OLLAMA_MODEL_PRODUCT") or None,
                "research": os.getenv("OLLAMA_MODEL_RESEARCH") or None,
                "finance": os.getenv("OLLAMA_MODEL_FINANCE") or None,
                "quality": os.getenv("OLLAMA_MODEL_QUALITY") or None,
                "worker": os.getenv("OLLAMA_WORKER_MODEL") or None,
            },
            "limits": {
                "rate_limit_per_minute": limit_per_minute,
                "max_body_bytes": max_body_bytes,
                "max_attempts": max_attempts(),
            },
            "simulation_only": True,
        }

    @app.get("/api/system/queue")
    def get_worker_queue():
        return queue_status(db, ollama)

    @app.get("/api/tasks/{task_id}/events")
    def task_events(task_id: int):
        with db.connect() as connection:
            if connection.execute("SELECT 1 FROM tasks WHERE id = ?", (task_id,)).fetchone() is None:
                raise HTTPException(status_code=404, detail="Task not found.")
            return [
                dict(row)
                for row in connection.execute(
                    "SELECT * FROM task_events WHERE task_id = ? ORDER BY id DESC", (task_id,)
                )
            ]

    @app.post("/api/tasks/{task_id}/retry", status_code=202)
    def retry_task(task_id: int, x_owner_token: str | None = Header(default=None)):
        authorize_owner(x_owner_token)
        with db.connect() as connection:
            task = connection.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
            if task is None:
                raise HTTPException(status_code=404, detail="Task not found.")
            if task["status"] not in {"failed", "pending"}:
                raise HTTPException(status_code=409, detail="Only failed or queued tasks can be retried.")
            connection.execute(
                """UPDATE tasks SET status = 'pending', attempts = 0, last_error = '',
                   next_attempt_at = NULL, updated_at = ?, completed_at = NULL WHERE id = ?""",
                (timestamp(), task_id),
            )
            record_task_event(connection, task_id, "retry_scheduled", "Owner cleared the failure and requeued the task.")
            add_activity(connection, f"Owner requeued task: {task['title']}")
            return dict(connection.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone())

    @app.post("/api/tasks/{task_id}/run")
    def run_task_now(task_id: int, x_owner_token: str | None = Header(default=None)):
        """Run one queued task immediately instead of waiting for the scheduler."""
        authorize_owner(x_owner_token)
        with db.connect() as connection:
            task = connection.execute(
                "SELECT id, title, status FROM tasks WHERE id = ?", (task_id,)
            ).fetchone()
            if task is None:
                raise HTTPException(status_code=404, detail="Task not found.")
            if task["status"] == "in_progress":
                raise HTTPException(status_code=409, detail="This task is already running.")
            if task["status"] == "completed":
                raise HTTPException(status_code=409, detail="This task is already completed.")
            connection.execute(
                """UPDATE tasks SET status = 'pending', next_attempt_at = NULL,
                   completed_at = NULL, priority = 100, updated_at = ? WHERE id = ?""",
                (timestamp(), task_id),
            )
            record_task_event(connection, task_id, "claimed", "Owner requested an immediate run.")
        outcome = process_next_autonomous_task(db, ollama, model_lock, None)
        if outcome is None:
            raise HTTPException(
                status_code=503,
                detail="The worker could not start: the local model is busy or unavailable.",
            )
        return outcome

    @app.get("/api/deliverables")
    def list_all_deliverables(limit: int = Query(default=50, ge=1, le=200)):
        with db.connect() as connection:
            return deliverables.list_deliverables(connection, None, limit)

    @app.get("/api/businesses/{business_id}/deliverables")
    def list_business_deliverables(business_id: int):
        with db.connect() as connection:
            if connection.execute("SELECT 1 FROM businesses WHERE id = ?", (business_id,)).fetchone() is None:
                raise HTTPException(status_code=404, detail="Business not found.")
            return deliverables.list_deliverables(connection, business_id)

    @app.get("/api/deliverables/{deliverable_id}")
    def get_deliverable(deliverable_id: int):
        with db.connect() as connection:
            record = deliverables.get_deliverable(connection, deliverable_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Deliverable not found.")
        try:
            report = json.loads(record.get("validation_report") or "{}")
        except json.JSONDecodeError:
            report = {}
        return {**record, "validation": report, "files": deliverables.deliverable_files(record)}

    @app.get("/api/deliverables/{deliverable_id}/file")
    def read_deliverable_file(deliverable_id: int, name: str | None = Query(default=None)):
        with db.connect() as connection:
            record = deliverables.get_deliverable(connection, deliverable_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Deliverable not found.")
        try:
            path = deliverables.deliverable_path(record, name)
        except ValueError as error:
            raise HTTPException(status_code=400, detail=str(error)) from error
        except FileNotFoundError as error:
            raise HTTPException(status_code=404, detail="File not found in this deliverable.") from error
        return FileResponse(path, filename=path.name, media_type="text/plain" if path.suffix in {".txt", ".md", ".js", ".css", ".html"} else "application/octet-stream")

    @app.get("/api/deliverables/{deliverable_id}/preview")
    def preview_deliverable(deliverable_id: int):
        with db.connect() as connection:
            record = deliverables.get_deliverable(connection, deliverable_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Deliverable not found.")
        try:
            path = deliverables.deliverable_path(record, record["entry_file"])
        except (ValueError, FileNotFoundError) as error:
            raise HTTPException(status_code=404, detail="Preview file is missing.") from error
        return FileResponse(
            path,
            media_type="text/html",
            headers={
                # The sandbox directive gives the page a unique origin: it cannot
                # read this app's storage, cookies or API, even though it is served here.
                "Content-Security-Policy": "sandbox allow-scripts allow-forms; default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:; connect-src 'none'; base-uri 'none'; form-action 'none'",
                "X-Content-Type-Options": "nosniff",
                "Cache-Control": "no-store",
            },
        )

    @app.post("/api/businesses/{business_id}/products/build", status_code=201)
    def build_business_product(
        business_id: int,
        request: ProductBuildRequest,
        x_owner_token: str | None = Header(default=None),
    ):
        """Owner-triggered real product build using the local model."""
        authorize_owner(x_owner_token)
        with db.connect() as connection:
            business = connection.execute(
                """SELECT b.id, i.title FROM businesses b JOIN business_ideas i ON i.id = b.idea_id
                   WHERE b.id = ?""",
                (business_id,),
            ).fetchone()
        if business is None:
            raise HTTPException(status_code=404, detail="Business not found.")
        if not model_lock.acquire(timeout=5):
            raise HTTPException(status_code=503, detail="The local model is busy. Try again in a moment.")
        try:
            status = ollama.status()
            if not status.get("connected") or not status.get("models"):
                raise HTTPException(status_code=503, detail=status.get("error") or "Ollama is offline.")
            model = select_work_model(status["models"], "product")
            if not model:
                raise HTTPException(status_code=503, detail="No local model is installed for product work.")
            with db.connect() as connection:
                attempt = deliverables.generate_web_deliverable(
                    connection,
                    ollama,
                    business_id=business_id,
                    task_id=None,
                    employee_name="Gizmo McNoodle",
                    model=model,
                    kind=request.kind,
                )
                connection.execute(
                    "INSERT INTO business_events (business_id, event_type, details, created_at) VALUES (?, ?, ?, ?)",
                    (
                        business_id,
                        "product_build_requested",
                        (
                            f"Owner-requested build finished with status '{attempt['status']}' using {model}."
                            + (f" Deliverable #{attempt['deliverable']['id']} passed validation." if attempt["status"] == "built" else f" Reason: {attempt.get('error', 'validation failed')}")
                        ),
                        timestamp(),
                    ),
                )
                add_activity(
                    connection,
                    (
                        f"Product files built for {business['title']} (deliverable #{attempt['deliverable']['id']})."
                        if attempt["status"] == "built"
                        else f"Product build for {business['title']} did not produce a valid file: {attempt.get('error', 'validation failed')}"
                    ),
                )
        finally:
            model_lock.release()
        if attempt["status"] == "built":
            return attempt
        if attempt["status"] == "rejected":
            raise HTTPException(
                status_code=422,
                detail={"message": "The model produced a file that failed validation; nothing was recorded as built.",
                        **{k: v for k, v in attempt.items() if k != "status"}},
            )
        raise HTTPException(
            status_code=503,
            detail=attempt.get("error") or "The local model could not build the product.",
        )

    @app.get("/api/activity")
    def list_activity(limit: int = Query(default=20, ge=1, le=100)):
        with db.connect() as connection:
            return [
                dict(row)
                for row in connection.execute(
                    "SELECT * FROM activity ORDER BY id DESC LIMIT ?", (limit,)
                )
            ]

    return app

