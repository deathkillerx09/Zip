"""Real product deliverables for the AI Money Town pipeline.

The Product Builder must produce files that a person can actually open, not a
description of files. This module turns a local model reply into a validated
deliverable on disk, records it in the database, and refuses to call anything
"built" when validation failed.

Nothing here contacts the network, spends money, or publishes anything.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path

from .ollama import OllamaError

ROOT = Path(__file__).resolve().parents[2]

# Every generated file lives under this folder so the server never reads or
# writes an arbitrary path supplied by a request.
def workspace_root() -> Path:
    configured = os.getenv("AI_MONEY_TOWN_WORKSPACE", "").strip()
    base = Path(configured).expanduser() if configured else ROOT / "workspace"
    return base / "products"


def timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def slugify(value: str, limit: int = 48) -> str:
    cleaned = re.sub(r"[^a-z0-9]+", "-", (value or "").lower()).strip("-")
    return (cleaned[:limit].strip("-") or "product")


class _StructureParser(HTMLParser):
    """Counts the structural elements the validator cares about."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.counts: dict[str, int] = {}
        self.scripts: list[str] = []
        self._in_script = False
        self._script_buffer: list[str] = []
        self.title = ""
        self._in_title = False
        self.headings: list[str] = []

    def handle_starttag(self, tag, attrs):  # noqa: ANN001 - stdlib signature
        self.counts[tag] = self.counts.get(tag, 0) + 1
        if tag == "script":
            self._in_script = True
            self._script_buffer = []
        if tag == "title":
            self._in_title = True
        if tag in {"h1", "h2"}:
            self.headings.append(tag)

    def handle_endtag(self, tag):  # noqa: ANN001 - stdlib signature
        if tag == "script" and self._in_script:
            self._in_script = False
            body = "".join(self._script_buffer)
            if body.strip():
                self.scripts.append(body)
        if tag == "title":
            self._in_title = False

    def handle_data(self, data: str) -> None:
        if self._in_script:
            self._script_buffer.append(data)
        if self._in_title:
            self.title += data


@dataclass
class Validation:
    ok: bool
    issues: list[str] = field(default_factory=list)
    checks: dict[str, object] = field(default_factory=dict)

    def as_report(self) -> dict:
        return {"ok": self.ok, "issues": self.issues, "checks": self.checks}


EXTERNAL_RESOURCE = re.compile(r'(?:src|href)\s*=\s*["\'](?:https?:)?//', re.IGNORECASE)


def extract_html(text: str) -> str | None:
    """Return the HTML document inside a model reply, or None if there is none."""
    if not text:
        return None
    body = text.strip()
    fence = re.search(r"```(?:html)?\s*(.*?)```", body, re.IGNORECASE | re.DOTALL)
    if fence:
        body = fence.group(1).strip()
    start = re.search(r"<!doctype html|<html", body, re.IGNORECASE)
    end = body.lower().rfind("</html>")
    if start and end > start.start():
        return body[start.start():end + len("</html>")].strip()
    if start:
        return body[start.start():].strip()
    return None


def _js_check(scripts: list[str]) -> dict:
    node = shutil.which("node")
    if not node:
        return {"ran": False, "reason": "Node.js is not installed; JavaScript syntax was not checked."}
    failures = []
    for index, script in enumerate(scripts):
        with tempfile.NamedTemporaryFile("w", suffix=".mjs", delete=False, encoding="utf-8") as handle:
            handle.write(script)
            path = handle.name
        try:
            result = subprocess.run(
                [node, "--check", path], capture_output=True, text=True, timeout=20
            )
            if result.returncode != 0:
                failures.append(f"script #{index + 1}: {result.stderr.strip().splitlines()[-1] if result.stderr else 'syntax error'}")
        except (OSError, subprocess.SubprocessError) as error:  # pragma: no cover - environment specific
            failures.append(f"script #{index + 1}: could not be checked ({error})")
        finally:
            Path(path).unlink(missing_ok=True)
    return {"ran": True, "failures": failures}


def validate_html(html: str, kind: str = "web_app") -> Validation:
    """Structural, offline-safety and interactivity checks for a generated page."""
    issues: list[str] = []
    checks: dict[str, object] = {}
    lowered = html.lower()
    if len(html) < 600:
        issues.append(f"The page is only {len(html)} characters; it is too small to be a usable product.")
    if not re.search(r"<!doctype html|<html", lowered):
        issues.append("The page has no <html> document element.")
    for tag in ("</html>", "</body>", "</head>", "<body", "<head"):
        if tag not in lowered:
            issues.append(f"The page is missing {tag}.")
    if "<title" not in lowered:
        issues.append("The page has no <title>.")
    if "charset" not in lowered:
        issues.append("The page does not declare a character set.")
    if "viewport" not in lowered:
        issues.append("The page has no mobile viewport meta tag.")
    if EXTERNAL_RESOURCE.search(html):
        issues.append("The page loads a remote script, stylesheet or font; generated products must work offline.")
    for marker in ("{{", "}}", "lorem ipsum", "todo:", "your-api-key"):
        if marker in lowered:
            issues.append(f"The page still contains the placeholder text '{marker}'.")
    parser = _StructureParser()
    try:
        parser.feed(html)
        parser.close()
    except Exception as error:  # noqa: BLE001 - parser failure is a validation verdict
        issues.append(f"The HTML could not be parsed: {error}")
    checks["title"] = parser.title.strip()[:200]
    checks["elements"] = parser.counts
    checks["script_blocks"] = len(html.split("<script")) - 1
    if kind == "landing_page" and not parser.counts.get("h1"):
        issues.append("A landing page needs at least one <h1> headline.")
    if kind == "web_app":
        interactive = parser.counts.get("button", 0) + parser.counts.get("input", 0) + parser.counts.get("textarea", 0)
        if interactive == 0:
            issues.append("The application has no button or input, so it does nothing when opened.")
        if not parser.scripts:
            issues.append("The application has no JavaScript, so it has no behaviour.")
    if parser.scripts:
        js = _js_check(parser.scripts)
        checks["javascript"] = js
        for failure in js.get("failures", []):
            issues.append(f"JavaScript syntax error: {failure}")
    else:
        checks["javascript"] = {"ran": False, "reason": "No inline script to check."}
    checks["bytes"] = len(html.encode("utf-8"))
    return Validation(ok=not issues, issues=issues, checks=checks)


def _safe_directory(business_id: int, slug: str, deliverable_id: int | None = None) -> Path:
    root = workspace_root().resolve()
    name = f"business-{int(business_id)}-{slugify(slug, 32)}"
    if deliverable_id is not None:
        name = f"{name}-{int(deliverable_id)}"
    directory = (root / name).resolve()
    if root not in directory.parents and directory != root:
        raise ValueError("Resolved deliverable path escapes the workspace.")
    return directory


def build_prompt(
    *,
    business_title: str,
    business_description: str,
    brief: str,
    task_title: str,
    employee_name: str,
) -> list[dict[str, str]]:
    system = (
        f"You are {employee_name}, the product builder of a tiny honest software studio. "
        "You write complete, working, self-contained code. You never invent customers, sales or market facts."
    )
    brief_text = (brief or "").strip()[:2500]
    user = f"""Business: {business_title}
Idea: {business_description}
Assignment: {task_title}
Internal brief (may be empty or rough):
{brief_text}

Build the smallest genuinely usable version of this product as ONE self-contained HTML file.

Hard requirements:
- Start with <!doctype html>, include <head>, a <title>, a charset meta tag and a viewport meta tag.
- Put ALL CSS inside a <style> block and ALL JavaScript inside a <script> block.
- No external URLs: no CDN scripts, web fonts, images or API calls. It must work offline by double-clicking the file.
- No placeholder text such as "Lorem ipsum", "TODO", "{{...}}", or fake testimonials and logos.
- Real behaviour: every button or form must do something useful with the product's own logic (state kept in memory or localStorage).
- Keep it under about 400 lines; simple and clean beats ambitious and broken.
- Use a plain, readable layout with clear labels. No marketing claims, prices, or revenue figures.

Reply with the complete HTML file only, inside one ```html code block. No explanation before or after."""
    return [{"role": "system", "content": system}, {"role": "user", "content": user}]


def save_deliverable(
    connection,
    *,
    business_id: int,
    task_id: int | None,
    kind: str,
    name: str,
    files: dict[str, str],
    validation: Validation,
    generated_by: str,
    model: str,
) -> dict:
    """Write validated files under the workspace and record them."""
    if kind not in {"web_app", "landing_page", "document", "data", "python_tool"}:
        raise ValueError("Unsupported deliverable kind.")
    if not files:
        raise ValueError("A deliverable needs at least one file.")
    cursor = connection.execute(
        """INSERT INTO deliverables
           (business_id, task_id, kind, name, slug, directory, entry_file, file_count,
            byte_size, sha256, validation_status, validation_report, generated_by, model, created_at)
           VALUES (?, ?, ?, ?, ?, '', '', 0, 0, '', ?, ?, ?, ?, ?)""",
        (
            business_id, task_id, kind, name[:160], slugify(name),
            "passed" if validation.ok else "failed",
            json.dumps(validation.as_report(), separators=(",", ":")),
            generated_by, model, timestamp(),
        ),
    )
    deliverable_id = cursor.lastrowid
    directory = _safe_directory(business_id, name, deliverable_id)
    directory.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256()
    total_bytes = 0
    written: list[dict] = []
    for filename, content in files.items():
        safe_name = Path(filename).name
        if safe_name != filename or safe_name.startswith("."):
            raise ValueError(f"Invalid deliverable filename: {filename}")
        target = (directory / safe_name).resolve()
        if target.parent != directory:
            raise ValueError("Deliverable file path escapes its folder.")
        encoded = content.encode("utf-8")
        target.write_bytes(encoded)
        digest.update(safe_name.encode("utf-8") + encoded)
        total_bytes += len(encoded)
        written.append({"name": safe_name, "bytes": len(encoded)})
    entry_file = next((item["name"] for item in written if item["name"].endswith(".html")), written[0]["name"])
    manifest = {
        "name": name,
        "business_id": business_id,
        "task_id": task_id,
        "kind": kind,
        "entry_file": entry_file,
        "files": written,
        "validation": validation.as_report(),
        "generated_by": generated_by,
        "model": model,
        "created_at": timestamp(),
        "note": "Generated locally by the AI Money Town product builder. Not published anywhere.",
    }
    (directory / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    connection.execute(
        """UPDATE deliverables
           SET directory = ?, entry_file = ?, file_count = ?, byte_size = ?, sha256 = ?
           WHERE id = ?""",
        (
            str(directory.relative_to(workspace_root().resolve())),
            entry_file,
            len(written),
            total_bytes,
            digest.hexdigest(),
            deliverable_id,
        ),
    )
    return dict(connection.execute("SELECT * FROM deliverables WHERE id = ?", (deliverable_id,)).fetchone())


def business_brief(connection, business_id: int) -> dict:
    rows = connection.execute(
        """SELECT artifact_type, content FROM business_artifacts
           WHERE business_id = ? ORDER BY id DESC""",
        (business_id,),
    ).fetchall()
    briefs: dict[str, str] = {}
    for row in rows:
        briefs.setdefault(row["artifact_type"], row["content"])
    business = connection.execute(
        """SELECT i.title, i.description FROM businesses b
           JOIN business_ideas i ON i.id = b.idea_id WHERE b.id = ?""",
        (business_id,),
    ).fetchone()
    return {
        "title": business["title"] if business else f"Business {business_id}",
        "description": business["description"] if business else "",
        "briefs": briefs,
    }


def generate_web_deliverable(
    connection,
    ollama,
    *,
    business_id: int,
    task_id: int | None,
    employee_name: str,
    model: str,
    kind: str = "web_app",
    initial_reply: str | None = None,
) -> dict:
    """Ask the local model for a page, validate it, repair once, and save it.

    Returns ``{"status": "built"|"rejected"|"ai_error", ...}``. A rejected or
    failed generation writes no deliverable row claiming success.
    """
    context = business_brief(connection, business_id)
    brief = "\n\n".join(
        f"[{name}]\n{content}" for name, content in context["briefs"].items() if name in {"strategy_brief", "mvp_blueprint", "research_brief"}
    )
    messages = build_prompt(
        business_title=context["title"],
        business_description=context["description"],
        brief=brief,
        task_title=f"Build a working {kind.replace('_', ' ')}",
        employee_name=employee_name,
    )
    options = {"num_predict": 1200, "num_ctx": 4096, "temperature": 0.35}
    reply = initial_reply
    if not reply:
        try:
            reply = ollama.chat(model, messages, options)
        except OllamaError as error:
            return {"status": "ai_error", "error": str(error), "kind": error.kind}
    html = extract_html(reply)
    if html is None:
        return {
            "status": "rejected",
            "error": "The local model did not return an HTML document.",
            "reply_excerpt": reply[:400],
        }
    validation = validate_html(html, kind)
    if not validation.ok:
        repair = messages + [
            {"role": "assistant", "content": reply[:3000]},
            {
                "role": "user",
                "content": (
                    "The file failed these automated checks:\n- "
                    + "\n- ".join(validation.issues)
                    + "\n\nReturn the corrected complete HTML file only, inside one ```html block."
                ),
            },
        ]
        try:
            second = ollama.chat(model, repair, options)
        except OllamaError as error:
            return {"status": "ai_error", "error": str(error), "kind": error.kind}
        repaired_html = extract_html(second)
        if repaired_html is None:
            return {"status": "rejected", "error": "The repair reply contained no HTML document.", "issues": validation.issues}
        second_validation = validate_html(repaired_html, kind)
        if not second_validation.ok:
            return {
                "status": "rejected",
                "error": "The generated page failed validation twice.",
                "issues": second_validation.issues,
                "validation": second_validation.as_report(),
            }
        html, validation = repaired_html, second_validation
    deliverable = save_deliverable(
        connection,
        business_id=business_id,
        task_id=task_id,
        kind=kind,
        name=context["title"],
        files={"index.html": html},
        validation=validation,
        generated_by=employee_name,
        model=model,
    )
    return {"status": "built", "deliverable": deliverable, "validation": validation.as_report()}


def list_deliverables(connection, business_id: int | None = None, limit: int = 100) -> list[dict]:
    if business_id is None:
        rows = connection.execute(
            "SELECT * FROM deliverables ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    else:
        rows = connection.execute(
            "SELECT * FROM deliverables WHERE business_id = ? ORDER BY id DESC LIMIT ?",
            (business_id, limit),
        ).fetchall()
    return [dict(row) for row in rows]


def get_deliverable(connection, deliverable_id: int) -> dict | None:
    row = connection.execute("SELECT * FROM deliverables WHERE id = ?", (deliverable_id,)).fetchone()
    return dict(row) if row else None


def deliverable_path(record: dict, filename: str | None = None) -> Path:
    """Resolve a file inside a recorded deliverable folder, refusing escapes."""
    root = workspace_root().resolve()
    directory = (root / record["directory"]).resolve()
    if root not in directory.parents:
        raise ValueError("Recorded deliverable folder is outside the workspace.")
    target = (directory / (filename or record["entry_file"])).resolve()
    if directory not in target.parents and target != directory:
        raise ValueError("Requested file is outside the deliverable folder.")
    if not target.is_file():
        raise FileNotFoundError(filename or record["entry_file"])
    return target


def deliverable_files(record: dict) -> list[dict]:
    try:
        directory = deliverable_path(record, "manifest.json").parent
    except (FileNotFoundError, ValueError):
        return []
    files = []
    for path in sorted(directory.iterdir()):
        if path.is_file():
            files.append({"name": path.name, "bytes": path.stat().st_size})
    return files


def summarize(connection, business_id: int | None = None) -> dict:
    row = connection.execute(
        "SELECT COUNT(*) AS total, "
        "COALESCE(SUM(CASE WHEN validation_status = 'passed' THEN 1 ELSE 0 END), 0) AS valid "
        + ("FROM deliverables WHERE business_id = ?" if business_id is not None else "FROM deliverables"),
        (() if business_id is None else (business_id,)),
    ).fetchone()
    return {"deliverable_count": row["total"], "valid_deliverable_count": row["valid"]}
