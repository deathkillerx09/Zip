import sqlite3
import threading
import time
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from backend.app.database import Database
from backend.app.empire import approve_idea, transition_business
from backend.app.main import create_app
from backend.app.scheduler import (
    process_next_autonomous_task,
    recover_unfinished_tasks,
    run_management_cycle,
)


OWNER_HEADERS = {"X-Owner-Token": "phase2-test-owner"}


class FakeOllama:
    def __init__(self):
        self.calls = 0

    def status(self):
        return {"connected": True, "models": ["test-model"], "error": None}

    def chat(self, model, messages, options=None):
        self.calls += 1
        return "Internal finding for the receiving department."


def build_client(tmp_path: Path, monkeypatch, *, owner_token=True):
    if owner_token:
        monkeypatch.setenv("AI_MONEY_TOWN_OWNER_TOKEN", "phase2-test-owner")
    else:
        monkeypatch.delenv("AI_MONEY_TOWN_OWNER_TOKEN", raising=False)
    path = tmp_path / "town.sqlite3"
    return TestClient(create_app(path, FakeOllama(), scheduler_enabled=False)), path


def approve_business(client: TestClient) -> int:
    idea = client.post(
        "/api/ideas",
        json={"title": "Community repair network", "description": "A test business concept."},
    ).json()
    approved = client.patch(
        f"/api/ideas/{idea['id']}",
        headers=OWNER_HEADERS,
        json={"status": "approved"},
    )
    assert approved.status_code == 200
    return approved.json()["business_id"]


def advance_to_live(client: TestClient, business_id: int) -> None:
    for stage in ("development", "simulation", "ready_for_approval", "live_business"):
        response = client.post(
            f"/api/businesses/{business_id}/transition",
            headers=OWNER_HEADERS,
            json={"target": stage},
        )
        assert response.status_code == 200, response.text


def test_approved_ideas_enter_persistent_business_lifecycle_and_validate_transitions(tmp_path, monkeypatch):
    client, path = build_client(tmp_path, monkeypatch)
    business_id = approve_business(client)

    unauthorized = client.post(
        f"/api/businesses/{business_id}/transition",
        json={"target": "development"},
    )
    assert unauthorized.status_code == 401
    assert client.get("/api/businesses/1").json()["business"]["stage"] == "research"
    assert client.patch(
        "/api/ideas/1",
        headers=OWNER_HEADERS,
        json={"status": "approved"},
    ).json()["business_id"] == business_id

    moved = client.post(
        f"/api/businesses/{business_id}/transition",
        headers=OWNER_HEADERS,
        json={"target": "development"},
    )
    assert moved.status_code == 200
    forbidden = client.post(
        f"/api/businesses/{business_id}/transition",
        headers=OWNER_HEADERS,
        json={"target": "stable"},
    )
    assert forbidden.status_code == 409

    reopened = TestClient(create_app(path, FakeOllama(), scheduler_enabled=False))
    history = reopened.get(f"/api/businesses/{business_id}").json()
    assert history["business"]["stage"] == "development"
    assert [event["event_type"] for event in history["events"]].count("stage_transition") == 1
    assert len(history["tasks"]) == 2
    assert history["assignments"][0]["employee_id"] == "builder"


def test_estimated_revenue_never_counts_as_actual_and_scheduler_creates_revival_mission(tmp_path, monkeypatch):
    client, path = build_client(tmp_path, monkeypatch)
    business_id = approve_business(client)
    advance_to_live(client, business_id)
    metrics = client.post(
        f"/api/businesses/{business_id}/metrics",
        headers=OWNER_HEADERS,
        json={
            "estimated_revenue_cents": 500000,
            "retention_pct": 24,
            "satisfaction_pct": 35,
            "growth_pct": -18,
            "customer_feedback": "Customers report difficult onboarding.",
            "competitor_analysis": "A competitor offers simpler setup.",
        },
    )
    assert metrics.status_code == 201
    assert client.get("/api/finance/summary").json()["actual_revenue_cents"] == 0

    database = Database(path)
    report = run_management_cycle(database)
    assert report["declines_detected"][0]["business_id"] == business_id
    repeated = run_management_cycle(database)
    assert len(repeated["declines_detected"]) == 0
    missions = client.get("/api/revival-missions").json()
    assert len(missions) == 1
    assert "onboarding" in missions[0]["customer_feedback"]
    assert "retention" in missions[0]["sales_retention_analysis"]
    with database.connect() as connection:
        assert connection.execute(
            "SELECT COUNT(*) FROM tasks WHERE mission_type = 'investigating'"
        ).fetchone()[0] == 1

    mission_id = missions[0]["id"]
    planned = client.post(
        f"/api/revival-missions/{mission_id}/advance",
        headers=OWNER_HEADERS,
        json={"phase": "solution_planning"},
    )
    assert planned.status_code == 200
    assert client.get(f"/api/businesses/{business_id}").json()["business"]["stage"] == "revival"
    assert any(task["employee_id"] == "strategist" for task in client.get(f"/api/businesses/{business_id}").json()["tasks"])


def test_ledger_verification_immutability_and_spending_safeguards(tmp_path, monkeypatch):
    client, path = build_client(tmp_path, monkeypatch)
    business_id = approve_business(client)
    advance_to_live(client, business_id)

    pending = client.post(
        "/api/finance/pending-payments",
        headers=OWNER_HEADERS,
        json={
            "business_id": business_id,
            "amount_cents": 10000,
            "external_reference": "provider-order-41",
        },
    )
    assert pending.status_code == 201
    summary = client.get("/api/finance/summary").json()
    assert summary["actual_revenue_cents"] == 0
    assert summary["pending_payments_cents"] == 10000
    assert summary["available_business_funds_cents"] == 0

    settlement = client.post(
        f"/api/finance/pending-payments/{pending.json()['id']}/settle",
        headers=OWNER_HEADERS,
        json={"amount_cents": 6000, "evidence_ref": "bank-statement-row-41"},
    )
    assert settlement.status_code == 201
    assert settlement.json()["is_verified"] == 1
    assert client.get("/api/finance/summary").json()["actual_revenue_cents"] == 6000
    over_settlement = client.post(
        f"/api/finance/pending-payments/{pending.json()['id']}/settle",
        headers=OWNER_HEADERS,
        json={"amount_cents": 5000, "evidence_ref": "bank-statement-row-42"},
    )
    assert over_settlement.status_code == 409

    no_budget = client.post(
        "/api/finance/adjustments",
        headers=OWNER_HEADERS,
        json={
            "business_id": business_id,
            "transaction_type": "expense",
            "amount_cents": 100,
            "external_reference": "hosting-invoice-1",
            "evidence_ref": "invoice-record-1",
        },
    )
    assert no_budget.status_code == 409
    assert client.put(
        "/api/finance/spending-limit",
        headers=OWNER_HEADERS,
        json={"amount_cents": 5000},
    ).status_code == 200
    expense = client.post(
        "/api/finance/adjustments",
        headers=OWNER_HEADERS,
        json={
            "business_id": business_id,
            "transaction_type": "expense",
            "amount_cents": 1000,
            "external_reference": "receipt-1",
            "evidence_ref": "bookkeeping-attachment-1",
        },
    )
    assert expense.status_code == 201
    assert client.get("/api/finance/summary").json()["available_business_funds_cents"] == 5000

    refund = client.post(
        "/api/finance/adjustments",
        headers=OWNER_HEADERS,
        json={
            "business_id": business_id,
            "transaction_type": "refund",
            "amount_cents": 500,
            "external_reference": str(settlement.json()["id"]),
            "evidence_ref": "refund-record-1",
        },
    )
    assert refund.status_code == 201
    ledger = client.get("/api/finance/transactions").json()
    assert len(ledger) == 4
    with sqlite3.connect(path) as connection:
        with pytest.raises(sqlite3.IntegrityError, match="immutable"):
            connection.execute("UPDATE transactions SET amount_cents = 1 WHERE id = 1")
        with pytest.raises(sqlite3.IntegrityError, match="immutable"):
            connection.execute("DELETE FROM transactions WHERE id = 1")
        assert connection.execute("SELECT COUNT(*) FROM transaction_audit").fetchone()[0] == 4

    withdrawn = client.post(
        "/api/finance/withdrawal-requests",
        headers=OWNER_HEADERS,
        json={"amount_cents": 500, "external_reference": "owner-request-1"},
    )
    assert withdrawn.status_code == 202
    assert withdrawn.json()["execution_status"] == "disabled"
    assert "no money was transferred" in withdrawn.json()["message"]


def test_employee_recognition_is_deterministic_persistent_and_simulated(tmp_path, monkeypatch):
    client, path = build_client(tmp_path, monkeypatch)
    reward = client.post(
        "/api/employees/researcher/rewards",
        headers=OWNER_HEADERS,
        json={
            "achievement_code": "good_research",
            "evidence_ref": "research-review-2026-09",
        },
    )
    assert reward.status_code == 201
    assert reward.json()["experience_points"] == 45

    second = client.post(
        "/api/employees/researcher/rewards",
        headers=OWNER_HEADERS,
        json={
            "achievement_code": "security_quality",
            "evidence_ref": "security-review-2026-10",
        },
    )
    assert second.status_code == 201
    assert second.json()["experience_points"] == 90
    duplicate = client.post(
        "/api/employees/researcher/rewards",
        headers=OWNER_HEADERS,
        json={
            "achievement_code": "security_quality",
            "evidence_ref": "security-review-copy",
        },
    )
    assert duplicate.status_code == 409

    profile = client.get("/api/employees/researcher/profile").json()
    assert profile["profile"]["experience_points"] == 135
    assert profile["profile"]["career_level"] == "associate"
    assert profile["profile"]["morale"] == 63
    assert "not real emotions" in profile["morale_notice"]
    restarted = TestClient(create_app(path, FakeOllama(), scheduler_enabled=False))
    assert restarted.get("/api/employees/researcher/profile").json()["profile"]["morale"] == 63


def test_task_recovery_requeues_work_without_losing_task(tmp_path):
    path = tmp_path / "recovery.sqlite3"
    database = Database(path)
    database.initialize()
    with database.connect() as connection:
        connection.execute(
            """
            INSERT INTO tasks
                (title, description, employee_id, status, created_at, updated_at)
            VALUES ('Resume analysis', '', 'researcher', 'in_progress', 'then', 'then')
            """
        )

    assert recover_unfinished_tasks(database) == 1
    with database.connect() as connection:
        tasks = connection.execute("SELECT title, status FROM tasks").fetchall()
        assert [(row["title"], row["status"]) for row in tasks] == [("Resume analysis", "pending")]
        assert connection.execute(
            "SELECT COUNT(*) FROM activity WHERE message LIKE 'Recovered 1 unfinished task%'"
        ).fetchone()[0] == 1


def test_old_approved_phase_one_idea_is_migrated_without_overwriting_data(tmp_path):
    path = tmp_path / "legacy.sqlite3"
    database = Database(path)
    database.initialize()
    with database.connect() as connection:
        connection.execute(
            "INSERT INTO business_ideas (title, description, status, created_at) VALUES (?, ?, 'approved', ?)",
            ("Existing approved idea", "Keep this user record.", "2026-01-01T00:00:00+00:00"),
        )
    database.initialize()

    with database.connect() as connection:
        assert connection.execute("SELECT COUNT(*) FROM business_ideas").fetchone()[0] == 1
        business = connection.execute(
            """
            SELECT b.stage, i.title FROM businesses b JOIN business_ideas i ON i.id = b.idea_id
            """
        ).fetchone()
        assert tuple(business) == ("research", "Existing approved idea")
        assert connection.execute(
            "SELECT COUNT(*) FROM tasks WHERE dedupe_key = 'business:1:stage:research'"
        ).fetchone()[0] == 1


def test_autonomous_worker_persists_result_and_queues_next_business_stage(tmp_path):
    database = Database(tmp_path / "worker.sqlite3")
    database.initialize()
    with database.connect() as connection:
        idea_id = connection.execute(
            "INSERT INTO business_ideas (title, description, created_at) VALUES (?, ?, ?)",
            ("Worker test business", "Internal test only.", "2026-01-01T00:00:00+00:00"),
        ).lastrowid
        approve_idea(connection, idea_id)
    ollama = FakeOllama()

    completed = process_next_autonomous_task(database, ollama, threading.BoundedSemaphore(1))

    assert completed is not None
    assert ollama.calls == 1
    with database.connect() as connection:
        task = connection.execute("SELECT status, result FROM tasks").fetchone()
        assert task["status"] == "completed"
        assert task["result"] == "Internal finding for the receiving department."
    # Completing the research task automatically queues the next internal stage.
    next_task = process_next_autonomous_task(database, ollama, threading.BoundedSemaphore(1))
    assert next_task is not None
    assert next_task["employee_id"] == "builder"
    assert ollama.calls == 2


def test_manager_dormants_unprofitable_business_and_preserves_revival_work(tmp_path, monkeypatch):
    client, path = build_client(tmp_path, monkeypatch)
    business_id = approve_business(client)
    advance_to_live(client, business_id)
    pending = client.post(
        "/api/finance/pending-payments",
        headers=OWNER_HEADERS,
        json={
            "business_id": business_id,
            "amount_cents": 1000,
            "external_reference": "verified-sale-1",
        },
    ).json()
    settlement = client.post(
        f"/api/finance/pending-payments/{pending['id']}/settle",
        headers=OWNER_HEADERS,
        json={"amount_cents": 1000, "evidence_ref": "bank-row-1"},
    )
    assert settlement.status_code == 201
    assert client.put(
        "/api/finance/spending-limit",
        headers=OWNER_HEADERS,
        json={"amount_cents": 5000},
    ).status_code == 200
    expense = client.post(
        "/api/finance/adjustments",
        headers=OWNER_HEADERS,
        json={
            "business_id": business_id,
            "transaction_type": "processing_fee",
            "amount_cents": 1500,
            "external_reference": "expense-1",
            "evidence_ref": "receipt-1",
        },
    )
    assert expense.status_code == 201

    run_management_cycle(Database(path))

    history = client.get(f"/api/businesses/{business_id}").json()
    assert history["business"]["stage"] == "temporarily_dormant"
    assert history["financials"]["available_business_funds_cents"] == -500
    assert history["revival_missions"][0]["phase"] == "investigating"
    assert any(task["mission_type"] == "investigating" for task in history["tasks"])
    researcher = client.get("/api/employees/researcher/profile").json()
    assert researcher["successful_projects"][0]["business_id"] == business_id


def test_employees_can_share_findings_using_only_the_local_model(tmp_path, monkeypatch):
    client, _ = build_client(tmp_path, monkeypatch)
    shared = client.post(
        "/api/employees/researcher/share",
        json={
            "recipient_employee_id": "strategist",
            "request": "Summarize onboarding feedback for strategy.",
            "model": "test-model",
        },
    )
    assert shared.status_code == 201
    assert shared.json()["content"] == "Internal finding for the receiving department."
    profile = client.get("/api/employees/strategist/profile").json()
    assert profile["team_communications"][0]["sender_name"] == "Sherlock Beans"
    assert profile["team_communications"][0]["recipient_name"] == "Captain Spreadsheet"


def test_autonomous_revival_runs_research_development_simulation_and_stops_at_recommendation(tmp_path):
    database = Database(tmp_path / "revival-worker.sqlite3")
    database.initialize()
    with database.connect() as connection:
        idea_id = connection.execute(
            "INSERT INTO business_ideas (title, description, created_at) VALUES (?, ?, ?)",
            ("Revival worker business", "Preserve the project.", "2026-01-01T00:00:00+00:00"),
        ).lastrowid
        business = approve_idea(connection, idea_id)
        business_id = business["id"]
        for stage in ("development", "simulation", "ready_for_approval", "live_business"):
            transition_business(connection, business_id, stage)
        connection.execute("UPDATE tasks SET status = 'completed' WHERE business_id = ?", (business_id,))
        connection.execute(
            """
            INSERT INTO business_metrics
                (business_id, estimated_revenue_cents, retention_pct, satisfaction_pct,
                 growth_pct, customer_feedback, competitor_analysis, created_at)
            VALUES (?, 5000, 20, 30, -20, 'Falling retention', 'Simpler competitor offer', ?)
            """,
            (business_id, "2026-01-02T00:00:00+00:00"),
        )
    run_management_cycle(database)
    ollama = FakeOllama()
    for _ in range(8):
        process_next_autonomous_task(database, ollama, threading.BoundedSemaphore(1))
        with database.connect() as connection:
            phase = connection.execute(
                "SELECT phase FROM revival_missions WHERE business_id = ? ORDER BY id DESC LIMIT 1",
                (business_id,),
            ).fetchone()["phase"]
        if phase == "experiment_recommended":
            break

    assert phase == "experiment_recommended"
    assert ollama.calls == 4
    with database.connect() as connection:
        assert connection.execute(
            "SELECT stage FROM businesses WHERE id = ?", (business_id,)
        ).fetchone()["stage"] == "revival"
        assert connection.execute("SELECT COUNT(*) FROM transactions").fetchone()[0] == 0
        assert connection.execute(
            """
            SELECT COUNT(*) FROM tasks
            WHERE status = 'completed' AND dedupe_key LIKE 'revival:%'
            """
        ).fetchone()[0] == 4


def test_background_scheduler_writes_persistent_portfolio_reports(tmp_path, monkeypatch):
    monkeypatch.setenv("AI_MONEY_TOWN_OWNER_TOKEN", "phase2-test-owner")
    monkeypatch.setenv("AI_MONEY_TOWN_SCHEDULER_START_DELAY_SECONDS", "0")
    path = tmp_path / "scheduled.sqlite3"
    application = create_app(path, FakeOllama(), scheduler_enabled=True)

    with TestClient(application) as client:
        for _ in range(40):
            reports = client.get("/api/management/reports").json()
            if reports:
                break
            time.sleep(0.05)
        assert reports
        assert reports[0]["report_type"] == "portfolio_review"
        assert "memory_available_bytes" in reports[0]["content"]["resources"]

    restarted = TestClient(create_app(path, FakeOllama(), scheduler_enabled=False))
    assert restarted.get("/api/management/reports").json()[0]["content"]["model_calls_in_cycle"] == 0


def test_owner_actions_stay_disabled_when_no_server_token_is_configured(tmp_path, monkeypatch):
    client, _ = build_client(tmp_path, monkeypatch, owner_token=False)
    assert client.get("/api/owner/status").status_code == 503
    assert client.put("/api/finance/spending-limit", json={"amount_cents": 1000}).status_code == 503


class IdeaBatchOllama:
    def __init__(self):
        self.calls = 0

    def status(self):
        return {"connected": True, "models": ["qwen3.5:0.8b"], "error": None}

    def chat(self, model, messages, options=None):
        self.calls += 1
        prompt = messages[-1]["content"]
        if "Generate exactly 10" in prompt:
            import json
            return json.dumps([
                {
                    "title": f"Useful Local Product {index}",
                    "description": f"A simple product concept number {index}.",
                    "category": "Digital product",
                    "problem": "People need a clearer way to organise small tasks.",
                    "target_customers": "Students and small teams",
                    "mvp": "A small checklist prototype",
                }
                for index in range(1, 11)
            ])
        return "Research summary: identify a narrow audience, test the core problem, and keep all estimates labelled."


def test_hourly_idea_generation_creates_ideas_and_research_tasks(tmp_path, monkeypatch):
    from datetime import datetime, timedelta, timezone
    from backend.app.scheduler import maybe_generate_ideas

    monkeypatch.setenv("AI_MONEY_TOWN_IDEA_INTERVAL_SECONDS", "3600")
    database = Database(tmp_path / "idea-town.sqlite3")
    database.initialize()
    ollama = IdeaBatchOllama()
    lock = threading.BoundedSemaphore(1)
    now = datetime(2026, 11, 21, 8, 0, tzinfo=timezone.utc)

    report = maybe_generate_ideas(database, ollama, lock, now=now)
    assert report is not None
    assert report["ideas_created"] == 10
    assert report["target_reached"] is True
    assert report["target_ideas_per_hour"] == 50
    assert report["batch_target"] == 10
    assert report["batch_interval_seconds"] == 3600  # Explicit test override is respected.
    with database.connect() as connection:
        assert connection.execute("SELECT COUNT(*) FROM business_ideas").fetchone()[0] == 10
        assert connection.execute("SELECT COUNT(*) FROM tasks WHERE mission_type = 'idea_research'").fetchone()[0] == 10
        assert connection.execute("SELECT COUNT(*) FROM tasks WHERE idea_id IS NOT NULL").fetchone()[0] == 10

    assert maybe_generate_ideas(database, ollama, lock, now=now + timedelta(minutes=30)) is None
    assert ollama.calls == 1


def test_idea_generator_default_targets_fifty_candidates_per_hour(tmp_path, monkeypatch):
    from datetime import datetime, timezone
    from backend.app.scheduler import maybe_generate_ideas

    monkeypatch.delenv("AI_MONEY_TOWN_IDEA_INTERVAL_SECONDS", raising=False)
    monkeypatch.setenv("AI_MONEY_TOWN_IDEA_TARGET_PER_HOUR", "50")
    monkeypatch.setenv("AI_MONEY_TOWN_IDEA_BATCH_SIZE", "10")
    database = Database(tmp_path / "fifty-ideas.sqlite3")
    database.initialize()
    report = maybe_generate_ideas(
        database,
        IdeaBatchOllama(),
        threading.BoundedSemaphore(1),
        now=datetime(2026, 11, 22, 8, 0, tzinfo=timezone.utc),
    )

    assert report is not None
    assert report["ideas_created"] == 10
    assert report["target_ideas_per_hour"] == 50
    assert report["batch_target"] == 10
    assert report["batch_interval_seconds"] == 720
    assert report["hourly_target_is_aspirational"] is True


def test_idea_research_and_strategy_start_internal_incubation(tmp_path):
    from backend.app.scheduler import maybe_generate_ideas
    from datetime import datetime, timezone

    database = Database(tmp_path / "idea-pipeline.sqlite3")
    database.initialize()
    ollama = IdeaBatchOllama()
    lock = threading.BoundedSemaphore(1)
    report = maybe_generate_ideas(database, ollama, lock, now=datetime(2026, 11, 21, 8, 0, tzinfo=timezone.utc))
    assert report and report["ideas_created"] == 10

    first = process_next_autonomous_task(database, ollama, lock)
    assert first is not None
    with database.connect() as connection:
        assert connection.execute("SELECT COUNT(*) FROM tasks WHERE mission_type = 'idea_strategy'").fetchone()[0] == 1
        strategy = connection.execute("SELECT * FROM tasks WHERE mission_type = 'idea_strategy'").fetchone()
        strategy_id = strategy["id"]
        idea_id = strategy["idea_id"]

    for _ in range(20):
        with database.connect() as connection:
            strategy_status = connection.execute("SELECT status FROM tasks WHERE id = ?", (strategy_id,)).fetchone()["status"]
        if strategy_status == "completed":
            break
        processed = process_next_autonomous_task(database, ollama, lock)
        assert processed is not None
    with database.connect() as connection:
        task = connection.execute("SELECT status FROM tasks WHERE id = ?", (strategy_id,)).fetchone()
        idea = connection.execute("SELECT status FROM business_ideas WHERE id = ?", (idea_id,)).fetchone()
        assert task["status"] == "completed"
        assert idea["status"] == "evaluating"
        assert connection.execute("SELECT COUNT(*) FROM businesses WHERE idea_id = ?", (idea_id,)).fetchone()[0] == 1
        assert connection.execute("SELECT COUNT(*) FROM management_reports WHERE report_type = 'idea_review'").fetchone()[0] == 1


def test_initial_employee_tasks_are_seeded_once_and_visible(tmp_path):
    from backend.app.scheduler import seed_initial_team_tasks

    database = Database(tmp_path / "starter-tasks.sqlite3")
    database.initialize()
    assert seed_initial_team_tasks(database) == 8
    assert seed_initial_team_tasks(database) == 0
    with database.connect() as connection:
        rows = connection.execute(
            "SELECT employee_id, status FROM tasks WHERE dedupe_key LIKE 'town-onboarding:%' ORDER BY employee_id"
        ).fetchall()
    assert len(rows) == 8
    assert {row["employee_id"] for row in rows} == {
        "town-manager", "researcher", "strategist", "builder",
        "marketer", "finance-analyst", "operations", "community-manager",
    }
    assert all(row["status"] == "pending" for row in rows)


def test_scheduler_creates_visible_first_shift_work_on_startup(tmp_path, monkeypatch):
    monkeypatch.setenv("AI_MONEY_TOWN_SCHEDULER_START_DELAY_SECONDS", "0")
    monkeypatch.setenv("AI_MONEY_TOWN_SCHEDULER_SECONDS", "20")
    monkeypatch.setenv("AI_MONEY_TOWN_INITIAL_IDEA_DELAY_SECONDS", "1800")
    app = create_app(tmp_path / "scheduler-start.sqlite3", FakeOllama(), scheduler_enabled=True)
    with TestClient(app) as client:
        deadline = time.time() + 3
        state = client.get("/api/city/state").json()
        while sum(state["tasks"].values()) < 8 and time.time() < deadline:
            time.sleep(0.05)
            state = client.get("/api/city/state").json()
        assert sum(state["tasks"].values()) == 8
        assert all(employee["current_task"] for employee in state["employees"])


def test_idea_moves_through_internal_research_mvp_simulation_and_owner_review(tmp_path):
    """The workers autonomously prepare an internal venture, but stop before public launch."""
    database = Database(tmp_path / "autonomous-business-pipeline.sqlite3")
    database.initialize()
    with database.connect() as connection:
        idea_id = connection.execute(
            "INSERT INTO business_ideas (title, description, status, created_at) VALUES (?, ?, 'evaluating', ?)",
            (
                "Homework planner for busy families",
                "A simple planner that turns school assignments into short daily checklists for families.",
                "2026-11-22T00:00:00+00:00",
            ),
        ).lastrowid
        connection.execute(
            """INSERT INTO tasks
               (title, description, employee_id, status, created_at, updated_at,
                task_kind, mission_type, dedupe_key, idea_id)
               VALUES (?, ?, 'researcher', 'pending', ?, ?, 'autonomous', 'idea_research', ?, ?)""",
            (
                "Research idea: Homework planner",
                "Identify problem, audience, alternatives and risks.",
                "2026-11-22T00:00:00+00:00",
                "2026-11-22T00:00:00+00:00",
                "idea:test:research",
                idea_id,
            ),
        )

    ollama = FakeOllama()
    lock = threading.BoundedSemaphore(1)
    for _ in range(6):
        result = process_next_autonomous_task(database, ollama, lock)
        assert result is not None

    with database.connect() as connection:
        business = connection.execute(
            "SELECT * FROM businesses WHERE idea_id = ?", (idea_id,)
        ).fetchone()
        assert business is not None
        assert business["stage"] == "ready_for_approval"
        idea = connection.execute("SELECT status FROM business_ideas WHERE id = ?", (idea_id,)).fetchone()
        assert idea["status"] == "proposed"
        artifact_types = {
            row[0] for row in connection.execute(
                "SELECT artifact_type FROM business_artifacts WHERE business_id = ?", (business["id"],)
            )
        }
        assert artifact_types >= {
            "strategy_brief", "research_brief", "mvp_blueprint",
            "simulation_analysis", "simulation_report", "launch_checklist",
        }
        metrics = connection.execute(
            "SELECT * FROM business_metrics WHERE business_id = ? ORDER BY id DESC LIMIT 1",
            (business["id"],),
        ).fetchone()
        assert metrics is not None
        assert 0 <= metrics["retention_pct"] <= 100
        assert 0 <= metrics["satisfaction_pct"] <= 100
        assert "SYNTHETIC SIMULATION ONLY" in metrics["customer_feedback"]
        assert connection.execute(
            "SELECT COUNT(*) FROM transactions WHERE business_id = ?", (business["id"],)
        ).fetchone()[0] == 0

    client = TestClient(create_app(database.path, FakeOllama(), scheduler_enabled=False))
    history = client.get(f"/api/businesses/{business["id"]}")
    assert history.status_code == 200
    assert len(history.json()["artifacts"]) >= 6
    automation = client.get("/api/automation/status").json()
    assert automation["businesses_waiting_for_owner_review"] == 1
    assert automation["public_launch_and_customer_outreach_require_owner_approval"] is True


def test_synthetic_customer_simulation_is_repeatable_and_never_records_sales():
    from backend.app.market_simulation import run_synthetic_customer_simulation

    first = run_synthetic_customer_simulation("Useful family planner", "Organizes school work into daily tasks.", 1000)
    second = run_synthetic_customer_simulation("Useful family planner", "Organizes school work into daily tasks.", 1000)
    assert first == second
    assert first["synthetic_profiles"] == 1000
    assert "not actual customers" in first["scenario"].lower()
    assert "SYNTHETIC SIMULATION ONLY" in first["customer_feedback"]
    assert first["estimated_revenue_cents"] >= 0


def test_employee_status_tracks_autonomous_task_execution(tmp_path):
    import threading as thread_module

    database = Database(tmp_path / "employee-live-status.sqlite3")
    database.initialize()
    with database.connect() as connection:
        connection.execute(
            """INSERT INTO tasks
               (title, description, employee_id, status, created_at, updated_at, task_kind, mission_type)
               VALUES ('Live status test', 'Keep this short.', 'researcher', 'pending', ?, ?, 'autonomous', 'town_onboarding')""",
            ("2026-11-22T00:00:00+00:00", "2026-11-22T00:00:00+00:00"),
        )

    started = thread_module.Event()
    release = thread_module.Event()

    class BlockingOllama(FakeOllama):
        def chat(self, model, messages, options=None):
            started.set()
            assert release.wait(timeout=5)
            return super().chat(model, messages, options)

    worker = thread_module.Thread(
        target=process_next_autonomous_task,
        args=(database, BlockingOllama(), thread_module.BoundedSemaphore(1)),
        daemon=True,
    )
    worker.start()
    assert started.wait(timeout=5)
    with database.connect() as connection:
        status = connection.execute("SELECT status FROM employees WHERE id = 'researcher'").fetchone()[0]
        assert status == "working"
    release.set()
    worker.join(timeout=5)
    assert not worker.is_alive()
    with database.connect() as connection:
        status = connection.execute("SELECT status FROM employees WHERE id = 'researcher'").fetchone()[0]
        assert status == "available"
