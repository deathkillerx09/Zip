"""Worker queue, retries, failures and stuck-task recovery."""

import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from backend.app.database import Database
from backend.app.main import create_app
from backend.app.ollama import OllamaError
from backend.app.scheduler import (
    process_next_autonomous_task,
    process_task_queue,
    queue_status,
    recover_stale_tasks,
)

OWNER = {"X-Owner-Token": "worker-test-owner"}


class FakeOllama:
    def __init__(self, reply="A concrete internal finding with next steps for the team."):
        self.reply = reply
        self.calls = 0

    def status(self):
        return {"connected": True, "models": ["test-model"], "error": None}

    def chat(self, model, messages, options=None):
        self.calls += 1
        return self.reply


class OfflineOllama:
    def status(self):
        return {"connected": False, "models": [], "error": "Cannot reach local Ollama."}

    def chat(self, model, messages, options=None):  # pragma: no cover - must not be called
        raise AssertionError("The worker must not call a model that is offline.")


class FailingOllama(FakeOllama):
    def __init__(self, error):
        super().__init__()
        self.error = error

    def chat(self, model, messages, options=None):
        self.calls += 1
        raise self.error


@pytest.fixture()
def database(tmp_path: Path) -> Database:
    db = Database(tmp_path / "worker.sqlite3")
    db.initialize()
    return db


def add_task(database, *, employee="researcher", title="Owner assigned research", kind="owner", mission=None, **extra):
    now = datetime.now(timezone.utc).isoformat()
    columns = {
        "title": title,
        "description": "Check the problem and report findings.",
        "employee_id": employee,
        "status": "pending",
        "created_at": now,
        "updated_at": now,
        "task_kind": kind,
        "mission_type": mission,
    }
    columns.update(extra)
    names = ", ".join(columns)
    marks = ", ".join("?" for _ in columns)
    with database.connect() as connection:
        task_id = connection.execute(
            f"INSERT INTO tasks ({names}) VALUES ({marks})", tuple(columns.values())
        ).lastrowid
    return task_id


def task_row(database, task_id):
    with database.connect() as connection:
        return dict(connection.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone())


def test_owner_assigned_task_is_executed_not_left_pending(database):
    """A task typed by the owner on the Task Board used to sit pending forever."""
    task_id = add_task(database, employee="strategist", title="Own task")
    ollama = FakeOllama()

    outcome = process_next_autonomous_task(database, ollama, threading.BoundedSemaphore(1))

    assert outcome is not None
    assert outcome["status"] == "completed"
    assert ollama.calls == 1
    row = task_row(database, task_id)
    assert row["status"] == "completed"
    assert row["result"].startswith("A concrete internal finding")
    assert row["attempts"] == 1
    assert row["started_at"] and row["completed_at"]


def test_retryable_error_requeues_with_backoff_and_counts_attempt(database):
    task_id = add_task(database)
    ollama = FailingOllama(OllamaError("Model is loading.", kind="offline", retryable=True))

    outcome = process_next_autonomous_task(database, ollama, threading.BoundedSemaphore(1))

    assert outcome["status"] == "retry_scheduled"
    row = task_row(database, task_id)
    assert row["status"] == "pending"
    assert row["attempts"] == 1
    assert row["next_attempt_at"] is not None
    assert "Model is loading" in row["last_error"]
    with database.connect() as connection:
        events = [r["event_type"] for r in connection.execute("SELECT event_type FROM task_events WHERE task_id = ?", (task_id,))]
    assert "retry_scheduled" in events

    # The retry window has not opened yet, so nothing may run.
    assert process_next_autonomous_task(database, FakeOllama(), threading.BoundedSemaphore(1)) is None

    # Force the window open and let the real model succeed.
    with database.connect() as connection:
        connection.execute("UPDATE tasks SET next_attempt_at = NULL WHERE id = ?", (task_id,))
    outcome = process_next_autonomous_task(database, FakeOllama(), threading.BoundedSemaphore(1))
    assert outcome["status"] == "completed"
    assert task_row(database, task_id)["attempts"] == 2


def test_permanent_error_marks_task_failed_never_completed(database):
    task_id = add_task(database)
    ollama = FailingOllama(OllamaError("Model not found.", kind="model_error", retryable=False))

    outcome = process_next_autonomous_task(database, ollama, threading.BoundedSemaphore(1))

    assert outcome["status"] == "failed"
    row = task_row(database, task_id)
    assert row["status"] == "failed"
    assert "Model not found" in row["last_error"]
    assert row["completed_at"] is None
    with database.connect() as connection:
        status = connection.execute(
            "SELECT status FROM employees WHERE id = 'researcher'"
        ).fetchone()[0]
        activity = [r[0] for r in connection.execute("SELECT message FROM activity")]
    assert status == "available"
    assert any("Task failed" in line for line in activity)


def test_repeated_failures_stop_at_the_attempt_limit(database, monkeypatch):
    monkeypatch.setenv("AI_MONEY_TOWN_TASK_MAX_ATTEMPTS", "2")
    task_id = add_task(database)
    lock = threading.BoundedSemaphore(1)
    for attempt in range(2):
        with database.connect() as connection:
            connection.execute("UPDATE tasks SET next_attempt_at = NULL WHERE id = ?", (task_id,))
        process_next_autonomous_task(
            database,
            FailingOllama(OllamaError("Ollama timed out.", kind="timeout")),
            lock,
        )
    row = task_row(database, task_id)
    assert row["status"] == "failed"
    assert row["attempts"] == 2


def test_short_model_output_is_treated_as_a_failure(database):
    task_id = add_task(database, mission="research")
    outcome = process_next_autonomous_task(database, FakeOllama("ok"), threading.BoundedSemaphore(1))
    assert outcome["status"] == "retry_scheduled"
    row = task_row(database, task_id)
    assert row["status"] == "pending"
    assert "not a usable result" in row["last_error"]


def test_worker_does_nothing_when_ollama_is_offline(database):
    add_task(database)
    assert process_next_autonomous_task(database, OfflineOllama(), threading.BoundedSemaphore(1)) is None
    report = queue_status(database, OfflineOllama())
    assert report["pending"] == 1
    assert "Cannot reach local Ollama" in report["blocked_reason"]


def test_stuck_in_progress_task_is_recovered(database):
    task_id = add_task(database)
    stale = (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat()
    with database.connect() as connection:
        connection.execute(
            """UPDATE tasks SET status = 'in_progress', attempts = 1, started_at = ?,
               last_attempt_at = ? WHERE id = ?""",
            (stale, stale, task_id),
        )
        connection.execute("UPDATE employees SET status = 'working' WHERE id = 'researcher'")

    recovered = recover_stale_tasks(database, stale_seconds=60)

    assert recovered == 1
    row = task_row(database, task_id)
    assert row["status"] == "pending"
    with database.connect() as connection:
        assert connection.execute(
            "SELECT status FROM employees WHERE id = 'researcher'"
        ).fetchone()[0] == "available"


def test_stuck_task_beyond_attempt_limit_becomes_failed(database, monkeypatch):
    monkeypatch.setenv("AI_MONEY_TOWN_TASK_MAX_ATTEMPTS", "1")
    task_id = add_task(database)
    stale = (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat()
    with database.connect() as connection:
        connection.execute(
            """UPDATE tasks SET status = 'in_progress', attempts = 1, started_at = ?,
               last_attempt_at = ? WHERE id = ?""",
            (stale, stale, task_id),
        )
    recover_stale_tasks(database, stale_seconds=60)
    assert task_row(database, task_id)["status"] == "failed"


def test_process_queue_runs_several_tasks_in_priority_order(database):
    low = add_task(database, employee="researcher", title="Low priority", priority=0)
    high = add_task(database, employee="strategist", title="High priority", priority=50)
    outcomes = process_task_queue(database, FakeOllama(), threading.BoundedSemaphore(1), limit=2)
    assert [item["task_id"] for item in outcomes] == [high, low]
    assert all(item["status"] == "completed" for item in outcomes)


class ApiOllama(FakeOllama):
    pass


def build_client(tmp_path: Path, monkeypatch, *, reply="A concrete internal finding with next steps."):
    monkeypatch.setenv("AI_MONEY_TOWN_OWNER_TOKEN", "worker-test-owner")
    monkeypatch.setenv("AI_MONEY_TOWN_RATE_LIMIT_PER_MINUTE", "500")
    application = create_app(tmp_path / "api.sqlite3", ApiOllama(reply), scheduler_enabled=False)
    return TestClient(application)


def test_failed_task_cannot_be_marked_completed(tmp_path, monkeypatch):
    client = build_client(tmp_path, monkeypatch)
    task = client.post("/api/tasks", json={"title": "Will fail", "employee_id": "researcher"}).json()
    with client.app.state.database.connect() as connection:
        connection.execute("UPDATE tasks SET status = 'failed', last_error = 'Model missing.' WHERE id = ?", (task["id"],))
    response = client.patch(f"/api/tasks/{task['id']}", json={"status": "completed"})
    assert response.status_code == 409
    assert "cannot be marked completed" in response.json()["detail"]


def test_owner_retry_and_run_endpoints(tmp_path, monkeypatch):
    client = build_client(tmp_path, monkeypatch)
    task = client.post("/api/tasks", json={"title": "Retry me", "employee_id": "researcher"}).json()
    with client.app.state.database.connect() as connection:
        connection.execute("UPDATE tasks SET status = 'failed', attempts = 3, last_error = 'boom' WHERE id = ?", (task["id"],))

    unauthorised = client.post(f"/api/tasks/{task['id']}/retry")
    assert unauthorised.status_code == 401 or unauthorised.status_code == 503

    retried = client.post(f"/api/tasks/{task['id']}/retry", headers=OWNER)
    assert retried.status_code == 202
    assert retried.json()["status"] == "pending"
    assert retried.json()["attempts"] == 0

    ran = client.post(f"/api/tasks/{task['id']}/run", headers=OWNER)
    assert ran.status_code == 200
    assert ran.json()["status"] == "completed"
    dashboard = client.get("/api/dashboard").json()
    assert dashboard["town"]["completed_task_count"] == 1

    events = client.get(f"/api/tasks/{task['id']}/events").json()
    assert {event["event_type"] for event in events} >= {"retry_scheduled", "claimed", "completed"}


def test_missing_model_does_not_consume_an_attempt(database, monkeypatch):
    """After installing a model the queued work must run, not be half-failed."""
    class NoModelOllama:
        def status(self):
            return {"connected": True, "models": ["nomic-embed-text:latest"], "error": None}

        def chat(self, model, messages, options=None):  # pragma: no cover
            raise AssertionError("No chat model is available.")

    task_id = add_task(database)
    outcome = process_next_autonomous_task(database, NoModelOllama(), threading.BoundedSemaphore(1))
    assert outcome["status"] == "waiting_for_model"
    row = task_row(database, task_id)
    assert row["status"] == "pending"
    assert row["attempts"] == 0
    assert "ollama pull" in row["last_error"]
