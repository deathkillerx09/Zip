"""Real product deliverables: generation, validation, storage and delivery."""

import json
import threading
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from backend.app import deliverables
from backend.app.database import Database
from backend.app.deliverables import extract_html, validate_html
from backend.app.empire import approve_idea
from backend.app.main import create_app
from backend.app.scheduler import process_next_autonomous_task

OWNER = {"X-Owner-Token": "deliverable-test-owner"}

GOOD_HTML = """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chore Splitter</title>
  <style>
    body { font-family: system-ui, sans-serif; margin: 2rem; background: #f7f7f4; color: #223; }
    main { max-width: 520px; margin: 0 auto; background: #fff; padding: 1.5rem; border-radius: 12px; }
    li { margin: .4rem 0; }
    button { padding: .5rem .9rem; border-radius: 8px; border: 1px solid #345; background: #eef; cursor: pointer; }
  </style>
</head>
<body>
  <main>
    <h1>Chore Splitter</h1>
    <p>Add one household chore per line. The page stores the list on this device only.</p>
    <form id="form">
      <input id="chore" placeholder="Wash the dishes" aria-label="Chore">
      <button type="submit">Add chore</button>
    </form>
    <ul id="list"></ul>
    <button id="clear" type="button">Clear list</button>
    <p id="count">0 chores</p>
  </main>
  <script>
    const form = document.getElementById("form");
    const input = document.getElementById("chore");
    const list = document.getElementById("list");
    const count = document.getElementById("count");
    let chores = [];
    try { chores = JSON.parse(localStorage.getItem("chores") || "[]"); } catch (error) { chores = []; }
    function render() {
      list.innerHTML = "";
      chores.forEach(function (item) {
        const li = document.createElement("li");
        li.textContent = item;
        list.appendChild(li);
      });
      count.textContent = chores.length + (chores.length === 1 ? " chore" : " chores");
      localStorage.setItem("chores", JSON.stringify(chores));
    }
    form.addEventListener("submit", function (event) {
      event.preventDefault();
      const value = input.value.trim();
      if (!value) { return; }
      chores.push(value);
      input.value = "";
      render();
    });
    document.getElementById("clear").addEventListener("click", function () {
      chores = [];
      render();
    });
    render();
  </script>
</body>
</html>
"""

BAD_HTML = """<!doctype html><html><head><title>Thing</title></head>
<body><h1>Thing</h1><p>{{ product_description }}</p>
<script src="https://cdn.example.com/lib.js"></script></body></html>"""


class HtmlOllama:
    def __init__(self, reply):
        self.reply = reply
        self.calls = 0

    def status(self):
        return {"connected": True, "models": ["test-model"], "error": None}

    def chat(self, model, messages, options=None):
        self.calls += 1
        return self.reply


@pytest.fixture()
def database(tmp_path: Path) -> Database:
    db = Database(tmp_path / "products.sqlite3")
    db.initialize()
    return db


def create_business(database, title="Chore Splitter", description="Turns chores into fair weekly lists."):
    with database.connect() as connection:
        idea_id = connection.execute(
            "INSERT INTO business_ideas (title, description, status, created_at) VALUES (?, ?, 'approved', ?)",
            (title, description, "2026-01-01T00:00:00+00:00"),
        ).lastrowid
        return approve_idea(connection, idea_id)["id"]


def move_to_development(database, business_id):
    with database.connect() as connection:
        connection.execute("UPDATE businesses SET stage = 'development' WHERE id = ?", (business_id,))
        # Approving an idea queues a research task; complete it so the product
        # development task is the work under test.
        connection.execute(
            "UPDATE tasks SET status = 'completed', completed_at = updated_at WHERE business_id = ? AND status = 'pending'",
            (business_id,),
        )
        now = "2026-01-02T00:00:00+00:00"
        task_id = connection.execute(
            """INSERT INTO tasks
               (title, description, employee_id, status, created_at, updated_at,
                business_id, task_kind, mission_type, dedupe_key)
               VALUES (?, ?, 'builder', 'pending', ?, ?, ?, 'autonomous', 'development', ?)""",
            (
                "Product development: Chore Splitter",
                "Build the smallest working version.",
                now, now, business_id, f"business:{business_id}:stage:development",
            ),
        ).lastrowid
    return task_id


def test_extract_html_prefers_the_fenced_document():
    reply = "Here is the file:\n```html\n" + GOOD_HTML + "\n```\nIt stores chores locally."
    extracted = extract_html(reply)
    assert extracted is not None
    assert extracted.startswith("<!doctype html>")
    assert extracted.rstrip().endswith("</html>")


def test_validator_accepts_a_working_page():
    result = validate_html(GOOD_HTML, "web_app")
    assert result.ok, result.issues
    assert result.checks["title"] == "Chore Splitter"
    assert result.checks["script_blocks"] == 1
    # If Node.js is installed the inline script is syntax-checked for real.
    if result.checks["javascript"]["ran"]:
        assert result.checks["javascript"]["failures"] == []


def test_validator_rejects_remote_assets_placeholders_and_empty_apps():
    issues = validate_html(BAD_HTML, "web_app").issues
    joined = " ".join(issues)
    assert "remote script" in joined
    assert "{{" in joined
    assert "too small" in joined
    assert "no button or input" in joined


def test_development_task_records_a_real_deliverable(database, monkeypatch, tmp_path):
    monkeypatch.setenv("AI_MONEY_TOWN_WORKSPACE", str(tmp_path / "workspace"))
    business_id = create_business(database)
    task_id = move_to_development(database, business_id)
    reply = "Blueprint summary: a simple chore list.\n\n```html\n" + GOOD_HTML + "\n```"
    ollama = HtmlOllama(reply)

    outcome = process_next_autonomous_task(database, ollama, threading.BoundedSemaphore(1))

    assert outcome["status"] == "completed"
    assert outcome["product_files_built"] is True
    with database.connect() as connection:
        task = connection.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
        assert task["status"] == "completed"
        rows = connection.execute("SELECT * FROM deliverables WHERE business_id = ?", (business_id,)).fetchall()
        assert len(rows) == 1
        record = dict(rows[0])
        assert record["validation_status"] == "passed"
        assert record["entry_file"] == "index.html"
        folder = deliverables.workspace_root() / record["directory"]
        assert (folder / "index.html").is_file()
        assert (folder / "manifest.json").is_file()
        manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
        assert manifest["business_id"] == business_id
        events = [r[0] for r in connection.execute(
            "SELECT event_type FROM business_events WHERE business_id = ?", (business_id,)
        )]
        assert "product_files_built" in events


def test_prose_only_reply_never_claims_a_product_was_built(database, monkeypatch, tmp_path):
    monkeypatch.setenv("AI_MONEY_TOWN_WORKSPACE", str(tmp_path / "workspace"))
    business_id = create_business(database, "Prose Only", "No files here.")
    task_id = move_to_development(database, business_id)

    outcome = process_next_autonomous_task(
        database, HtmlOllama("A written blueprint with no code at all, describing the product."),
        threading.BoundedSemaphore(1),
    )

    assert outcome["status"] == "completed"
    assert outcome["product_files_built"] is False
    with database.connect() as connection:
        assert connection.execute(
            "SELECT COUNT(*) FROM deliverables WHERE business_id = ?", (business_id,)
        ).fetchone()[0] == 0
        assert connection.execute(
            "SELECT COUNT(*) FROM business_events WHERE business_id = ? AND event_type = 'product_files_built'",
            (business_id,),
        ).fetchone()[0] == 0
        rejections = [r[0] for r in connection.execute(
            "SELECT event_type FROM task_events WHERE task_id = ?", (task_id,)
        )]
    assert "deliverable_rejected" in rejections


def test_invalid_generated_page_is_repaired_once_then_accepted(database, monkeypatch, tmp_path):
    monkeypatch.setenv("AI_MONEY_TOWN_WORKSPACE", str(tmp_path / "workspace"))
    business_id = create_business(database, "Repair Case", "Needs one repair.")

    class RepairOllama(HtmlOllama):
        def chat(self, model, messages, options=None):
            self.calls += 1
            if self.calls == 1:
                return "```html\n" + BAD_HTML + "\n```"
            return "```html\n" + GOOD_HTML + "\n```"

    with database.connect() as connection:
        attempt = deliverables.generate_web_deliverable(
            connection, RepairOllama(""), business_id=business_id, task_id=None,
            employee_name="Gizmo McNoodle", model="test-model",
        )
    assert attempt["status"] == "built"
    assert attempt["deliverable"]["validation_status"] == "passed"


def test_build_endpoint_requires_owner_and_serves_the_file(database, monkeypatch, tmp_path):
    monkeypatch.setenv("AI_MONEY_TOWN_WORKSPACE", str(tmp_path / "workspace"))
    monkeypatch.setenv("AI_MONEY_TOWN_OWNER_TOKEN", "deliverable-test-owner")
    business_id = create_business(database)
    app = create_app(database.path, HtmlOllama("```html\n" + GOOD_HTML + "\n```"), scheduler_enabled=False)
    client = TestClient(app)

    anonymous = client.post(
        f"/api/businesses/{business_id}/products/build", json={"kind": "web_app"}
    )
    assert anonymous.status_code in {401, 503}

    built = client.post(
        f"/api/businesses/{business_id}/products/build", json={"kind": "web_app"}, headers=OWNER
    )
    assert built.status_code == 201, built.text
    deliverable_id = built.json()["deliverable"]["id"]

    listing = client.get("/api/deliverables").json()
    assert [item["id"] for item in listing] == [deliverable_id]
    detail = client.get(f"/api/deliverables/{deliverable_id}").json()
    assert detail["validation"]["ok"] is True
    assert any(item["name"] == "index.html" for item in detail["files"])

    preview = client.get(f"/api/deliverables/{deliverable_id}/preview")
    assert preview.status_code == 200
    assert "sandbox" in preview.headers["content-security-policy"]
    assert "Chore Splitter" in preview.text

    file_response = client.get(f"/api/deliverables/{deliverable_id}/file")
    assert file_response.status_code == 200
    assert "<!doctype html>" in file_response.text

    traversal = client.get(f"/api/deliverables/{deliverable_id}/file", params={"name": "../manifest.json"})
    assert traversal.status_code in {400, 404}

    history = client.get(f"/api/businesses/{business_id}").json()
    assert [item["id"] for item in history["deliverables"]] == [deliverable_id]


def test_build_endpoint_reports_a_rejected_page_without_recording_it(database, monkeypatch, tmp_path):
    monkeypatch.setenv("AI_MONEY_TOWN_WORKSPACE", str(tmp_path / "workspace"))
    monkeypatch.setenv("AI_MONEY_TOWN_OWNER_TOKEN", "deliverable-test-owner")
    business_id = create_business(database)
    app = create_app(database.path, HtmlOllama("I cannot build that."), scheduler_enabled=False)
    client = TestClient(app)

    response = client.post(
        f"/api/businesses/{business_id}/products/build", json={"kind": "web_app"}, headers=OWNER
    )
    assert response.status_code == 422
    detail = response.json()["detail"]
    assert "failed validation" in detail["message"] or "did not return" in detail["error"]
    assert client.get("/api/deliverables").json() == []
