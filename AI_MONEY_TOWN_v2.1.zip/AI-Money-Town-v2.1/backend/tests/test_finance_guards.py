"""Financial safeguards: duplicates, limits, and the separation of simulated money."""

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from backend.app.main import create_app

OWNER = {"X-Owner-Token": "finance-test-owner"}


class FakeOllama:
    def status(self):
        return {"connected": True, "models": ["test-model"], "error": None}

    def chat(self, model, messages, options=None):
        return "Internal finding for the receiving department."


@pytest.fixture()
def client(tmp_path: Path, monkeypatch) -> TestClient:
    monkeypatch.setenv("AI_MONEY_TOWN_OWNER_TOKEN", "finance-test-owner")
    monkeypatch.setenv("AI_MONEY_TOWN_RATE_LIMIT_PER_MINUTE", "500")
    return TestClient(create_app(tmp_path / "finance.sqlite3", FakeOllama(), scheduler_enabled=False))


def create_business(client: TestClient, title="Ledger test business") -> int:
    idea = client.post("/api/ideas", json={"title": title, "description": "Finance guard test."}).json()
    approved = client.patch(f"/api/ideas/{idea['id']}", headers=OWNER, json={"status": "approved"})
    assert approved.status_code == 200
    return approved.json()["business_id"]


def settle_one_receipt(client: TestClient, business_id: int) -> int:
    pending = client.post(
        "/api/finance/pending-payments",
        headers=OWNER,
        json={"business_id": business_id, "amount_cents": 5000, "external_reference": "inv-1"},
    )
    assert pending.status_code == 201
    settled = client.post(
        f"/api/finance/pending-payments/{pending.json()['id']}/settle",
        headers=OWNER,
        json={"amount_cents": 5000, "evidence_ref": "statement-1"},
    )
    assert settled.status_code == 201
    return settled.json()["id"]


def test_identical_settlement_is_refused(client):
    business_id = create_business(client)
    pending = client.post(
        "/api/finance/pending-payments",
        headers=OWNER,
        json={"business_id": business_id, "amount_cents": 2500, "external_reference": "inv-9"},
    ).json()
    first = client.post(
        f"/api/finance/pending-payments/{pending['id']}/settle",
        headers=OWNER,
        json={"amount_cents": 2500, "evidence_ref": "bank-line"},
    )
    assert first.status_code == 201
    again = client.post(
        f"/api/finance/pending-payments/{pending['id']}/settle",
        headers=OWNER,
        json={"amount_cents": 2500, "evidence_ref": "bank-line"},
    )
    assert again.status_code == 409


def test_duplicate_expense_reference_is_refused(client):
    business_id = create_business(client)
    settle_one_receipt(client, business_id)
    client.put("/api/finance/spending-limit", headers=OWNER, json={"amount_cents": 1000})
    body = {
        "business_id": business_id,
        "transaction_type": "expense",
        "amount_cents": 100,
        "external_reference": "receipt-77",
        "evidence_ref": "receipt-scan-77",
    }
    assert client.post("/api/finance/adjustments", headers=OWNER, json=body).status_code == 201
    duplicate = client.post("/api/finance/adjustments", headers=OWNER, json=body)
    assert duplicate.status_code == 409
    assert "already recorded" in duplicate.json()["detail"]


def test_duplicate_withdrawal_request_is_refused(client):
    business_id = create_business(client)
    settle_one_receipt(client, business_id)
    body = {"amount_cents": 1000, "external_reference": "payout-1"}
    assert client.post("/api/finance/withdrawal-requests", headers=OWNER, json=body).status_code == 202
    duplicate = client.post("/api/finance/withdrawal-requests", headers=OWNER, json=body)
    assert duplicate.status_code == 409


def test_spending_is_paused_by_default_and_simulated_revenue_is_not_spendable(client):
    business_id = create_business(client)
    metrics = client.post(
        f"/api/businesses/{business_id}/metrics",
        headers=OWNER,
        json={
            "estimated_revenue_cents": 900000,
            "retention_pct": 80,
            "satisfaction_pct": 80,
            "growth_pct": 10,
            "customer_feedback": "Synthetic only.",
            "competitor_analysis": "Not researched live.",
        },
    )
    assert metrics.status_code == 201

    summary = client.get("/api/finance/summary").json()
    assert summary["estimated_revenue_cents"] == 900000
    assert summary["actual_revenue_cents"] == 0
    assert summary["available_business_funds_cents"] == 0

    blocked = client.post(
        "/api/finance/adjustments",
        headers=OWNER,
        json={
            "business_id": business_id,
            "transaction_type": "expense",
            "amount_cents": 500,
            "external_reference": "hosting-1",
            "evidence_ref": "invoice-1",
        },
    )
    assert blocked.status_code == 409
    assert "spending" in blocked.json()["detail"].lower()


def test_expense_cannot_exceed_verified_funds_even_with_a_limit(client):
    business_id = create_business(client)
    settle_one_receipt(client, business_id)
    assert client.put(
        "/api/finance/spending-limit", headers=OWNER, json={"amount_cents": 100000}
    ).status_code == 200
    too_much = client.post(
        "/api/finance/adjustments",
        headers=OWNER,
        json={
            "business_id": business_id,
            "transaction_type": "expense",
            "amount_cents": 6000,
            "external_reference": "big-invoice",
            "evidence_ref": "invoice-scan",
        },
    )
    assert too_much.status_code == 409
    assert "Insufficient verified" in too_much.json()["detail"]


def test_summary_reports_today_spend_and_remaining_allowance(client):
    business_id = create_business(client)
    settle_one_receipt(client, business_id)
    client.put("/api/finance/spending-limit", headers=OWNER, json={"amount_cents": 2000})
    allowed = client.post(
        "/api/finance/adjustments",
        headers=OWNER,
        json={
            "business_id": business_id,
            "transaction_type": "expense",
            "amount_cents": 1500,
            "external_reference": "small-invoice",
            "evidence_ref": "invoice-scan",
        },
    )
    assert allowed.status_code == 201
    summary = client.get("/api/finance/summary").json()
    assert summary["spent_today_cents"] == 1500
    assert summary["spending_remaining_today_cents"] == 500


def test_refund_cannot_exceed_the_settled_receipt(client):
    business_id = create_business(client)
    settled_id = settle_one_receipt(client, business_id)
    refund = client.post(
        "/api/finance/adjustments",
        headers=OWNER,
        json={
            "business_id": business_id,
            "transaction_type": "refund",
            "amount_cents": 6000,
            "external_reference": str(settled_id),
            "evidence_ref": "refund-slip",
        },
    )
    assert refund.status_code == 409
    assert "Refund exceeds" in refund.json()["detail"]


def test_transactions_are_immutable(client):
    business_id = create_business(client)
    settle_one_receipt(client, business_id)
    with client.app.state.database.connect() as connection:  # type: ignore[attr-defined]
        with pytest.raises(Exception):
            connection.execute("UPDATE transactions SET amount_cents = 1")
