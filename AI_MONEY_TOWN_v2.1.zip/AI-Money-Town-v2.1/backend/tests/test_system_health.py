"""System health, request guards and read consistency."""

import os
import subprocess
import sys
from pathlib import Path

from fastapi.testclient import TestClient

from backend.app.main import create_app
from backend.app.scheduler import seed_initial_team_tasks


class FakeOllama:
    def status(self):
        return {"connected": True, "models": ["test-model"], "error": None}

    def chat(self, model, messages, options=None):
        return "Internal finding for the receiving department."


class OfflineOllama:
    def status(self):
        return {"connected": False, "models": [], "error": "Cannot reach local Ollama."}


def build(tmp_path: Path, monkeypatch, ollama=None, **env):
    monkeypatch.setenv("AI_MONEY_TOWN_OWNER_TOKEN", "system-test-owner")
    for key, value in env.items():
        monkeypatch.setenv(key, str(value))
    return create_app(tmp_path / "system.sqlite3", ollama or FakeOllama(), scheduler_enabled=False)


def test_health_reports_every_subsystem(tmp_path, monkeypatch):
    client = TestClient(build(tmp_path, monkeypatch))
    health = client.get("/api/system/health").json()

    assert health["database"]["ok"] is True
    assert health["scheduler"]["enabled"] is False
    assert health["scheduler"]["task_concurrency"] == 1
    assert health["ollama"]["connected"] is True
    assert health["worker"]["model_ready"] is True
    assert health["limits"]["max_attempts"] == 3
    assert health["simulation_only"] is True
    assert set(health["model_roles"]) >= {"chat", "product", "worker"}
    assert "workspace" in health and "writable" in health["workspace"]


def test_queue_explains_why_work_is_not_moving(tmp_path, monkeypatch):
    client = TestClient(build(tmp_path, monkeypatch, ollama=OfflineOllama()))
    queue = client.get("/api/system/queue").json()
    assert queue["model_ready"] is False
    assert "Cannot reach local Ollama" in queue["blocked_reason"]
    assert queue["worker_concurrency"] == 1


def test_read_endpoints_return_one_consistent_snapshot(tmp_path, monkeypatch):
    """The town must never show eight tasks while every employee looks unassigned."""
    app = build(tmp_path, monkeypatch)
    database = app.state.database
    seed_initial_team_tasks(database)
    client = TestClient(app)

    for _ in range(5):
        state = client.get("/api/city/state").json()
        tasks_total = sum(state["tasks"].values())
        assert tasks_total == 8
        assert all(employee["current_task"] for employee in state["employees"]), state["employees"][0]
        assert state["products"]["deliverable_count"] == 0
        assert state["failed_tasks"]["count"] == 0


def test_dashboard_reports_failed_tasks_and_product_counts(tmp_path, monkeypatch):
    client = TestClient(build(tmp_path, monkeypatch))
    task = client.post("/api/tasks", json={"title": "Will fail", "employee_id": "researcher"}).json()
    with client.app.state.database.connect() as connection:
        connection.execute(
            "UPDATE tasks SET status = 'failed', last_error = 'Model missing.' WHERE id = ?", (task["id"],)
        )
    dashboard = client.get("/api/dashboard").json()
    assert dashboard["town"]["failed_task_count"] == 1
    assert dashboard["deliverables"]["deliverable_count"] == 0
    assert dashboard["worker"]["model_ready"] is True


def test_write_rate_limit_returns_429(tmp_path, monkeypatch):
    client = TestClient(build(tmp_path, monkeypatch, AI_MONEY_TOWN_RATE_LIMIT_PER_MINUTE=5))
    statuses = [
        client.post("/api/ideas", json={"title": f"Idea {index}"}).status_code
        for index in range(7)
    ]
    assert statuses[:5] == [201] * 5
    assert statuses[5:] == [429, 429]
    response = client.post("/api/ideas", json={"title": "Too many"})
    assert response.headers["retry-after"] == "30"


def test_oversized_request_body_is_rejected(tmp_path, monkeypatch):
    client = TestClient(build(tmp_path, monkeypatch, AI_MONEY_TOWN_MAX_BODY_BYTES=500))
    response = client.post("/api/ideas", json={"title": "x" * 2000, "description": "y" * 2000})
    assert response.status_code == 413


def test_unknown_routes_return_json_errors_not_tracebacks(tmp_path, monkeypatch):
    client = TestClient(build(tmp_path, monkeypatch))
    assert client.get("/api/businesses/9999").status_code == 404
    assert client.get("/api/deliverables/9999").status_code == 404
    assert client.post("/api/tasks/9999/retry", headers={"X-Owner-Token": "system-test-owner"}).status_code == 404
    assert client.get("/api/tasks/9999/events").status_code == 404


def test_owner_only_endpoints_stay_locked_without_a_token(tmp_path, monkeypatch):
    monkeypatch.delenv("AI_MONEY_TOWN_OWNER_TOKEN", raising=False)
    client = TestClient(create_app(tmp_path / "locked.sqlite3", FakeOllama(), scheduler_enabled=False))
    assert client.get("/api/owner/status").status_code == 503
    assert client.post("/api/tasks/1/run").status_code == 503


def test_private_access_gate_covers_new_endpoints(tmp_path, monkeypatch):
    monkeypatch.setenv("AI_MONEY_TOWN_ACCESS_USERNAME", "owner")
    monkeypatch.setenv("AI_MONEY_TOWN_ACCESS_PASSWORD", "secret-pass")
    app = create_app(tmp_path / "gated.sqlite3", FakeOllama(), scheduler_enabled=False)
    with TestClient(app) as client:
        assert client.get("/api/system/health").status_code == 401
        assert client.get("/api/deliverables").status_code == 401
        auth = ("owner", "secret-pass")
        assert client.get("/api/system/health", auth=auth).status_code == 200


def test_importing_the_application_module_never_touches_the_database(tmp_path):
    """A test run or a plain import must not migrate or create the owner's data."""
    root = Path(__file__).resolve().parents[2]
    target = tmp_path / "should-not-exist.db"
    environment = {**os.environ, "AI_MONEY_TOWN_DB": str(target)}
    environment.pop("AI_MONEY_TOWN_OWNER_TOKEN", None)
    result = subprocess.run(
        [sys.executable, "-c", "import backend.app.main"],
        cwd=str(root), env=environment, capture_output=True, text=True, timeout=120,
    )
    assert result.returncode == 0, result.stderr
    assert not target.exists()
